package ru.abab.bots;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import net.fabricmc.loader.api.FabricLoader;
/** Owns the bots (offline accounts used to sit AFK) + their saved settings. No bot limit; joins are staggered, commands are rate limited, no chat spam. */
public final class BotManager {
  public static volatile int gapSeconds=6; // seconds between bot joins (servers throttle fast connections); minimum 3
  public static final List<Bot> bots=new CopyOnWriteArrayList<>();
  public static final ConcurrentLinkedDeque<String> LOG=new ConcurrentLinkedDeque<>();
  public static volatile boolean reconnect=true; public static volatile int reconnectSeconds=20, joinDelaySeconds=4; public static volatile String script="", lastIp="";
  // (clientbound keep-alive id, serverbound keep-alive id) candidates for 1.21.11; rotates automatically if the server times the bot out
  static final int[][] CAND={{0x2B,0x1C},{0x2B,0x1B},{0x2C,0x1C},{0x2B,0x1D},{0x2C,0x1B},{0x2B,0x1A}}; static volatile int cal=0; static long lastCal; static boolean loaded;
  static Path file(){ return FabricLoader.getInstance().getConfigDir().resolve("abab-bots.properties"); }
  public static void log(String s){ LOG.add(s); while(LOG.size()>300) LOG.pollFirst(); System.out.println("[ABAB bots] "+s); }
  public static void load(){ if(loaded) return; loaded=true; try{ Path f=file(); if(!Files.exists(f)) return; Properties p=new Properties(); try(var r=Files.newBufferedReader(f)){ p.load(r); }
      cal=Math.floorMod(Integer.parseInt(p.getProperty("cal","0")),CAND.length); script=p.getProperty("script",""); lastIp=p.getProperty("ip",""); reconnect=!"false".equals(p.getProperty("reconnect","true"));
      for(String n:p.getProperty("bots","").split(",")) if(!n.isBlank()&&find(n.trim())==null) bots.add(new Bot(n.trim())); }catch(Exception e){ e.printStackTrace(); } }
  public static void save(){ try{ Properties p=new Properties(); p.setProperty("cal",String.valueOf(cal)); p.setProperty("script",script); p.setProperty("ip",lastIp); p.setProperty("reconnect",String.valueOf(reconnect));
      StringBuilder sb=new StringBuilder(); for(Bot b:bots) sb.append(b.name).append(','); p.setProperty("bots",sb.toString()); try(var w=Files.newBufferedWriter(file())){ p.store(w,"ABAB bots"); } }catch(Exception e){ e.printStackTrace(); } }
  static int kaClient(){ return CAND[cal][0]; } static int kaServer(){ return CAND[cal][1]; }
  static synchronized void calFail(){ if(System.currentTimeMillis()-lastCal<20000) return; lastCal=System.currentTimeMillis(); cal=(cal+1)%CAND.length; save(); log("Keep-alive timed out - trying packet ids "+Integer.toHexString(kaClient())+"/"+Integer.toHexString(kaServer())); }
  static void calOk(){ save(); }
  public static String[] scriptCommands(){ String s=script==null?"":script; List<String> l=new ArrayList<>(); for(String c:s.split(";")) if(!c.isBlank()) l.add(c.trim()); return l.toArray(new String[0]); }
  public static Bot find(String n){ for(Bot b:bots) if(b.name.equalsIgnoreCase(n)) return b; return null; }
  /** creates prefix1..prefixN (names are max 16 chars) and returns how many were new */
  public static int addMany(String prefix,int count){ load(); int n=0; for(int i=1;i<=count;i++){ String name=prefix+i; if(name.length()<=16&&add(name)) n++; } return n; }
  public static boolean add(String n){ load(); if(!n.matches("[A-Za-z0-9_]{3,16}")||find(n)!=null) return false; bots.add(new Bot(n)); save(); return true; }
  public static void remove(String n){ Bot b=find(n); if(b!=null){ b.stopBot(); bots.remove(b); save(); } }
  public static void clear(){ for(Bot b:bots) b.stopBot(); bots.clear(); save(); }
  /** starts every bot that is not running, one every 6 seconds (servers throttle fast reconnects) */
  public static void joinAll(String ip){ load(); lastIp=ip; save(); List<Bot> l=new ArrayList<>(); for(Bot b:bots) if(b.selected) l.add(b); Thread t=new Thread(()->{ for(Bot b:l){ if(!b.isAlive()) b.start(ip); try{ Thread.sleep(Math.max(3,gapSeconds)*1000L); }catch(InterruptedException e){ return; } } },"ABAB-bot-join"); t.setDaemon(true); t.start(); }
  public static void leaveAll(){ for(Bot b:bots) if(b.selected) b.stopBot(); }
  public static int sendSelected(String cmd){ int n=0; for(Bot b:bots) if(b.selected&&b.isAlive()){ b.command(cmd); n++; } return n; }
  public static int sendFirst(int count,String cmd){ int n=0; for(Bot b:bots){ if(n>=count) break; if(b.isAlive()){ b.command(cmd); n++; } } return n; }
  public static int sendNames(String names,String cmd){ int n=0; for(String s:names.split(",")){ Bot b=find(s.trim()); if(b!=null&&b.isAlive()){ b.command(cmd); n++; } } return n; }
  public static void selectAll(boolean v){ for(Bot b:bots) b.selected=v; }
  public static void selectFirst(int n){ int i=0; for(Bot b:bots) b.selected=i++<n; }
  public static int selectedCount(){ int n=0; for(Bot b:bots) if(b.selected) n++; return n; }
  public static int removeSelected(){ List<Bot> l=new ArrayList<>(); for(Bot b:bots) if(b.selected) l.add(b); for(Bot b:l){ b.stopBot(); bots.remove(b); } save(); return l.size(); }
  public static int send(String target,String cmd){ int n=0; for(Bot b:bots) if((target==null||b.name.equalsIgnoreCase(target))&&b.isAlive()){ b.command(cmd); n++; } return n; }
}
