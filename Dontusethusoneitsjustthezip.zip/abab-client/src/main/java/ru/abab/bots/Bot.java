package ru.abab.bots;
import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.zip.*;
/**
 * One offline-mode ("cracked") bot connection: Handshake -> Login -> Configuration -> Play, answers keep-alives, and sends commands you give it.
 * It does NOT move, chat or spam; it just stays connected (AFK warp). Offline-mode servers only (no Mojang login).
 * Protocol numbers are for Minecraft 1.21.11 (protocol 774). The play keep-alive packet ids are calibrated automatically (see BotManager).
 */
public final class Bot implements Runnable {
  static final int PROTOCOL=774;
  enum S{LOGIN,CONFIG,PLAY}
  public final String name; public volatile boolean selected=true; public volatile String status="Idle"; volatile boolean stop, fatal, alive; String host; int port=25565; Thread thread;
  Socket sock; InputStream in; OutputStream out; int threshold=-1; long lastCmd; final ConcurrentLinkedDeque<String> queue=new ConcurrentLinkedDeque<>(); final ArrayDeque<String> script=new ArrayDeque<>(); long nextScript;
  public Bot(String name){ this.name=name; }
  public boolean isAlive(){ return alive; }
  public void start(String ip){
    if(alive) return; stop=false; fatal=false; String h=ip.trim(); int p=25565; int c=h.lastIndexOf(':'); if(c>0&&h.substring(c+1).matches("\\d{1,5}")){ p=Integer.parseInt(h.substring(c+1)); h=h.substring(0,c); }
    host=h; port=p; alive=true; thread=new Thread(this,"ABAB-bot-"+name); thread.setDaemon(true); thread.start(); }
  public void stopBot(){ stop=true; close(); if(!alive) status="Stopped"; }
  public void command(String c){ queue.add(c.startsWith("/")?c.substring(1):c); }
  void close(){ try{ if(sock!=null) sock.close(); }catch(Exception ignored){} }
  @Override public void run(){
    try{ while(!stop){
        long t0=System.currentTimeMillis(); String reason="";
        try{ session(); }catch(Exception e){ reason=String.valueOf(e.getMessage()); lastReason=reason; BotManager.log(name+": "+reason); }
        close(); long dur=System.currentTimeMillis()-playStart; boolean wasPlay=playStart>0&&playStart>=t0;
        if(wasPlay){ String r=reason.toLowerCase(); if(dur<75000&&(r.contains("timed out")||r.contains("timeout")||r.contains("closed"))) BotManager.calFail(); else if(dur>90000) BotManager.calOk(); }
        playStart=0; if(stop||fatal||!BotManager.reconnect) break;
        for(int i=0;i<BotManager.reconnectSeconds*2&&!stop;i++){ status="Reconnecting in "+(BotManager.reconnectSeconds-i/2)+"s ("+(lastReason.length()>34?lastReason.substring(0,34):lastReason)+")"; Thread.sleep(500); }
      }
    }catch(InterruptedException ignored){}
    alive=false; if(!fatal) status=stop?"Stopped":"Disconnected: "+(lastReason.length()>40?lastReason.substring(0,40):lastReason); }
  long playStart; String lastReason=""; final Set<Integer> seen=new HashSet<>(); int logged;
  // ---------- protocol helpers ----------
  static void vi(ByteArrayOutputStream b,int v){ while((v&~0x7F)!=0){ b.write((v&0x7F)|0x80); v>>>=7; } b.write(v); }
  static void str(ByteArrayOutputStream b,String s){ byte[] d=s.getBytes(StandardCharsets.UTF_8); vi(b,d.length); b.write(d,0,d.length); }
  static int readVi(byte[] d,int[] o){ int n=0,sh=0; while(true){ int by=d[o[0]++]&0xFF; n|=(by&0x7F)<<sh; if((by&0x80)==0) break; sh+=7; if(sh>35) throw new RuntimeException("bad varint"); } return n; }
  static byte[] offlineUuid(String n){ UUID u=UUID.nameUUIDFromBytes(("OfflinePlayer:"+n).getBytes(StandardCharsets.UTF_8)); return ByteBuffer.allocate(16).putLong(u.getMostSignificantBits()).putLong(u.getLeastSignificantBits()).array(); }
  static String printable(byte[] b,int from){ StringBuilder sb=new StringBuilder(), cur=new StringBuilder(); for(int i=from;i<b.length;i++){ int c=b[i]&0xFF; if(c>=32&&c<127) cur.append((char)c); else { if(cur.length()>=3) sb.append(cur).append(' '); cur.setLength(0); } } if(cur.length()>=3) sb.append(cur); return sb.toString().trim(); }
  void send(int id,ByteArrayOutputStream payload) throws IOException {
    ByteArrayOutputStream body=new ByteArrayOutputStream(); vi(body,id); if(payload!=null) body.write(payload.toByteArray(),0,payload.size());
    byte[] bd=body.toByteArray(); ByteArrayOutputStream frame=new ByteArrayOutputStream();
    if(threshold>=0){ if(bd.length>=threshold){ Deflater df=new Deflater(); df.setInput(bd); df.finish(); byte[] buf=new byte[bd.length+64]; int n=df.deflate(buf); df.end(); vi(frame,bd.length); frame.write(buf,0,n); } else { vi(frame,0); frame.write(bd,0,bd.length); } }
    else frame.write(bd,0,bd.length);
    ByteArrayOutputStream pkt=new ByteArrayOutputStream(); vi(pkt,frame.size()); pkt.write(frame.toByteArray(),0,frame.size()); out.write(pkt.toByteArray()); out.flush(); }
  /** returns -2 when nothing arrived within the socket timeout */
  int readLen() throws IOException { int n=0,sh=0; boolean first=true; while(true){ int by; try{ by=in.read(); }catch(SocketTimeoutException e){ if(first) return -2; continue; } if(by<0) throw new IOException("Server closed the connection"); first=false; n|=(by&0x7F)<<sh; if((by&0x80)==0) return n; sh+=7; if(sh>35) throw new IOException("bad length"); } }
  byte[] readN(int len) throws IOException { byte[] d=new byte[len]; int got=0; long dl=System.currentTimeMillis()+20000; while(got<len){ try{ int r=in.read(d,got,len-got); if(r<0) throw new IOException("Server closed the connection"); got+=r; }catch(SocketTimeoutException e){ if(System.currentTimeMillis()>dl) throw new IOException("read timeout"); } } return d; }
  byte[] readPacket() throws IOException { int len=readLen(); if(len==-2) return null; if(len<0||len>8_000_000) throw new IOException("bad packet size"); byte[] raw=readN(len);
    if(threshold<0) return raw; int[] o={0}; int dl=readVi(raw,o); byte[] body=Arrays.copyOfRange(raw,o[0],raw.length); if(dl==0) return body;
    Inflater inf=new Inflater(); inf.setInput(body); byte[] res=new byte[dl]; try{ int n=0; while(n<dl&&!inf.finished()){ int r=inf.inflate(res,n,dl-n); if(r==0&&(inf.needsInput()||inf.needsDictionary())) break; n+=r; } }catch(DataFormatException e){ throw new IOException("bad compressed packet"); } finally{ inf.end(); } return res; }
  void clientInfoAndBrand() throws IOException {
    ByteArrayOutputStream b=new ByteArrayOutputStream(); str(b,"en_US"); b.write(8); vi(b,0); b.write(1); b.write(0x7F); vi(b,1); b.write(0); b.write(1); vi(b,0); send(0x00,b);
    ByteArrayOutputStream c=new ByteArrayOutputStream(); str(c,"minecraft:brand"); str(c,"vanilla"); send(0x02,c); }
  void sendCommand(String cmd) throws IOException { ByteArrayOutputStream b=new ByteArrayOutputStream(); str(b,cmd); send(0x06,b); lastCmd=System.currentTimeMillis(); BotManager.log(name+" > /"+cmd); }
  // ---------- one connection ----------
  void session() throws Exception {
    status="Connecting..."; sock=new Socket(); sock.connect(new InetSocketAddress(host,port),10000); sock.setSoTimeout(1000); sock.setTcpNoDelay(true); in=new BufferedInputStream(sock.getInputStream()); out=sock.getOutputStream(); threshold=-1;
    ByteArrayOutputStream h=new ByteArrayOutputStream(); vi(h,PROTOCOL); str(h,host); h.write(port>>8); h.write(port&0xFF); vi(h,2); send(0x00,h);
    ByteArrayOutputStream l=new ByteArrayOutputStream(); str(l,name); byte[] u=offlineUuid(name); l.write(u,0,u.length); send(0x00,l);
    S st=S.LOGIN; status="Logging in..."; seen.clear(); logged=0; int kaIn=BotManager.kaClient(), kaOut=BotManager.kaServer(); long lastRx=System.currentTimeMillis();
    while(!stop){
      if(st==S.PLAY){ long now=System.currentTimeMillis();
        if(!script.isEmpty()&&now>=nextScript){ sendCommand(script.pollFirst().replaceFirst("^/","")); nextScript=now+2500; }
        else if(!queue.isEmpty()&&now-lastCmd>=1500) sendCommand(queue.pollFirst()); }
      byte[] body=readPacket();
      if(body==null){ if(System.currentTimeMillis()-lastRx>(st==S.PLAY?70000:30000)) throw new IOException("No data from the server (timed out)"); continue; }
      lastRx=System.currentTimeMillis(); int[] o={0}; int id=readVi(body,o); byte[] p=Arrays.copyOfRange(body,o[0],body.length);
      if(logged<14&&seen.add(st.ordinal()*4096+id)){ logged++; BotManager.log(name+" "+st+" packet 0x"+Integer.toHexString(id)+" ("+p.length+" bytes)"); }
      switch(st){
        case LOGIN -> { switch(id){
          case 0x00 -> { int[] q={0}; int n=readVi(p,q); String r=new String(p,q[0],Math.min(n,p.length-q[0]),StandardCharsets.UTF_8); fatal=true; status="Refused"; throw new IOException("Refused: "+printable(r.getBytes(StandardCharsets.UTF_8),0)); }
          case 0x01 -> { fatal=true; status="Server is online-mode (premium only)"; throw new IOException("This server needs a premium account - offline bots cannot join"); }
          case 0x02 -> { send(0x03,null); st=S.CONFIG; status="Configuring..."; clientInfoAndBrand(); }
          case 0x03 -> { int[] q={0}; threshold=readVi(p,q); }
          case 0x04 -> { int[] q={0}; int mid=readVi(p,q); ByteArrayOutputStream r=new ByteArrayOutputStream(); vi(r,mid); r.write(0); send(0x02,r); }
          default -> {} } }
        case CONFIG -> { switch(id){
          case 0x02 -> throw new IOException("Disconnected while configuring: "+printable(p,0));
          case 0x03 -> { send(0x03,null); st=S.PLAY; playStart=System.currentTimeMillis(); status="Online"; script.clear(); for(String c:BotManager.scriptCommands()) script.add(c); nextScript=playStart+BotManager.joinDelaySeconds*1000L; BotManager.log(name+" joined "+host); }
          case 0x04 -> { ByteArrayOutputStream r=new ByteArrayOutputStream(); r.write(p,0,p.length); send(0x04,r); }
          case 0x05 -> { ByteArrayOutputStream r=new ByteArrayOutputStream(); r.write(p,0,p.length); send(0x05,r); }
          case 0x09 -> { if(p.length>=16){ ByteArrayOutputStream r=new ByteArrayOutputStream(); r.write(p,0,16); vi(r,0); send(0x06,r); } } // resource pack: answer "loaded"
          case 0x0E -> { ByteArrayOutputStream r=new ByteArrayOutputStream(); vi(r,0); send(0x07,r); } // known packs: none
          default -> {} } }
        case PLAY -> {
          if(id==kaIn&&p.length==8){ ByteArrayOutputStream r=new ByteArrayOutputStream(); r.write(p,0,8); send(kaOut,r); }
          else if(id==0x20) throw new IOException("Kicked: "+printable(p,0));
          else if(id==0x74){ send(0x0F,null); st=S.CONFIG; status="Switching server..."; clientInfoAndBrand(); } }
      }
    }
  }
}
