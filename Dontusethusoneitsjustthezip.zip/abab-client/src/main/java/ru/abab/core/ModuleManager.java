package ru.abab.core;
import java.util.*;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import ru.abab.mods.Mods;
public final class ModuleManager {
  public static final List<Module> all=new ArrayList<>();
  private static final Map<Module,Boolean> down=new HashMap<>();
  public static boolean panicked; static final List<Module> saved=new ArrayList<>();
  /** master switch: turns every enabled module OFF (and hides the HUD); call again to restore exactly what was on. */
  public static void panic(){
    if(!panicked){ saved.clear(); for(Module m:all) if(m.on){ saved.add(m); m.set(false); } panicked=true; }
    else { for(Module m:saved) m.set(true); saved.clear(); panicked=false; }
  }
  public static void init(){ Mods.register(all); }
  public static Module get(String n){ for(Module m:all) if(m.name.equalsIgnoreCase(n)) return m; return null; }
  public static List<Module> byCat(Category c){ List<Module> l=new ArrayList<>(); for(Module m:all) if(m.cat==c) l.add(m); return l; }
  public static int enabledCount(){ int n=0; for(Module m:all) if(m.on) n++; return n; }
  public static boolean pendingInit;
  public static void tick(){
    MinecraftClient mc=MinecraftClient.getInstance();
    if(mc.player==null||mc.world==null) return;
    if(pendingInit){ pendingInit=false; for(Module m:all) if(m.on){ try{ m.onEnable(); }catch(Exception e){ e.printStackTrace(); m.on=false; } } } // restore saved modules
    if(mc.currentScreen==null){
      long h=mc.getWindow().getHandle();
      for(Module m:all){ if(m.key<0) continue; boolean p=GLFW.glfwGetKey(h,m.key)==GLFW.GLFW_PRESS; if(m.hold) m.set(p); else if(p&&!down.getOrDefault(m,false)) m.toggle(); down.put(m,p); }
    }
    for(Module m:all) if(m.on){ try{ m.onTick(); }catch(Exception e){ e.printStackTrace(); m.set(false); Util.msg("§e"+m.name+" crashed and was disabled: "+e); } }
  }
  public static int parseKey(String s){
    String k=s.toLowerCase().trim();
    if(k.length()==1){ char c=k.charAt(0); if(c>='a'&&c<='z') return GLFW.GLFW_KEY_A+(c-'a'); if(c>='0'&&c<='9') return GLFW.GLFW_KEY_0+(c-'0'); }
    if(k.matches("f([1-9]|1[0-2])")) return GLFW.GLFW_KEY_F1+Integer.parseInt(k.substring(1))-1;
    return switch(k){
      case "space" -> GLFW.GLFW_KEY_SPACE; case "tab" -> GLFW.GLFW_KEY_TAB; case "enter" -> GLFW.GLFW_KEY_ENTER;
      case "rshift","right.shift" -> GLFW.GLFW_KEY_RIGHT_SHIFT; case "lshift","left.shift" -> GLFW.GLFW_KEY_LEFT_SHIFT;
      case "rctrl","right.control" -> GLFW.GLFW_KEY_RIGHT_CONTROL; case "lctrl","left.control" -> GLFW.GLFW_KEY_LEFT_CONTROL;
      case "ralt","right.alt" -> GLFW.GLFW_KEY_RIGHT_ALT; case "lalt","left.alt" -> GLFW.GLFW_KEY_LEFT_ALT;
      case "up" -> GLFW.GLFW_KEY_UP; case "down" -> GLFW.GLFW_KEY_DOWN; case "left" -> GLFW.GLFW_KEY_LEFT; case "right" -> GLFW.GLFW_KEY_RIGHT;
      case "insert" -> GLFW.GLFW_KEY_INSERT; case "delete" -> GLFW.GLFW_KEY_DELETE; case "home" -> GLFW.GLFW_KEY_HOME; case "end" -> GLFW.GLFW_KEY_END;
      case "grave","`" -> GLFW.GLFW_KEY_GRAVE_ACCENT; case "semicolon",";" -> GLFW.GLFW_KEY_SEMICOLON; case "comma","," -> GLFW.GLFW_KEY_COMMA; case "period","." -> GLFW.GLFW_KEY_PERIOD;
      default -> -2;
    };
  }
  public static String keyName(int k){
    if(k<0) return "-";
    if(k>=GLFW.GLFW_KEY_A&&k<=GLFW.GLFW_KEY_Z) return String.valueOf((char)('A'+(k-GLFW.GLFW_KEY_A)));
    if(k>=GLFW.GLFW_KEY_0&&k<=GLFW.GLFW_KEY_9) return String.valueOf((char)('0'+(k-GLFW.GLFW_KEY_0)));
    if(k>=GLFW.GLFW_KEY_F1&&k<=GLFW.GLFW_KEY_F12) return "F"+(k-GLFW.GLFW_KEY_F1+1);
    String n=GLFW.glfwGetKeyName(k,0); if(n!=null) return n.toUpperCase();
    return switch(k){ case GLFW.GLFW_KEY_SPACE->"SPACE"; case GLFW.GLFW_KEY_RIGHT_SHIFT->"RSHIFT"; case GLFW.GLFW_KEY_LEFT_SHIFT->"LSHIFT"; case GLFW.GLFW_KEY_RIGHT_CONTROL->"RCTRL"; case GLFW.GLFW_KEY_LEFT_CONTROL->"LCTRL"; case GLFW.GLFW_KEY_TAB->"TAB"; default->"KEY"+k; };
  }
}
