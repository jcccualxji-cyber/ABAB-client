package ru.abab.core;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.*;
import org.joml.Matrix4f;
import ru.abab.AbabClient;
import java.util.List;
/**
 * Through-wall overlay renderer for 1.21.11 (projects to the screen and draws with DrawContext).
 * All coordinates passed in are camera-relative unless stated otherwise.
 * v2: lines are drawn as horizontal/vertical RUNS (about half the fill calls of the old 1px stepping),
 * plus 2D boxes, corner boxes and tracers that also point to targets behind you.
 */
public final class R {
  static DrawContext g;
  public static void begin(DrawContext ctx){ g=ctx; }
  public static void end(){ g=null; }
  static int sw(){ return MinecraftClient.getInstance().getWindow().getScaledWidth(); }
  static int sh(){ return MinecraftClient.getInstance().getWindow().getScaledHeight(); }

  /** Liang-Barsky clip, then draw as runs (one fill per row/column). Long lines use 2px steps (half the fills = faster on phones). */
  static void seg(double x0,double y0,double x1,double y1,int c){
    if(g==null||(c>>>24)==0) return;
    double dx=x1-x0, dy=y1-y0, t0=0, t1=1;
    double[] p={-dx,dx,-dy,dy}, q={x0,sw()-x0,y0,sh()-y0};
    for(int i=0;i<4;i++){
      if(p[i]==0){ if(q[i]<0) return; }
      else { double r=q[i]/p[i]; if(p[i]<0){ if(r>t1) return; if(r>t0) t0=r; } else { if(r<t0) return; if(r<t1) t1=r; } }
    }
    int ax=(int)Math.round(x0+t0*dx), ay=(int)Math.round(y0+t0*dy), bx=(int)Math.round(x0+t1*dx), by=(int)Math.round(y0+t1*dy);
    int w=bx-ax, h=by-ay;
    if(h==0){ g.fill(Math.min(ax,bx),ay,Math.max(ax,bx)+1,ay+1,c); return; }
    if(w==0){ g.fill(ax,Math.min(ay,by),ax+1,Math.max(ay,by)+1,c); return; }
    if(Math.abs(w)>=Math.abs(h)){
      int n=Math.min(4096,Math.abs(h)); int sy=h>0?1:-1, st=n>110?2:1;
      for(int i=0;i<=n;i+=st){ int y=ay+sy*i; double ta=Math.max(0,(i-0.5)/n), tb=Math.min(1,(i+st-0.5)/n);
        int xa=(int)Math.round(ax+w*ta), xb=(int)Math.round(ax+w*tb); int ya=sy>0?y:y-st+1; g.fill(Math.min(xa,xb),ya,Math.max(xa,xb)+1,ya+st,c); }
    } else {
      int n=Math.min(4096,Math.abs(w)); int sx=w>0?1:-1, st=n>110?2:1;
      for(int i=0;i<=n;i+=st){ int x=ax+sx*i; double ta=Math.max(0,(i-0.5)/n), tb=Math.min(1,(i+st-0.5)/n);
        int ya=(int)Math.round(ay+h*ta), yb=(int)Math.round(ay+h*tb); int xa=sx>0?x:x-st+1; g.fill(xa,Math.min(ya,yb),xa+st,Math.max(ya,yb)+1,c); }
    }
  }
  /** 3D line between two camera-relative points, clipped against the near plane (so big boxes you stand inside still draw) */
  public static void seg3(Vec3d a,Vec3d b,int c){
    if(g==null||(c>>>24)==0) return;
    double[] p=new double[3], q=new double[3]; AbabClient.camSpace(a,p); AbabClient.camSpace(b,q); double near=0.05;
    if(p[2]<near&&q[2]<near) return;
    if(p[2]<near){ double t=(near-p[2])/(q[2]-p[2]); for(int i=0;i<3;i++) p[i]=p[i]+(q[i]-p[i])*t; p[2]=near; }
    else if(q[2]<near){ double t=(near-q[2])/(p[2]-q[2]); for(int i=0;i<3;i++) q[i]=q[i]+(p[i]-q[i])*t; q[2]=near; }
    double[] sa=AbabClient.scr(p), sb=AbabClient.scr(q); seg(sa[0],sa[1],sb[0],sb[1],c);
  }
  /** filled + outlined convex quad/polygon of camera-relative points, clipped against the near plane */
  public static void quad(Vec3d[] rel,int fill,int line){
    if(g==null) return; List<double[]> in=new java.util.ArrayList<>(); for(Vec3d v:rel){ double[] o=new double[3]; AbabClient.camSpace(v,o); in.add(o); }
    double near=0.05; List<double[]> out=new java.util.ArrayList<>();
    for(int i=0;i<in.size();i++){ double[] a=in.get(i), b=in.get((i+1)%in.size()); boolean ai=a[2]>=near, bi=b[2]>=near;
      if(ai) out.add(a);
      if(ai!=bi){ double t=(near-a[2])/(b[2]-a[2]); out.add(new double[]{a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,near}); } }
    if(out.size()<3) return; List<double[]> pts=new java.util.ArrayList<>(); for(double[] o:out) pts.add(AbabClient.scr(o)); fillHull(pts,fill,line);
  }

  /** Full 3D box (wire + optional screen-space fill). */
  public static void box(Matrix4f unused,Box bx,int fill,int line){
    if(g==null) return;
    double[][] cs={{bx.minX,bx.minY,bx.minZ},{bx.maxX,bx.minY,bx.minZ},{bx.maxX,bx.minY,bx.maxZ},{bx.minX,bx.minY,bx.maxZ},
                   {bx.minX,bx.maxY,bx.minZ},{bx.maxX,bx.maxY,bx.minZ},{bx.maxX,bx.maxY,bx.maxZ},{bx.minX,bx.maxY,bx.maxZ}};
    Vec3d[] s=new Vec3d[8]; double minx=1e9,miny=1e9,maxx=-1e9,maxy=-1e9; int vis=0;
    for(int i=0;i<8;i++){ s[i]=AbabClient.projectRel(new Vec3d(cs[i][0],cs[i][1],cs[i][2])); if(s[i]!=null){ vis++; minx=Math.min(minx,s[i].x); maxx=Math.max(maxx,s[i].x); miny=Math.min(miny,s[i].y); maxy=Math.max(maxy,s[i].y); } }
    if(vis==0) return;
    if((fill>>>24)>0&&vis==8&&(bx.maxY-bx.minY)>0.2){
      int x1=(int)Math.max(0,minx), y1=(int)Math.max(0,miny), x2=(int)Math.min(sw(),maxx), y2=(int)Math.min(sh(),maxy);
      if(x2>x1&&y2>y1) g.fill(x1,y1,x2,y2,fill);
    }
    if((line>>>24)>0){
      int[][] e={{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
      for(int[] k:e) seg3(new Vec3d(cs[k[0]][0],cs[k[0]][1],cs[k[0]][2]),new Vec3d(cs[k[1]][0],cs[k[1]][1],cs[k[1]][2]),line);
    }
  }

  /** Screen rectangle {minX,minY,maxX,maxY} of a camera-relative box, or null if any corner is behind the camera. */
  public static double[] rect(Box bx){
    double minx=1e9,miny=1e9,maxx=-1e9,maxy=-1e9;
    for(int i=0;i<8;i++){
      Vec3d s=AbabClient.projectRel(new Vec3d((i&1)==0?bx.minX:bx.maxX,(i&2)==0?bx.minY:bx.maxY,(i&4)==0?bx.minZ:bx.maxZ));
      if(s==null) return null;
      minx=Math.min(minx,s.x); maxx=Math.max(maxx,s.x); miny=Math.min(miny,s.y); maxy=Math.max(maxy,s.y);
    }
    if(maxx<0||maxy<0||minx>sw()||miny>sh()) return null;
    return new double[]{minx,miny,maxx,maxy};
  }

  /** 2D ESP box (always upright and centered on the target). corners=true draws only the corner brackets. */
  public static void box2d(double[] r,int line,int fill,boolean corners){
    if(g==null||r==null) return;
    int x1=(int)Math.round(r[0]), y1=(int)Math.round(r[1]), x2=(int)Math.round(r[2]), y2=(int)Math.round(r[3]);
    if(x2-x1<2) x2=x1+2; if(y2-y1<2) y2=y1+2;
    if((fill>>>24)>0) g.fill(x1,y1,x2,y2,fill);
    int sh=0xAA000000;
    if(!corners){
      g.fill(x1-1,y1-1,x2+1,y1,sh); g.fill(x1-1,y2,x2+1,y2+1,sh); g.fill(x1-1,y1,x1,y2,sh); g.fill(x2,y1,x2+1,y2,sh);
      g.fill(x1,y1,x2,y1+1,line); g.fill(x1,y2-1,x2,y2,line); g.fill(x1,y1,x1+1,y2,line); g.fill(x2-1,y1,x2,y2,line);
    } else {
      int L=Math.max(3,Math.min(x2-x1,y2-y1)/4);
      g.fill(x1,y1,x1+L,y1+1,line); g.fill(x1,y1,x1+1,y1+L,line);
      g.fill(x2-L,y1,x2,y1+1,line); g.fill(x2-1,y1,x2,y1+L,line);
      g.fill(x1,y2-1,x1+L,y2,line); g.fill(x1,y2-L,x1+1,y2,line);
      g.fill(x2-L,y2-1,x2,y2,line); g.fill(x2-1,y2-L,x2,y2,line);
    }
  }

  public static void line(Matrix4f unused,Vec3d a,Vec3d b,int c){
    seg3(a,b,c);
  }

  /** Tracer from the screen center (or bottom center) to a camera-relative point. Points behind you aim at the screen edge. */
  public static void tracer(Vec3d rel,int c,boolean bottom){
    if(g==null) return;
    double[] o=new double[3]; AbabClient.camSpace(rel,o);
    double W=sw(),H=sh(), sx=W/2, sy=bottom?H:H/2, tx,ty;
    if(o[2]<=0.05){ double l=Math.hypot(o[0],o[1]); if(l<1e-6){ tx=W/2; ty=H+2000; } else { tx=W/2+o[0]/l*4000; ty=H/2-o[1]/l*4000; } }
    else { double[] s=AbabClient.scr(o); tx=s[0]; ty=s[1]; }
    seg(sx,sy,tx,ty,c);
  }

  /** pts are absolute world positions. */
  public static void lines(Matrix4f unused,List<Vec3d> pts,Vec3d cam,int c){
    if(pts.size()<2) return;
    Vec3d prev=null;
    for(Vec3d p:pts){ Vec3d s=AbabClient.projectRel(p.subtract(cam)); if(prev!=null&&s!=null) seg(prev.x,prev.y,s.x,s.y,c); prev=s; }
  }

  /** Fill the convex hull of screen points (scanline, one fill per row) + optional outline. Used for Chams silhouettes. */
  public static void fillHull(List<double[]> pts,int fill,int line){
    if(g==null||pts.size()<3) return;
    List<double[]> sorted=new java.util.ArrayList<>(pts); sorted.sort((a,b)->a[0]!=b[0]?Double.compare(a[0],b[0]):Double.compare(a[1],b[1]));
    List<double[]> h=new java.util.ArrayList<>();
    for(int pass=0;pass<2;pass++){ int start=h.size();
      for(int i=0;i<sorted.size();i++){ double[] q=sorted.get(pass==0?i:sorted.size()-1-i);
        while(h.size()>=start+2){ double[] a=h.get(h.size()-2), b=h.get(h.size()-1); if((b[0]-a[0])*(q[1]-a[1])-(b[1]-a[1])*(q[0]-a[0])<=0) h.remove(h.size()-1); else break; }
        h.add(q); }
      h.remove(h.size()-1); }
    int n=h.size(); if(n<3) return;
    if((fill>>>24)>0){
      double miny=1e9,maxy=-1e9; for(double[] q:h){ miny=java.lang.Math.min(miny,q[1]); maxy=java.lang.Math.max(maxy,q[1]); }
      int y0=(int)java.lang.Math.max(0,java.lang.Math.floor(miny)), y1=(int)java.lang.Math.min(sh()-1,java.lang.Math.ceil(maxy));
      for(int y=y0;y<=y1;y++){ double yy=y+0.5, lo=1e9, hi=-1e9;
        for(int i=0;i<n;i++){ double[] a=h.get(i), b=h.get((i+1)%n); if((a[1]<=yy&&b[1]>yy)||(b[1]<=yy&&a[1]>yy)){ double x=a[0]+(yy-a[1])/(b[1]-a[1])*(b[0]-a[0]); lo=java.lang.Math.min(lo,x); hi=java.lang.Math.max(hi,x); } }
        if(hi>=lo){ int xa=(int)java.lang.Math.max(0,java.lang.Math.round(lo)), xb=(int)java.lang.Math.min(sw(),java.lang.Math.round(hi)); if(xb>xa) g.fill(xa,y,xb,y+1,fill); } } }
    if((line>>>24)>0) for(int i=0;i<n;i++){ double[] a=h.get(i), b=h.get((i+1)%n); seg(a[0],a[1],b[0],b[1],line); }
  }

  /** HSB -> ARGB without java.awt (java.awt does not exist on Android launchers!) */
  public static int hsb(float h,float sat,float v){ float r=0,g2=0,b=0; int i=(int)(h*6); float f=h*6-i, p=v*(1-sat), q=v*(1-f*sat), t=v*(1-(1-f)*sat);
    switch(i%6){ case 0 -> { r=v; g2=t; b=p; } case 1 -> { r=q; g2=v; b=p; } case 2 -> { r=p; g2=v; b=t; } case 3 -> { r=p; g2=q; b=v; } case 4 -> { r=t; g2=p; b=v; } default -> { r=v; g2=p; b=q; } }
    return 0xFF000000|((int)(r*255)<<16)|((int)(g2*255)<<8)|(int)(b*255); }
}
