package ru.abab.core;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;
/** Shareable configs: the ON modules + their settings + keybinds, as one line of text ("ABAB1:..."). Copy it, send it, paste it on another client. */
public final class ConfigCode {
  public static final String PREFIX="ABAB1:";
  static String value(Setting s){ return switch(s.type){ case BOOL -> String.valueOf(s.b); case NUM -> String.valueOf(s.d); case COLOR -> String.valueOf(s.c); }; }
  /** readable text of what is ON right now */
  public static String currentText(){ StringBuilder sb=new StringBuilder("ABAB-CONFIG 1\n");
    for(Module m:ModuleManager.all) if(m.on){ sb.append("M|").append(m.name).append('|').append(m.key).append('|').append(m.hold?1:0).append('\n'); for(Setting s:m.settings) sb.append("S|").append(m.name).append('|').append(s.name).append('|').append(value(s)).append('\n'); }
    return sb.toString(); }
  /** text -> one-line code */
  public static String encode(String text){
    try{ byte[] raw=text.getBytes(StandardCharsets.UTF_8); Deflater df=new Deflater(9); df.setInput(raw); df.finish(); ByteArrayOutputStream bo=new ByteArrayOutputStream(); byte[] buf=new byte[1024]; while(!df.finished()){ int n=df.deflate(buf); bo.write(buf,0,n); } df.end();
      return PREFIX+Base64.getEncoder().withoutPadding().encodeToString(bo.toByteArray()); }catch(Exception e){ return ""; } }
  /** code (or already-plain text) -> text, or null if it is not an ABAB config */
  public static String decode(String code){
    if(code==null) return null; String c=code.replaceAll("\\s+",""); 
    if(c.startsWith(PREFIX)){ try{ byte[] z=Base64.getDecoder().decode(c.substring(PREFIX.length())); Inflater inf=new Inflater(); inf.setInput(z); ByteArrayOutputStream bo=new ByteArrayOutputStream(); byte[] buf=new byte[1024]; int total=0;
        while(!inf.finished()){ int n=inf.inflate(buf); if(n==0&&(inf.needsInput()||inf.needsDictionary())) break; total+=n; if(total>400_000) return null; bo.write(buf,0,n); } inf.end(); return bo.toString(StandardCharsets.UTF_8); }catch(Exception e){ return null; } }
    if(code.trim().startsWith("ABAB-CONFIG")) return code; return null; }
  static int parse(String s){ try{ return Integer.parseInt(s.trim()); }catch(Exception e){ return -1; } }
  /** switches modules ON/OFF and sets their settings so they match the text; everything not in the text is turned OFF. Returns how many modules were enabled. */
  public static int apply(String text){
    Set<String> on=new HashSet<>(); Map<String,Map<String,String>> st=new HashMap<>(); Map<String,int[]> kh=new HashMap<>();
    for(String line:text.split("\n")){ line=line.trim(); if(line.isEmpty()) continue;
      if(line.startsWith("M|")){ String[] p=line.split("\\|"); if(p.length>=2){ on.add(p[1]); if(p.length>=4) kh.put(p[1],new int[]{parse(p[2]),parse(p[3])}); } }
      else if(line.startsWith("S|")){ String[] p=line.split("\\|",4); if(p.length==4) st.computeIfAbsent(p[1],k->new HashMap<>()).put(p[2],p[3]); }
      else if(!line.startsWith("ABAB")&&!line.startsWith("name=")&&!line.contains("|")) on.add(line); } // old profile files: just module names
    int n=0; ModuleManager.panicked=false;
    for(Module m:ModuleManager.all){ boolean want=on.contains(m.name);
      if(want){ Map<String,String> ms=st.get(m.name);
        if(ms!=null) for(Setting s:m.settings){ String v=ms.get(s.name); if(v==null) continue;
          try{ switch(s.type){ case BOOL -> s.b=Boolean.parseBoolean(v); case NUM -> s.d=Math.max(s.min,Math.min(s.max,Double.parseDouble(v))); case COLOR -> s.c=Integer.parseInt(v); } }catch(Exception ignored){} }
        int[] k=kh.get(m.name); if(k!=null){ m.key=k[0]; m.hold=k[1]==1; } n++; }
      if(m.on!=want) m.set(want); }
    Config.save(); return n; }
}
