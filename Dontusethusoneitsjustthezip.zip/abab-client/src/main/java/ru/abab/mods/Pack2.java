package ru.abab.mods;
import java.util.*;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.block.*;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.*;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.FishingBobberEntity;
import net.minecraft.entity.vehicle.VehicleEntity;
import net.minecraft.item.*;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.*;
import net.minecraft.util.math.*;
import net.minecraft.world.RaycastContext;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;
import ru.abab.AbabClient;
import ru.abab.core.Module;
import ru.abab.core.*;
import ru.abab.gui.Hud;
import ru.abab.mixin.*;

/** Batch 2: 57 more modules. */
public final class Pack2 {
  public static void register(List<Module> l){
    l.addAll(List.of(new AutoGap(),new AutoTrap(),new SelfTrap(),new AutoWeapon(),new BowSpam(),new BowAimbot(),new ShieldBypass(),new Criticals(),new AutoMend(),new Offhand(),new Burrow(),new AutoCity(),
      new FastUse(),new AutoTool(),new AutoReplenish(),new AutoFish(),new MiddleClickExtra(),new AirPlace(),new DeathCoords(),new AutoRespawn(),new SpeedMine(),new LiquidFiller(),new ChestStealer(),new AutoClicker()));
    l.addAll(List.of(new BoatFly(),new EntitySpeed(),new ElytraFly(),new AirJump(),new AntiLevitation(),new FastClimb(),new Follow(),new LongJump(),new ReverseStep(),new SafeWalk(),new Strafe(),new Parkour(),new ClickTP(),new AntiVoid(),new NoJumpDelay()));
    l.addAll(List.of(new Breadcrumbs(),new Waypoints(),new LogoutSpots(),new Trajectories(),new Zoom(),new NoBob(),new CityEsp(),new Coords(),new TargetHud(),new Radar(),new Counters()));
    l.addAll(List.of(new AutoShearer(),new AutoMount(),new AutoBreed(),new AutoNametag(),new PlayerLog(),new VisualRange()));
    Criticals cr=(Criticals)find(l,"Criticals");
    AttackEntityCallback.EVENT.register((p,w,hand,e,hit)->{
      if(w.isClient()&&cr.on&&mc().player.isOnGround()&&!mc().player.isTouchingWater()&&!mc().player.isClimbing()){
        double x=mc().player.getX(),y=mc().player.getY(),z=mc().player.getZ();
        Util.send(new PlayerMoveC2SPacket.PositionAndOnGround(x,y+0.0625,z,false,false)); Util.send(new PlayerMoveC2SPacket.PositionAndOnGround(x,y,z,false,false)); }
      return ActionResult.PASS; });
  }
  static Module find(List<Module> l,String n){ for(Module m:l) if(m.name.equals(n)) return m; return null; }
  static net.minecraft.client.MinecraftClient mc(){ return Module.mc; }

  // ---------- helpers ----------
  static PlayerEntity nearestPlayer(double range){ PlayerEntity t=null; double bd=range; for(PlayerEntity p:Module.mc.world.getPlayers()) if(p!=Module.mc.player&&p.isAlive()&&Module.mc.player.distanceTo(p)<bd){ bd=Module.mc.player.distanceTo(p); t=p; } return t; }
  static Vec3d inputDir(){ var pl=Module.mc.player; float f=Util.fwd(),s=Util.side(); if(f==0&&s==0) return Vec3d.ZERO; double yaw=Math.toRadians(pl.getYaw()),len=Math.max(1,Math.hypot(f,s));
    return new Vec3d((-Math.sin(yaw)*f+Math.cos(yaw)*s)/len,0,(Math.cos(yaw)*f+Math.sin(yaw)*s)/len); }
  static boolean free(BlockPos p){ return Module.mc.world.getBlockState(p).isReplaceable()&&Module.mc.world.getOtherEntities(null,new Box(p)).isEmpty(); }
  static int px(Setting s,int total){ return (int)(total*s.d/100.0); }
  static String dim(){ return Module.mc.world.getRegistryKey().getValue().getPath(); }
  static void tp(Vec3d to){ var pl=Module.mc.player; Vec3d from=pl.getEntityPos(); int n=(int)Math.ceil(from.distanceTo(to)/9.0);
    for(int i=1;i<n;i++){ Vec3d p=from.lerp(to,i/(double)n); Util.send(new PlayerMoveC2SPacket.PositionAndOnGround(p.x,p.y,p.z,false,false)); }
    Util.send(new PlayerMoveC2SPacket.PositionAndOnGround(to.x,to.y,to.z,false,false)); pl.setPosition(to); }

  // ================= COMBAT =================
  public static class AutoGap extends Module { Setting hp=num("Health",10,1,20,1); boolean eating; int old=-1; public AutoGap(){ super("AutoGap",Category.COMBAT); }
    public void onTick(){ int s=Util.findHotbar(x->x.isOf(Items.GOLDEN_APPLE)||x.isOf(Items.ENCHANTED_GOLDEN_APPLE));
      if((mc.player.getHealth()<=hp.d||(eating&&mc.player.isUsingItem()))&&s>=0){ if(!eating){ old=Util.sel(); eating=true; } Util.sel(s); mc.options.useKey.setPressed(true); return; }
      if(eating){ eating=false; mc.options.useKey.setPressed(false); if(old>=0) Util.sel(old); } }
    public void onDisable(){ if(eating){ mc.options.useKey.setPressed(false); eating=false; } } }

  public static class AutoTrap extends Module { Setting range=num("Range",6,2,10,0.5); public AutoTrap(){ super("AutoTrap",Category.COMBAT); }
    public void onTick(){ int slot=Util.findHotbar(s->s.isOf(Items.OBSIDIAN)); PlayerEntity t=nearestPlayer(range.d); if(slot<0||t==null) return; BlockPos f=t.getBlockPos(); List<BlockPos> ps=new ArrayList<>();
      for(Direction d:Direction.Type.HORIZONTAL) ps.add(f.offset(d)); for(Direction d:Direction.Type.HORIZONTAL) ps.add(f.up().offset(d)); ps.add(f.up(2));
      int old=Util.sel(),n=0; for(BlockPos p:ps){ if(n>=3) break; if(free(p)){ Util.sel(slot); if(Util.place(p)) n++; } } if(n>0) Util.sel(old); } }

  public static class SelfTrap extends Module { public SelfTrap(){ super("SelfTrap",Category.COMBAT); }
    public void onTick(){ int slot=Util.findHotbar(s->s.isOf(Items.OBSIDIAN)); if(slot<0) return; BlockPos f=mc.player.getBlockPos(); List<BlockPos> ps=new ArrayList<>();
      for(Direction d:Direction.Type.HORIZONTAL) ps.add(f.up().offset(d)); ps.add(f.up(2));
      int old=Util.sel(),n=0; for(BlockPos p:ps){ if(n>=2) break; if(free(p)){ Util.sel(slot); if(Util.place(p)) n++; } } if(n>0) Util.sel(old); } }

  static double wscore(ItemStack s){ String n=Registries.ITEM.getId(s.getItem()).getPath(); double r=n.startsWith("netherite")?5:n.startsWith("diamond")?4:n.startsWith("iron")?3:n.startsWith("stone")?2:1;
    return n.endsWith("_sword")?r+0.5:n.endsWith("_axe")?r:-1; }
  public static class AutoWeapon extends Module { public AutoWeapon(){ super("AutoWeapon",Category.COMBAT); }
    public void onTick(){ if(!mc.options.attackKey.isPressed()||!(mc.crosshairTarget instanceof EntityHitResult)) return; int best=-1; double bs=0; for(int i=0;i<9;i++){ double s=wscore(mc.player.getInventory().getStack(i)); if(s>bs){ bs=s; best=i; } } if(best>=0) Util.sel(best); } }

  public static class BowSpam extends Module { Setting ticks=num("ChargeTicks",3,1,20,1); public BowSpam(){ super("BowSpam",Category.COMBAT); }
    public void onTick(){ if(mc.player.isUsingItem()&&mc.player.getActiveItem().isOf(Items.BOW)&&mc.player.getItemUseTime()>=ticks.i()) mc.interactionManager.stopUsingItem(mc.player); } }

  public static class BowAimbot extends Module { Setting range=num("Range",100,10,300,5); public BowAimbot(){ super("BowAimbot",Category.COMBAT); }
    public void onTick(){ if(!mc.player.isUsingItem()||!mc.player.getActiveItem().isOf(Items.BOW)) return; PlayerEntity t=nearestPlayer(range.d); if(t==null) return;
      double v=Math.max(0.3,BowItem.getPullProgress(mc.player.getItemUseTime())*3.0); Vec3d c=t.getBoundingBox().getCenter(); double dist=mc.player.getEyePos().distanceTo(c), tt=dist/v;
      Vec3d vel=t.getVelocity();
      Util.face(c.add(vel.multiply(tt)).add(0,0.5*0.05*tt*tt,0)); } }

  public static class ShieldBypass extends Module { public ShieldBypass(){ super("ShieldBypass",Category.COMBAT); }
    public void onTick(){ if(mc.crosshairTarget instanceof EntityHitResult r&&r.getEntity() instanceof LivingEntity le&&le.isBlocking()){ int s=Util.findHotbar(x->Registries.ITEM.getId(x.getItem()).getPath().endsWith("_axe")); if(s>=0) Util.sel(s); } } }

  public static class Criticals extends Module { public Criticals(){ super("Criticals",Category.COMBAT); } }

  public static class AutoMend extends Module { int t; public AutoMend(){ super("AutoMend",Category.COMBAT); }
    public void onTick(){ if(t-->0) return; boolean dmg=false; for(EquipmentSlot s:new EquipmentSlot[]{EquipmentSlot.HEAD,EquipmentSlot.CHEST,EquipmentSlot.LEGS,EquipmentSlot.FEET}) if(mc.player.getEquippedStack(s).isDamaged()) dmg=true;
      int s=Util.findHotbar(x->x.isOf(Items.EXPERIENCE_BOTTLE)); if(!dmg||s<0) return; int old=Util.sel(); Util.sel(s); mc.player.setPitch(90); mc.interactionManager.interactItem(mc.player,Hand.MAIN_HAND); Util.sel(old); t=2; } }

  public static class Offhand extends Module { Setting mode=num("Mode",0,0,3,1); public Offhand(){ super("Offhand",Category.COMBAT); }
    public void onTick(){ Item it=switch(mode.i()){ case 1->Items.GOLDEN_APPLE; case 2->Items.END_CRYSTAL; case 3->Items.SHIELD; default->Items.TOTEM_OF_UNDYING; };
      if(mc.player.getOffHandStack().isOf(it)) return; for(int i=0;i<36;i++) if(mc.player.getInventory().getStack(i).isOf(it)){ mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId,i<9?i+36:i,40,SlotActionType.SWAP,mc.player); return; } } }

  public static class Burrow extends Module { public Burrow(){ super("Burrow",Category.COMBAT); }
    public void onEnable(){ set(false); int slot=Util.findHotbar(s->s.isOf(Items.OBSIDIAN)); BlockPos pos=mc.player.getBlockPos(); if(slot<0||!mc.player.isOnGround()||!mc.world.getBlockState(pos).isReplaceable()) return;
      double x=mc.player.getX(),y=mc.player.getY(),z=mc.player.getZ(); for(double d:new double[]{0.41999998688698,0.7531999805212,1.00133597911214,1.16610926093821}) Util.send(new PlayerMoveC2SPacket.PositionAndOnGround(x,y+d,z,false,false));
      int old=Util.sel(); Util.sel(slot); Util.place(pos); Util.sel(old); } }

  public static class AutoCity extends Module { Setting range=num("Range",5,2,7,0.5); public AutoCity(){ super("AutoCity",Category.COMBAT); }
    public void onTick(){ PlayerEntity t=nearestPlayer(8); if(t==null) return; BlockPos best=null; double bd=1e9;
      for(Direction d:Direction.Type.HORIZONTAL){ BlockPos p=t.getBlockPos().offset(d); if(mc.world.getBlockState(p).getBlock()!=Blocks.OBSIDIAN) continue; double dd=mc.player.getEyePos().distanceTo(Vec3d.ofCenter(p)); if(dd<=range.d&&dd<bd){ bd=dd; best=p; } }
      if(best==null) return; int s=Util.findHotbar(x->Registries.ITEM.getId(x.getItem()).getPath().endsWith("_pickaxe")); if(s>=0) Util.sel(s);
      mc.interactionManager.updateBlockBreakingProgress(best,Direction.UP); mc.player.swingHand(Hand.MAIN_HAND); } }

  // ================= PLAYER =================
  public static class FastUse extends Module { public FastUse(){ super("FastUse",Category.PLAYER); }
    public void onTick(){ ((McAccessor)mc).abab$setItemUseCooldown(0); } }
  public static class AutoTool extends Module { public AutoTool(){ super("AutoTool",Category.PLAYER); }
    public void onTick(){ if(!mc.options.attackKey.isPressed()||!(mc.crosshairTarget instanceof BlockHitResult bh)||bh.getType()!=HitResult.Type.BLOCK) return;
      BlockState st=mc.world.getBlockState(bh.getBlockPos()); int best=-1; float bs=1f; for(int i=0;i<9;i++){ float sp=mc.player.getInventory().getStack(i).getMiningSpeedMultiplier(st); if(sp>bs){ bs=sp; best=i; } } if(best>=0) Util.sel(best); } }
  public static class AutoReplenish extends Module { Setting thr=num("Below",16,1,63,1); int t; public AutoReplenish(){ super("AutoReplenish",Category.PLAYER); }
    public void onTick(){ if(t-->0||mc.currentScreen!=null) return; var inv=mc.player.getInventory(); var im=mc.interactionManager; int id=mc.player.playerScreenHandler.syncId;
      for(int i=0;i<9;i++){ ItemStack h=inv.getStack(i); if(h.isEmpty()||!h.isStackable()||h.getCount()>thr.i()) continue;
        for(int j=9;j<36;j++){ ItemStack s=inv.getStack(j); if(!s.isEmpty()&&ItemStack.areItemsAndComponentsEqual(h,s)){ im.clickSlot(id,j,0,SlotActionType.PICKUP,mc.player); im.clickSlot(id,i+36,0,SlotActionType.PICKUP,mc.player);
          if(!mc.player.playerScreenHandler.getCursorStack().isEmpty()) im.clickSlot(id,j,0,SlotActionType.PICKUP,mc.player); t=4; return; } } } } }
  public static class AutoFish extends Module { int cd; boolean recast; public AutoFish(){ super("AutoFish",Category.PLAYER); }
    public void onTick(){ if(!mc.player.getMainHandStack().isOf(Items.FISHING_ROD)) return; if(cd>0){ cd--; return; } FishingBobberEntity h=mc.player.fishHook;
      if(h==null){ if(recast){ mc.interactionManager.interactItem(mc.player,Hand.MAIN_HAND); recast=false; cd=25; } }
      else if(h.isTouchingWater()&&h.getVelocity().y<-0.06){ mc.interactionManager.interactItem(mc.player,Hand.MAIN_HAND); recast=true; cd=25; } } }
  public static class MiddleClickExtra extends Module { boolean last; public MiddleClickExtra(){ super("MiddleClickExtra",Category.PLAYER); }
    public void onTick(){ boolean d=mc.currentScreen==null&&GLFW.glfwGetMouseButton(mc.getWindow().getHandle(),GLFW.GLFW_MOUSE_BUTTON_MIDDLE)==GLFW.GLFW_PRESS;
      if(d&&!last){ int s=Util.findHotbar(x->x.isOf(Items.ENDER_PEARL)); if(s>=0){ int old=Util.sel(); Util.sel(s); mc.interactionManager.interactItem(mc.player,Hand.MAIN_HAND); Util.sel(old); } } last=d; } }
  public static class AirPlace extends Module { Setting range=num("Range",4.5,2,10,0.5); int cd; public AirPlace(){ super("AirPlace",Category.PLAYER); }
    public void onTick(){ if(cd-->0||mc.currentScreen!=null||!mc.options.useKey.isPressed()||!(mc.player.getMainHandStack().getItem() instanceof BlockItem)||mc.crosshairTarget==null||mc.crosshairTarget.getType()!=HitResult.Type.MISS) return;
      Vec3d p=mc.player.getEyePos().add(mc.player.getRotationVec(1f).multiply(range.d)); BlockPos bp=BlockPos.ofFloored(p);
      mc.interactionManager.interactBlock(mc.player,Hand.MAIN_HAND,new BlockHitResult(Vec3d.ofCenter(bp),Direction.UP,bp,false)); mc.player.swingHand(Hand.MAIN_HAND); cd=4; } }
  public static class DeathCoords extends Module { boolean said; public DeathCoords(){ super("DeathCoords",Category.PLAYER); }
    public void onTick(){ if(mc.player.getHealth()<=0){ if(!said){ said=true; Util.msg("§cYou died at §f"+mc.player.getBlockX()+" "+mc.player.getBlockY()+" "+mc.player.getBlockZ()+" §7("+dim()+")"); } } else said=false; } }
  public static class AutoRespawn extends Module { public AutoRespawn(){ super("AutoRespawn",Category.PLAYER); }
    public void onTick(){ if(mc.currentScreen instanceof DeathScreen) mc.player.requestRespawn(); } }
  public static class SpeedMine extends Module { public SpeedMine(){ super("SpeedMine",Category.PLAYER); }
    public void onTick(){ ((ImAccessor)mc.interactionManager).abab$setBreakCd(0); } }
  public static class LiquidFiller extends Module { Setting r=num("Range",4,1,5,1); public LiquidFiller(){ super("LiquidFiller",Category.PLAYER); }
    public void onTick(){ int s=Util.findHotbar(x->x.getItem() instanceof BlockItem bi&&!(bi.getBlock() instanceof ShulkerBoxBlock)); if(s<0) return; BlockPos c=mc.player.getBlockPos(),best=null; double bd=1e9; int R=r.i();
      for(int x=-R;x<=R;x++) for(int y=-R;y<=R;y++) for(int z=-R;z<=R;z++){ BlockPos p=c.add(x,y,z); if(!mc.world.getFluidState(p).isStill()) continue; double d=c.getSquaredDistance(p); if(d<bd){ bd=d; best=p; } }
      if(best==null) return; int old=Util.sel(); Util.sel(s); Util.place(best); Util.sel(old); } }
  public static class ChestStealer extends Module { Setting delay=num("Delay",1,0,10,1); int t; public ChestStealer(){ super("ChestStealer",Category.PLAYER); }
    public void onTick(){ if(!(mc.currentScreen instanceof GenericContainerScreen gs)) return; if(t-->0) return; var h=gs.getScreenHandler(); int n=h.getRows()*9;
      for(int i=0;i<n;i++) if(!h.getSlot(i).getStack().isEmpty()){ mc.interactionManager.clickSlot(h.syncId,i,0,SlotActionType.QUICK_MOVE,mc.player); t=delay.i(); return; } } }
  public static class AutoClicker extends Module { public AutoClicker(){ super("AutoClicker",Category.PLAYER); }
    public void onTick(){ if(mc.currentScreen==null&&mc.options.attackKey.isPressed()&&mc.crosshairTarget instanceof EntityHitResult r&&mc.player.getAttackCooldownProgress(0)>=0.95f){ mc.interactionManager.attackEntity(mc.player,r.getEntity()); mc.player.swingHand(Hand.MAIN_HAND); } } }

  // ================= MOVEMENT =================
  public static class BoatFly extends Module { Setting sp=num("Speed",2,0.1,10,0.1), vs=num("Vertical",0.6,0.05,5,0.05); public BoatFly(){ super("BoatFly",Category.MOVEMENT); }
    public void onTick(){ Entity v=mc.player.getVehicle(); if(v==null) return; Vec3d d=inputDir(); v.setVelocity(d.x*sp.d,mc.options.jumpKey.isPressed()?vs.d:mc.options.sneakKey.isPressed()?-vs.d:0,d.z*sp.d); } }
  public static class EntitySpeed extends Module { Setting sp=num("Speed",1.5,0.1,10,0.1); public EntitySpeed(){ super("EntitySpeed",Category.MOVEMENT); }
    public void onTick(){ Entity v=mc.player.getVehicle(); if(v==null) return; Vec3d d=inputDir(); if(d.lengthSquared()==0) return; v.setVelocity(d.x*sp.d,v.getVelocity().y,d.z*sp.d); } }
  public static class ElytraFly extends Module { Setting sp=num("Speed",1.5,0.1,10,0.1); public ElytraFly(){ super("ElytraFly",Category.MOVEMENT); }
    public void onTick(){ String p=mc.player.getPose().name(); if(!(p.contains("FALL_FLYING")||p.contains("GLIDING"))) return; Vec3d l=mc.player.getRotationVec(1f);
      if(Util.fwd()>0) mc.player.setVelocity(l.multiply(sp.d)); else if(mc.options.sneakKey.isPressed()) mc.player.setVelocity(0,-0.5,0); else mc.player.setVelocity(0,0,0); } }
  public static class AirJump extends Module { boolean last; public AirJump(){ super("AirJump",Category.MOVEMENT); }
    public void onTick(){ boolean d=mc.options.jumpKey.isPressed(); if(d&&!last&&!mc.player.isOnGround()){ Vec3d v=mc.player.getVelocity(); mc.player.setVelocity(v.x,0.42,v.z); mc.player.fallDistance=0; } last=d; } }
  public static class AntiLevitation extends Module { public AntiLevitation(){ super("AntiLevitation",Category.MOVEMENT); } public void onTick(){ mc.player.removeStatusEffect(StatusEffects.LEVITATION); } }
  public static class FastClimb extends Module { Setting sp=num("Speed",0.3,0.1,5,0.05); public FastClimb(){ super("FastClimb",Category.MOVEMENT); }
    public void onTick(){ if(mc.player.isClimbing()&&(mc.player.horizontalCollision||mc.options.jumpKey.isPressed())){ Vec3d v=mc.player.getVelocity(); mc.player.setVelocity(v.x,sp.d,v.z); } } }
  public static class Follow extends Module { Setting range=num("Range",30,5,200,1), dist=num("Distance",2.5,1,10,0.5); public Follow(){ super("Follow",Category.MOVEMENT); }
    public void onTick(){ PlayerEntity t=nearestPlayer(range.d); if(t==null){ mc.options.forwardKey.setPressed(false); return; } Util.face(t.getEyePos()); mc.options.forwardKey.setPressed(mc.player.distanceTo(t)>dist.d); }
    public void onDisable(){ mc.options.forwardKey.setPressed(false); } }
  public static class LongJump extends Module { Setting boost=num("Boost",1.2,0.2,5,0.1); public LongJump(){ super("LongJump",Category.MOVEMENT); }
    boolean was; public void onTick(){ boolean g=mc.player.isOnGround(); /* vanilla jump() overwrites velocity, so boost on the first airborne tick */ if(was&&!g&&mc.options.jumpKey.isPressed()&&Util.moving()&&mc.player.getVelocity().y>0.1) Util.move(boost.d,mc.player.getVelocity().y); was=g; } }
  public static class ReverseStep extends Module { Setting h=num("Height",3,1,10,1); public ReverseStep(){ super("ReverseStep",Category.MOVEMENT); }
    public void onTick(){ Vec3d v=mc.player.getVelocity(); if(mc.player.isOnGround()||v.y>=0||v.y<-0.6||mc.player.isTouchingWater()) return; Box b=mc.player.getBoundingBox();
      for(int k=1;k<=h.i();k++) if(!mc.world.isSpaceEmpty(mc.player,b.offset(0,-k,0))){ mc.player.setVelocity(v.x,-1.0,v.z); return; } } }
  public static class SafeWalk extends Module { Setting depth=num("Depth",1.1,0.6,5,0.1); public SafeWalk(){ super("SafeWalk",Category.MOVEMENT); }
    public void onTick(){ if(!mc.player.isOnGround()||mc.player.isSneaking()) return; Vec3d d=inputDir().multiply(0.25); if(d.lengthSquared()==0) return;
      if(mc.world.isSpaceEmpty(mc.player,mc.player.getBoundingBox().offset(d.x,-depth.d,d.z))){ Vec3d v=mc.player.getVelocity(); mc.player.setVelocity(0,v.y,0); } } }
  public static class Strafe extends Module { public Strafe(){ super("Strafe",Category.MOVEMENT); }
    public void onTick(){ if(mc.player.isOnGround()||!Util.moving()) return; Vec3d v=mc.player.getVelocity(); Util.move(Math.max(0.2,Math.hypot(v.x,v.z)),v.y); } }
  public static class Parkour extends Module { public Parkour(){ super("Parkour",Category.MOVEMENT); }
    public void onTick(){ if(!mc.player.isOnGround()||mc.player.isSneaking()) return; Vec3d d=inputDir().multiply(0.3); if(d.lengthSquared()==0) return;
      if(mc.world.isSpaceEmpty(mc.player,mc.player.getBoundingBox().offset(d.x,-0.6,d.z))) mc.player.jump(); } }
  public static class ClickTP extends Module { Setting range=num("Range",100,5,200,5); public ClickTP(){ super("ClickTP",Category.MOVEMENT); }
    public void onEnable(){ set(false); HitResult h=mc.player.raycast(range.d,1f,false); if(!(h instanceof BlockHitResult b)||b.getType()!=HitResult.Type.BLOCK){ Util.msg("§cNo block in range"); return; }
      Vec3d t=b.getPos().add(new Vec3d(b.getSide().getOffsetX(),b.getSide().getOffsetY(),b.getSide().getOffsetZ()).multiply(0.35)); if(b.getSide()==Direction.DOWN) t=t.add(0,-1.8,0); tp(t); } }
  public static class AntiVoid extends Module { public AntiVoid(){ super("AntiVoid",Category.MOVEMENT); }
    public void onTick(){ if(mc.player.getY()<mc.world.getBottomY()+1&&!mc.player.isOnGround()) mc.player.setVelocity(0,0.6,0); } }
  public static class NoJumpDelay extends Module { public NoJumpDelay(){ super("NoJumpDelay",Category.MOVEMENT); } public void onTick(){ ((LeAccessor)mc.player).abab$setJumpCd(0); } }

  // ================= RENDER =================
  public static class Breadcrumbs extends Module { Setting max=num("MaxPoints",800,50,5000,50), c=color("Color",0xFFFF3B3B); final List<Vec3d> pts=new ArrayList<>(); public Breadcrumbs(){ super("Breadcrumbs",Category.RENDER); }
    public void onTick(){ Vec3d p=mc.player.getEntityPos(); if(pts.isEmpty()||pts.get(pts.size()-1).distanceTo(p)>0.3) pts.add(p); while(pts.size()>max.i()) pts.remove(0); }
    public void onRender(Matrix4f m,Vec3d cam,float td){ R.lines(m,pts,cam,c.c); } public void onDisable(){ pts.clear(); } }

  public record Wp(String name,double x,double y,double z,String dim){}
  static final List<Wp> WPS=new ArrayList<>();
  public static String wpSerialize(){ StringBuilder sb=new StringBuilder(); for(Wp w:WPS) sb.append(w.name().replace(';','_').replace(':','_')).append(':').append(w.x()).append(':').append(w.y()).append(':').append(w.z()).append(':').append(w.dim()).append(';'); return sb.toString(); }
  public static void wpLoad(String s){ WPS.clear(); for(String e:s.split(";")){ String[] p=e.split(":"); if(p.length==5) try{ WPS.add(new Wp(p[0],Double.parseDouble(p[1]),Double.parseDouble(p[2]),Double.parseDouble(p[3]),p[4])); }catch(Exception ig){} } }
  public static void wpCommand(String[] a){ String sub=a.length>1?a[1].toLowerCase():"list";
    switch(sub){
      case "add" -> { String n=a[2]; double x=Module.mc.player.getX(),y=Module.mc.player.getY(),z=Module.mc.player.getZ(); if(a.length>=6){ x=Double.parseDouble(a[3]); y=Double.parseDouble(a[4]); z=Double.parseDouble(a[5]); }
        WPS.add(new Wp(n,x,y,z,dim())); Util.msg("Waypoint §f"+n+" §7added"); }
      case "del" -> { WPS.removeIf(w->w.name().equalsIgnoreCase(a[2])); Util.msg("Removed"); }
      case "clear" -> { WPS.clear(); Util.msg("Cleared"); }
      default -> { for(Wp w:WPS) Util.msg("§c"+w.name()+" §7"+(int)w.x()+" "+(int)w.y()+" "+(int)w.z()+" ("+w.dim()+")"); } } }
  public static class Waypoints extends Module { Setting tr=bool("Tracers",true), c=color("Color",0xFF3BC8FF); public Waypoints(){ super("Waypoints",Category.RENDER); on=true; }
    public void onRender(Matrix4f m,Vec3d cam,float td){ Vec3d st=mc.player.getRotationVec(td).multiply(0.6); for(Wp w:WPS){ if(!w.dim().equals(dim())) continue;
        Box b=new Box(w.x()-0.4,w.y(),w.z()-0.4,w.x()+0.4,w.y()+1.8,w.z()+0.4).offset(-cam.x,-cam.y,-cam.z); R.box(m,b,(50<<24)|(c.c&0xFFFFFF),c.c); if(tr.b) R.line(m,st,b.getCenter(),c.c); } }
    public void onHud(DrawContext g,float td){ for(Wp w:WPS){ if(!w.dim().equals(dim())) continue; Vec3d p=AbabClient.project(new Vec3d(w.x(),w.y()+2.2,w.z())); if(p==null) continue;
        String s=w.name()+" §7"+(int)mc.player.getEntityPos().distanceTo(new Vec3d(w.x(),w.y(),w.z()))+"m"; g.drawCenteredTextWithShadow(mc.textRenderer,s,(int)p.x,(int)p.y,0xFFFFFFFF); } } }

  public static class LogoutSpots extends Module { record Rec(String name,Box box,double dist){}
    final Map<UUID,Rec> cur=new HashMap<>(), spots=new HashMap<>(); Object lastWorld; public LogoutSpots(){ super("LogoutSpots",Category.RENDER); }
    public void onTick(){ if(lastWorld!=mc.world){ lastWorld=mc.world; cur.clear(); spots.clear(); } Set<UUID> now=new HashSet<>();
      for(PlayerEntity p:mc.world.getPlayers()){ if(p==mc.player) continue; now.add(p.getUuid()); cur.put(p.getUuid(),new Rec(p.getName().getString(),p.getBoundingBox(),mc.player.distanceTo(p))); spots.remove(p.getUuid()); }
      Iterator<Map.Entry<UUID,Rec>> it=cur.entrySet().iterator(); while(it.hasNext()){ var e=it.next(); if(!now.contains(e.getKey())){ if(e.getValue().dist()<=48) spots.put(e.getKey(),e.getValue()); it.remove(); } } }
    public void onRender(Matrix4f m,Vec3d cam,float td){ for(Rec r:spots.values()) R.box(m,r.box().offset(-cam.x,-cam.y,-cam.z),0x40FFAA00,0xFFFFAA00); }
    public void onHud(DrawContext g,float td){ for(Rec r:spots.values()){ Vec3d c=r.box().getCenter(); Vec3d p=AbabClient.project(new Vec3d(c.x,r.box().maxY+0.3,c.z)); if(p!=null) g.drawCenteredTextWithShadow(mc.textRenderer,"§e"+r.name()+" §7logged out "+(int)c.x+" "+(int)c.z,(int)p.x,(int)p.y,0xFFFFFFFF); } }
    public void onDisable(){ cur.clear(); spots.clear(); } }

  public static class Trajectories extends Module { Setting c=color("Color",0xFFFFE23B); public Trajectories(){ super("Trajectories",Category.RENDER); }
    public void onRender(Matrix4f m,Vec3d cam,float td){ ItemStack s=mc.player.getMainHandStack(); double v,g;
      if(s.isOf(Items.BOW)&&mc.player.isUsingItem()){ v=BowItem.getPullProgress(mc.player.getItemUseTime())*3.0; g=0.05; }
      else if(s.isOf(Items.CROSSBOW)&&CrossbowItem.isCharged(s)){ v=3.15; g=0.05; }
      else if(s.isOf(Items.ENDER_PEARL)||s.isOf(Items.SNOWBALL)||s.isOf(Items.EGG)){ v=1.5; g=0.03; } else return;
      Vec3d pos=mc.player.getEyePos().subtract(0,0.1,0), vel=mc.player.getRotationVec(td).multiply(v);
      for(int i=0;i<150;i++){ Vec3d next=pos.add(vel); BlockHitResult r=mc.world.raycast(new RaycastContext(pos,next,RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,mc.player));
        if(r.getType()!=HitResult.Type.MISS){ next=r.getPos(); R.line(m,pos.subtract(cam),next.subtract(cam),c.c); R.box(m,new Box(next.x-0.15,next.y-0.15,next.z-0.15,next.x+0.15,next.y+0.15,next.z+0.15).offset(-cam.x,-cam.y,-cam.z),0x60FFFFFF,c.c); break; }
        R.line(m,pos.subtract(cam),next.subtract(cam),c.c); pos=next; vel=vel.multiply(0.99).subtract(0,g,0); } } }

  public static class Zoom extends Module { Setting f=num("FOV",30,30,110,1); int old=-1; public Zoom(){ super("Zoom",Category.RENDER); }
    public void onEnable(){ old=mc.options.getFov().getValue(); } public void onTick(){ mc.options.getFov().setValue(f.i()); } public void onDisable(){ if(old>0) mc.options.getFov().setValue(old); } }
  public static class NoBob extends Module { boolean old=true; public NoBob(){ super("NoBob",Category.RENDER); }
    public void onEnable(){ old=mc.options.getBobView().getValue(); } public void onTick(){ mc.options.getBobView().setValue(false); } public void onDisable(){ mc.options.getBobView().setValue(old); } }
  public static class CityEsp extends Module { Setting c=color("Color",0xFFFF9A1F); public CityEsp(){ super("CityESP",Category.RENDER); }
    public void onRender(Matrix4f m,Vec3d cam,float td){ for(PlayerEntity p:mc.world.getPlayers()){ if(p==mc.player||mc.player.distanceTo(p)>24) continue;
        for(Direction d:Direction.Type.HORIZONTAL){ BlockPos b=p.getBlockPos().offset(d); if(mc.world.getBlockState(b).getBlock()!=Blocks.OBSIDIAN) continue; R.box(m,new Box(b).offset(-cam.x,-cam.y,-cam.z),(70<<24)|(c.c&0xFFFFFF),c.c); } } } }
  public static class CustomCrosshair extends Module { Setting c=color("Color",0xFFFFFFFF), size=num("Size",6,1,40,1), gap=num("Gap",3,0,20,1), th=num("Thickness",1,1,5,1), dot=bool("Dot",true); public CustomCrosshair(){ super("CustomCrosshair",Category.RENDER); }
    public void onHud(DrawContext g,float td){ int cx=mc.getWindow().getScaledWidth()/2,cy=mc.getWindow().getScaledHeight()/2,s=size.i(),gp=gap.i(),t=th.i(),h=t/2;
      g.fill(cx-gp-s,cy-h,cx-gp,cy-h+t,c.c); g.fill(cx+gp,cy-h,cx+gp+s,cy-h+t,c.c); g.fill(cx-h,cy-gp-s,cx-h+t,cy-gp,c.c); g.fill(cx-h,cy+gp,cx-h+t,cy+gp+s,c.c); if(dot.b) g.fill(cx-h,cy-h,cx-h+t,cy-h+t,c.c); } }
  public static class Coords extends Module { Setting x=num("X%",1,0,95,1), y=num("Y%",88,0,97,1); public Coords(){ super("Coords",Category.RENDER); on=true; }
    public void onHud(DrawContext g,float td){ int w=mc.getWindow().getScaledWidth(),h=mc.getWindow().getScaledHeight(); int X=px(x,w),Y=px(y,h); String d=dim(); double bx=mc.player.getX(),bz=mc.player.getZ();
      String other=d.equals("the_nether")?"§7Overworld §f"+(int)(bx*8)+" "+(int)(bz*8):d.equals("overworld")?"§7Nether §f"+(int)(bx/8)+" "+(int)(bz/8):"";
      var e=mc.getNetworkHandler()!=null?mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()):null; String ping=e!=null?" §7| §f"+e.getLatency()+"ms":"";
      g.drawTextWithShadow(mc.textRenderer,"§cXYZ §f"+(int)bx+" "+(int)mc.player.getY()+" "+(int)bz+" §7"+mc.player.getHorizontalFacing().asString()+ping,X,Y,0xFFFFFFFF); if(!other.isEmpty()) g.drawTextWithShadow(mc.textRenderer,other,X,Y+10,0xFFFFFFFF); } }
  public static class TargetHud extends Module { Setting range=num("Range",12,3,60,1); public TargetHud(){ super("TargetHUD",Category.RENDER); }
    public void onHud(DrawContext g,float td){ PlayerEntity t=nearestPlayer(range.d); if(t==null) return; TextRenderer tr=mc.textRenderer; int x=mc.getWindow().getScaledWidth()/2+40,y=mc.getWindow().getScaledHeight()/2+20;
      g.fill(x,y,x+112,y+52,0xAA000000); g.fill(x,y,x+2,y+52,Hud.RED); g.drawTextWithShadow(tr,t.getName().getString()+" §7"+(int)mc.player.distanceTo(t)+"m",x+6,y+4,0xFFFFFFFF);
      float hp=t.getHealth()+t.getAbsorptionAmount(); g.fill(x+6,y+16,x+106,y+22,0xFF222222); g.fill(x+6,y+16,x+6+(int)(100*Math.min(1f,hp/t.getMaxHealth())),y+22,hp>14?0xFF3BFF6A:hp>7?0xFFFFE23B:0xFFFF3B3B);
      g.drawTextWithShadow(tr,"§c♥ §f"+(int)Math.ceil(hp),x+6,y+25,0xFFFFFFFF);
      EquipmentSlot[] sl={EquipmentSlot.HEAD,EquipmentSlot.CHEST,EquipmentSlot.LEGS,EquipmentSlot.FEET,EquipmentSlot.MAINHAND}; for(int i=0;i<sl.length;i++){ ItemStack s=t.getEquippedStack(sl[i]); if(!s.isEmpty()) g.drawItem(s,x+4+i*21,y+34); } } }
  public static class Radar extends Module { Setting size=num("Size",90,40,200,5), range=num("Range",40,10,200,5), x=num("X%",98,0,100,1), y=num("Y%",30,0,95,1), pl=bool("Players",true), ho=bool("Hostile",true), an=bool("Animals",false); public Radar(){ super("Radar",Category.RENDER); }
    public void onHud(DrawContext g,float td){ int S=size.i(),w=mc.getWindow().getScaledWidth(),h=mc.getWindow().getScaledHeight(),X=px(x,w)-S,Y=px(y,h),cx=X+S/2,cy=Y+S/2; if(X<0) X=0;
      g.fill(X,Y,X+S,Y+S,0x99000000); g.fill(X,Y,X+S,Y+1,Hud.RED); g.fill(X,Y+S-1,X+S,Y+S,Hud.RED); g.fill(X,Y,X+1,Y+S,Hud.RED); g.fill(X+S-1,Y,X+S,Y+S,Hud.RED); g.fill(cx-1,cy-1,cx+2,cy+2,0xFFFFFFFF);
      double yaw=Math.toRadians(mc.player.getYaw()),sc=(S/2.0)/range.d,fx=-Math.sin(yaw),fz=Math.cos(yaw),rx=-Math.cos(yaw),rz=-Math.sin(yaw);
      for(Entity e:mc.world.getEntities()){ if(e==mc.player) continue; int c=Util.cat(e); if(!(c==0&&pl.b||c==1&&ho.b||c==2&&an.b)) continue; double dx=e.getX()-mc.player.getX(),dz=e.getZ()-mc.player.getZ();
        int sx=cx+(int)((dx*rx+dz*rz)*sc),sy=cy-(int)((dx*fx+dz*fz)*sc); if(sx<X+2||sx>X+S-3||sy<Y+2||sy>Y+S-3) continue; g.fill(sx-1,sy-1,sx+2,sy+2,c==0?0xFFFF3B3B:c==1?0xFFFF9A1F:0xFF3BFF6A); } } }
  public static class Counters extends Module { Setting x=num("X%",1,0,95,1), y=num("Y%",30,0,90,1); static Item[] IT; public Counters(){ super("Counters",Category.RENDER); }
    public void onHud(DrawContext g,float td){ if(IT==null) IT=new Item[]{Items.TOTEM_OF_UNDYING,Items.END_CRYSTAL,Items.EXPERIENCE_BOTTLE,Items.GOLDEN_APPLE,Items.OBSIDIAN,Items.ENDER_PEARL};
      int X=px(x,mc.getWindow().getScaledWidth()),Y=px(y,mc.getWindow().getScaledHeight()); for(int i=0;i<IT.length;i++){ int n=0; for(int k=0;k<mc.player.getInventory().size();k++){ ItemStack s=mc.player.getInventory().getStack(k); if(s.isOf(IT[i])) n+=s.getCount(); }
        g.drawItem(new ItemStack(IT[i]),X,Y+i*18); g.drawTextWithShadow(mc.textRenderer,"x"+n,X+20,Y+i*18+4,n==0?0xFFFF5555:0xFFFFFFFF); } } }

  // ================= WORLD / MISC =================
  public static class AutoShearer extends Module { int cd; public AutoShearer(){ super("AutoShearer",Category.WORLD); }
    public void onTick(){ if(cd-->0) return; int s=Util.findHotbar(x->x.isOf(Items.SHEARS)); if(s<0) return;
      for(Entity e:mc.world.getEntities()) if(e instanceof SheepEntity sh&&!sh.isSheared()&&!sh.isBaby()&&mc.player.distanceTo(sh)<=4){ Util.sel(s); mc.interactionManager.interactEntity(mc.player,sh,Hand.MAIN_HAND); mc.player.swingHand(Hand.MAIN_HAND); cd=5; return; } } }
  public static class AutoMount extends Module { int cd; public AutoMount(){ super("AutoMount",Category.WORLD); }
    public void onTick(){ if(cd-->0||mc.player.hasVehicle()) return; for(Entity e:mc.world.getEntities()) if((e instanceof VehicleEntity||e instanceof AbstractHorseEntity||e.getType()==EntityType.PIG||e.getType()==EntityType.STRIDER)&&mc.player.distanceTo(e)<=3.5){ mc.interactionManager.interactEntity(mc.player,e,Hand.MAIN_HAND); cd=20; return; } } }
  public static class AutoBreed extends Module { int cd; public AutoBreed(){ super("AutoBreed",Category.WORLD); }
    public void onTick(){ if(cd-->0) return; for(Entity e:mc.world.getEntities()) if(e instanceof AnimalEntity a&&!a.isBaby()&&!a.isInLove()&&a.getBreedingAge()==0&&mc.player.distanceTo(a)<=4){
        int s=Util.findHotbar(x->a.isBreedingItem(x)); if(s<0) continue; Util.sel(s); mc.interactionManager.interactEntity(mc.player,a,Hand.MAIN_HAND); mc.player.swingHand(Hand.MAIN_HAND); cd=5; return; } } }
  public static class AutoNametag extends Module { int cd; public AutoNametag(){ super("AutoNametag",Category.WORLD); }
    public void onTick(){ if(cd-->0) return; int s=Util.findHotbar(x->x.isOf(Items.NAME_TAG)&&x.contains(DataComponentTypes.CUSTOM_NAME)); if(s<0) return;
      for(Entity e:mc.world.getEntities()) if(e instanceof LivingEntity&&!(e instanceof PlayerEntity)&&!e.hasCustomName()&&mc.player.distanceTo(e)<=4){ Util.sel(s); mc.interactionManager.interactEntity(mc.player,e,Hand.MAIN_HAND); cd=10; return; } } }
  public static class PlayerLog extends Module { Setting r=num("Range",25,5,200,1); public PlayerLog(){ super("PlayerLog",Category.COMBAT); }
    public void onTick(){ if(nearestPlayer(r.d)!=null){ mc.player.networkHandler.getConnection().disconnect(Text.literal("[АБАБ] PlayerLog: player in range")); set(false); } } }
  public static class VisualRange extends Module { final Set<UUID> known=new HashSet<>(); Object lastWorld; public VisualRange(){ super("VisualRange",Category.WORLD); }
    public void onTick(){ boolean first=lastWorld!=mc.world; if(first){ lastWorld=mc.world; known.clear(); } Set<UUID> now=new HashSet<>();
      for(PlayerEntity p:mc.world.getPlayers()){ if(p==mc.player) continue; now.add(p.getUuid()); if(known.add(p.getUuid())&&!first) Util.msg("§c"+p.getName().getString()+" §7entered visual range §f"+(int)p.getX()+" "+(int)p.getZ()); }
      for(UUID u:new ArrayList<>(known)) if(!now.contains(u)){ known.remove(u); var e=mc.getNetworkHandler().getPlayerListEntry(u); Util.msg("§7"+(e!=null?e.getProfile().name():"player")+" left visual range"); } } }
}
