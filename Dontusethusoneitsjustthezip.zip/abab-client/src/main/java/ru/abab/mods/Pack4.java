package ru.abab.mods;
import java.util.*;
import java.util.function.Predicate;
import net.minecraft.block.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.*;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.registry.Registries;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.*;
import net.minecraft.util.math.*;
import net.minecraft.world.LightType;
import org.joml.Matrix4f;
import ru.abab.AbabClient;
import ru.abab.core.Module;
import ru.abab.core.*;
import ru.abab.gui.BlockPicker;

/** Batch 4 (modules from Meteor / Wurst / Krypton lists that can be done without new mixins). */
public final class Pack4 {
  static XRay XR; static Blink BL;
  public static void register(List<Module> l){
    XR=new XRay(); BL=new Blink(); AKB=new AntiKnockback();
    l.addAll(List.of(XR,BL,AKB,new AimAssist(),new AutoWeb(),new HoleFiller(),new AutoMace(),new WindChargeKey(),new NoSlow(),new AutoMine(),new AutoFarm(),new BonemealAura(),new AntiBlind(),new LightOverlay()));
    l.add(new BlockFinder("BarrierESP",0xFFFF3B3B,s->s.isOf(Blocks.BARRIER)));
    l.add(new BlockFinder("SpawnerESP",0xFF3BC8FF,s->s.isOf(Blocks.SPAWNER)));
    l.add(new BlockFinder("TrialSpawnerESP",0xFFFF9A1F,s->s.isOf(Blocks.TRIAL_SPAWNER)));
    l.add(new BlockFinder("BedESP",0xFFFF6AD5,s->s.getBlock() instanceof BedBlock));
    l.add(new EntityFinder("PearlESP",0xFF3BC8FF,e->e.getType()==EntityType.ENDER_PEARL));
    l.add(new EntityFinder("TridentESP",0xFF3BFF6A,e->e.getType()==EntityType.TRIDENT));
    l.add(new EntityFinder("WardenESP",0xFFFF3B3B,e->e.getType()==EntityType.WARDEN));
    l.add(new EntityFinder("CrystalESP",0xFFFF6AD5,e->e.getType()==EntityType.END_CRYSTAL));
    l.add(new EntityFinder("ItemESP",0xFFFFFFFF,e->e instanceof ItemEntity));
  }
  public static boolean blinkActive(){ return Blink.active; }
  static AntiKnockback AKB;
  /** true -> the server's knockback packet for you is dropped (both percents 0) */
  public static boolean cancelKnockback(){ return AKB!=null&&AKB.on&&AKB.h.d<=0&&AKB.v.d<=0; }
  public static void reset(){ Blink.active=false; if(BL!=null) BL.on=false; Pack5.reset(); }
  public static java.util.Set<Block> xraySet(){ return XR.blocks; }
  public static List<String> xrayNames(){ List<String> l=new ArrayList<>(); if(XR!=null) for(Block b:XR.blocks) l.add(Registries.BLOCK.getId(b).getPath()); return l; }
  public static void xrayLoad(String csv){ XR.blocks.clear(); for(String n:csv.split(",")){ if(n.isBlank()) continue; Block b=Registries.BLOCK.get(Identifier.tryParse("minecraft:"+n.trim())); if(b!=Blocks.AIR) XR.blocks.add(b); } }

  // ===== XRay (see-through-walls version): highlights the chosen blocks through the terrain. Pick blocks in the GUI. =====
  public static class XRay extends Module {
    public final Set<Block> blocks=new LinkedHashSet<>();
    Setting radius=num("Radius",20,4,32,2), maxN=num("MaxDraw",300,20,1500,10), fill=num("FillAlpha",70,0,255,5), multi=bool("ColorPerBlock",true), tracer=bool("Tracers",true), pre=bool("OnlySusChunks",false);
    final List<BlockPos> found=new ArrayList<>(); final List<Integer> cols=new ArrayList<>(); int t;
    public XRay(){ super("XRay",Category.RENDER); BlockPicker.addOres(blocks); }
    public void onDisable(){ found.clear(); cols.clear(); }
    public void onTick(){ if(t++%20!=0) return; found.clear(); cols.clear(); if(blocks.isEmpty()) return; BlockPos c=mc.player.getBlockPos(); int r=radius.i(); BlockPos.Mutable mp=new BlockPos.Mutable(); List<BlockPos> tmp=new ArrayList<>();
      for(int x=-r;x<=r;x++) for(int y=-r;y<=r;y++) for(int z=-r;z<=r;z++){ mp.set(c.getX()+x,c.getY()+y,c.getZ()+z); if(blocks.contains(mc.world.getBlockState(mp).getBlock())){ if(pre.b&&!Pack7.flagged(mp.getX()>>4,mp.getZ()>>4)) continue; tmp.add(mp.toImmutable()); if(tmp.size()>8000) break; } }
      tmp.sort(Comparator.comparingDouble(p->p.getSquaredDistance(c)));
      for(int i=0;i<Math.min(tmp.size(),maxN.i());i++){ BlockPos p=tmp.get(i); found.add(p); int h=Registries.BLOCK.getId(mc.world.getBlockState(p).getBlock()).hashCode(); cols.add(multi.b?R.hsb((Math.abs(h)%360)/360f,0.8f,1f):0xFF3BC8FF); } }
    public void onRender(Matrix4f m,Vec3d cam,float td){ for(int i=0;i<found.size();i++){ BlockPos p=found.get(i); int col=cols.get(i); Box b=new Box(p).offset(-cam.x,-cam.y,-cam.z);
      if(AbabClient.visible(b.getCenter(),1.5)) R.box(m,b,(fill.i()<<24)|(col&0xFFFFFF),col); if(tracer.b) R.tracer(b.getCenter(),col,false); } }
  }

  public static class AimAssist extends Module {
    Setting range=num("Range",5,2,8,0.5), smooth=num("Smooth",6,1,30,0.5), fov=num("FOV",70,5,180,5), onlyAtk=bool("OnlyWhileAttack",true);
    public AimAssist(){ super("AimAssist",Category.COMBAT); }
    public void onTick(){ if(mc.currentScreen!=null||(onlyAtk.b&&!mc.options.attackKey.isPressed())) return;
      PlayerEntity best=null; double ba=fov.d; Vec3d eye=mc.player.getEyePos(), look=mc.player.getRotationVec(1f);
      for(PlayerEntity p:mc.world.getPlayers()){ if(p==mc.player||!p.isAlive()||p.isSpectator()||mc.player.distanceTo(p)>range.d) continue; Vec3d d=p.getBoundingBox().getCenter().subtract(eye);
        double a=Math.toDegrees(Math.acos(Math.max(-1,Math.min(1,look.dotProduct(d.normalize()))))); if(a<ba){ ba=a; best=p; } }
      if(best==null) return; Vec3d d=best.getBoundingBox().getCenter().subtract(eye);
      float ty=(float)(Math.toDegrees(Math.atan2(d.z,d.x))-90), tp=(float)-Math.toDegrees(Math.atan2(d.y,Math.hypot(d.x,d.z)));
      mc.player.setYaw(mc.player.getYaw()+MathHelper.wrapDegrees(ty-mc.player.getYaw())/(float)smooth.d); mc.player.setPitch(mc.player.getPitch()+(tp-mc.player.getPitch())/(float)smooth.d); }
  }

  public static class AutoWeb extends Module {
    Setting range=num("Range",5,2,8,0.5);
    public AutoWeb(){ super("AutoWeb",Category.COMBAT); }
    public void onTick(){ int slot=Util.findHotbar(s->s.isOf(Items.COBWEB)); PlayerEntity t=Pack2.nearestPlayer(range.d); if(slot<0||t==null) return; int old=Util.sel();
      for(BlockPos p:new BlockPos[]{t.getBlockPos(),t.getBlockPos().up()}) if(Pack2.free(p)){ Util.sel(slot); Util.place(p); }
      Util.sel(old); }
  }

  public static class HoleFiller extends Module {
    Setting r=num("Range",4,2,6,1), per=num("PerTick",2,1,4,1);
    public HoleFiller(){ super("HoleFiller",Category.COMBAT); }
    static boolean hole(BlockPos p){ var w=mc.world; if(!w.getBlockState(p).isAir()||!w.getBlockState(p.up()).isAir()||w.getBlockState(p.down()).isAir()) return false;
      for(Direction d:Direction.Type.HORIZONTAL) if(w.getBlockState(p.offset(d)).isReplaceable()) return false; return true; }
    public void onTick(){ int slot=Util.findHotbar(s->s.getItem() instanceof BlockItem bi&&bi.getBlock()==Blocks.OBSIDIAN); if(slot<0) return; BlockPos c=mc.player.getBlockPos(); int old=Util.sel(), n=0, rr=r.i();
      outer: for(int x=-rr;x<=rr;x++) for(int y=-1;y<=1;y++) for(int z=-rr;z<=rr;z++){ BlockPos p=c.add(x,y,z); if(p.equals(c)||!hole(p)||!Pack2.free(p)) continue; Util.sel(slot); if(Util.place(p)&&++n>=per.i()) break outer; }
      Util.sel(old); }
  }

  public static class AutoMace extends Module {
    Setting range=num("Range",5,2,6,0.5);
    public AutoMace(){ super("AutoMace",Category.COMBAT); }
    public void onTick(){ if(mc.player.fallDistance<1.5) return; int s=Util.findHotbar(x->x.isOf(Items.MACE)); if(s<0) return; PlayerEntity t=Pack2.nearestPlayer(range.d); if(t==null) return;
      Util.sel(s); mc.interactionManager.attackEntity(mc.player,t); mc.player.swingHand(Hand.MAIN_HAND); }
  }

  public static class WindChargeKey extends Module {
    public WindChargeKey(){ super("WindChargeKey",Category.MOVEMENT); }
    public void onEnable(){ set(false); int s=Util.findHotbar(x->x.isOf(Items.WIND_CHARGE)); if(s<0){ Util.msg("§eNo wind charge in hotbar"); return; }
      int old=Util.sel(); float pit=mc.player.getPitch(); Util.sel(s); mc.player.setPitch(90); mc.interactionManager.interactItem(mc.player,Hand.MAIN_HAND); mc.player.setPitch(pit); Util.sel(old); }
  }

  public static class AntiKnockback extends Module { // drops the server knockback packet (NetMixin) + client-side scaling
    Setting h=num("Horizontal%",0,0,100,5), v=num("Vertical%",0,0,100,5);
    public AntiKnockback(){ super("AntiKnockback",Category.COMBAT); }
    public void onTick(){ if(mc.player.hurtTime>=9){ Vec3d d=mc.player.getVelocity(); mc.player.setVelocity(d.x*h.d/100,d.y*v.d/100,d.z*h.d/100); } }
  }

  public static class NoSlow extends Module {
    public NoSlow(){ super("NoSlow",Category.MOVEMENT); }
    public void onTick(){ if(mc.player.isUsingItem()&&!mc.player.hasVehicle()&&Util.moving()) Util.move(mc.player.isSprinting()?0.28:0.22,mc.player.getVelocity().y); }
  }

  public static class AutoMine extends Module {
    public AutoMine(){ super("AutoMine",Category.WORLD); }
    public void onTick(){ mc.options.attackKey.setPressed(mc.currentScreen==null&&mc.crosshairTarget instanceof BlockHitResult bh&&bh.getType()==HitResult.Type.BLOCK); }
    public void onDisable(){ mc.options.attackKey.setPressed(false); }
  }

  public static class AutoFarm extends Module {
    Setting r=num("Range",4,1,5,1);
    public AutoFarm(){ super("AutoFarm",Category.WORLD); }
    public void onTick(){ BlockPos c=mc.player.getBlockPos(), best=null; double bd=1e9; int rr=r.i(); Vec3d eye=mc.player.getEyePos();
      for(int x=-rr;x<=rr;x++) for(int y=-2;y<=2;y++) for(int z=-rr;z<=rr;z++){ BlockPos p=c.add(x,y,z); BlockState s=mc.world.getBlockState(p);
        if(s.getBlock() instanceof CropBlock cb&&cb.isMature(s)){ double d=Vec3d.ofCenter(p).distanceTo(eye); if(d<=r.d+1&&d<bd){ bd=d; best=p; } } }
      if(best!=null){ mc.interactionManager.updateBlockBreakingProgress(best,Direction.UP); mc.player.swingHand(Hand.MAIN_HAND); } }
  }

  public static class BonemealAura extends Module {
    Setting r=num("Range",4,1,5,1); int cd;
    public BonemealAura(){ super("BonemealAura",Category.WORLD); }
    public void onTick(){ if(cd-->0) return; int slot=Util.findHotbar(s->s.isOf(Items.BONE_MEAL)); if(slot<0) return; BlockPos c=mc.player.getBlockPos(), best=null; double bd=1e9; int rr=r.i(); Vec3d eye=mc.player.getEyePos();
      for(int x=-rr;x<=rr;x++) for(int y=-2;y<=2;y++) for(int z=-rr;z<=rr;z++){ BlockPos p=c.add(x,y,z); BlockState s=mc.world.getBlockState(p);
        if(s.getBlock() instanceof CropBlock cb&&!cb.isMature(s)){ double d=Vec3d.ofCenter(p).distanceTo(eye); if(d<=r.d+1&&d<bd){ bd=d; best=p; } } }
      if(best==null) return; int old=Util.sel(); Util.sel(slot);
      mc.interactionManager.interactBlock(mc.player,Hand.MAIN_HAND,new BlockHitResult(Vec3d.ofCenter(best),Direction.UP,best,false)); Util.sel(old); cd=2; }
  }

  public static class AntiBlind extends Module {
    public AntiBlind(){ super("AntiBlind",Category.PLAYER); }
    public void onTick(){ mc.player.removeStatusEffect(StatusEffects.BLINDNESS); mc.player.removeStatusEffect(StatusEffects.DARKNESS); mc.player.removeStatusEffect(StatusEffects.NAUSEA); }
  }

  // ===== Blink: your movement packets are held while it is ON; turning it OFF sends you to where you really are (in safe steps) =====
  public static class Blink extends Module {
    static boolean active; static Vec3d start;
    public Blink(){ super("Blink",Category.MOVEMENT); }
    public void onEnable(){ active=true; start=mc.player.getEntityPos(); }
    public void onDisable(){ active=false; if(start==null) return; Vec3d to=mc.player.getEntityPos(); Extra.SpearKill.pk(start,to,mc.player.isOnGround()); start=null; }
  }

  public static class LightOverlay extends Module {
    Setting radius=num("Radius",8,3,16,1); final List<BlockPos> l=new ArrayList<>(); int t;
    public LightOverlay(){ super("LightOverlay",Category.RENDER); }
    public void onDisable(){ l.clear(); }
    public void onTick(){ if(t++%10!=0) return; l.clear(); BlockPos c=mc.player.getBlockPos(); int r=radius.i();
      for(int x=-r;x<=r;x++) for(int z=-r;z<=r;z++) for(int y=-3;y<=3;y++){ BlockPos p=c.add(x,y,z); if(!mc.world.getBlockState(p).isAir()) continue; if(!mc.world.getBlockState(p.down()).isOpaque()) continue;
        if(mc.world.getLightLevel(LightType.BLOCK,p)==0){ l.add(p); if(l.size()>1500) return; } } }
    public void onRender(Matrix4f m,Vec3d cam,float td){ for(BlockPos p:l) R.box(m,new Box(p.getX(),p.getY(),p.getZ(),p.getX()+1,p.getY()+0.05,p.getZ()+1).offset(-cam.x,-cam.y,-cam.z),0x40FF2020,0xFFFF2020); }
  }

  // ===== generic finders: BarrierESP, SpawnerESP, TrialSpawnerESP, BedESP / PearlESP, TridentESP, WardenESP, CrystalESP, ItemESP =====
  public static class BlockFinder extends Module {
    final Predicate<BlockState> test; Setting radius=num("Radius",16,4,32,2), maxN=num("MaxDraw",150,10,600,10), fill=num("FillAlpha",50,0,255,5), tracer=bool("Tracers",true), pre=bool("OnlySusChunks",false), col;
    final List<BlockPos> found=new ArrayList<>(); int t;
    public BlockFinder(String n,int c,Predicate<BlockState> p){ super(n,Category.RENDER); test=p; col=color("Color",c); }
    public void onDisable(){ found.clear(); }
    public void onTick(){ if(t++%20!=0) return; found.clear(); BlockPos c=mc.player.getBlockPos(); int r=radius.i(); BlockPos.Mutable mp=new BlockPos.Mutable(); List<BlockPos> tmp=new ArrayList<>();
      for(int x=-r;x<=r;x++) for(int y=-r;y<=r;y++) for(int z=-r;z<=r;z++){ mp.set(c.getX()+x,c.getY()+y,c.getZ()+z); if(test.test(mc.world.getBlockState(mp))){ if(pre.b&&!Pack7.flagged(mp.getX()>>4,mp.getZ()>>4)) continue; tmp.add(mp.toImmutable()); if(tmp.size()>3000) break; } }
      tmp.sort(Comparator.comparingDouble(p->p.getSquaredDistance(c))); for(int i=0;i<Math.min(tmp.size(),maxN.i());i++) found.add(tmp.get(i)); }
    public void onRender(Matrix4f m,Vec3d cam,float td){ int cc=col.c; for(BlockPos p:found){ Box b=new Box(p).offset(-cam.x,-cam.y,-cam.z); R.box(m,b,(fill.i()<<24)|(cc&0xFFFFFF),cc); if(tracer.b) R.tracer(b.getCenter(),cc,false); } }
  }

  public static class EntityFinder extends Module {
    final Predicate<Entity> test; Setting maxD=num("MaxDist",128,16,300,8), fill=num("FillAlpha",40,0,255,5), names=bool("Names",true), tracer=bool("Tracers",false), col;
    public EntityFinder(String n,int c,Predicate<Entity> p){ super(n,Category.RENDER); test=p; col=color("Color",c); }
    public void onRender(Matrix4f m,Vec3d cam,float td){ double md2=maxD.d*maxD.d; int cc=col.c;
      for(Entity e:mc.world.getEntities()){ if(e==mc.player||!test.test(e)||mc.player.squaredDistanceTo(e)>md2) continue; Box b=Util.lerpBox(e,td).offset(-cam.x,-cam.y,-cam.z);
        R.box(m,b,(fill.i()<<24)|(cc&0xFFFFFF),cc); if(tracer.b) R.tracer(b.getCenter(),cc,false); } }
    public void onHud(DrawContext g,float td){ if(!names.b) return; double md2=maxD.d*maxD.d;
      for(Entity e:mc.world.getEntities()){ if(e==mc.player||!test.test(e)||mc.player.squaredDistanceTo(e)>md2) continue; Box b=Util.lerpBox(e,td); Vec3d s=AbabClient.project(new Vec3d(b.getCenter().x,b.maxY+0.3,b.getCenter().z)); if(s==null) continue;
        String n=e instanceof ItemEntity ie?ie.getStack().getName().getString()+" x"+ie.getStack().getCount():e.getName().getString(); int w=mc.textRenderer.getWidth(n);
        g.fill((int)s.x-w/2-2,(int)s.y-10,(int)s.x+w/2+2,(int)s.y,0x99000000); g.drawTextWithShadow(mc.textRenderer,n,(int)s.x-w/2,(int)s.y-9,0xFFFFFFFF); } }
  }
}
