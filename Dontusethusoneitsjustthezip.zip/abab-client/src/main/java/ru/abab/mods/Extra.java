package ru.abab.mods;
import java.util.*;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.block.*;
import net.minecraft.block.entity.*;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.*;
import net.minecraft.entity.decoration.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.vehicle.AbstractMinecartEntity;
import net.minecraft.item.*;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.registry.Registries;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.*;
import net.minecraft.world.Heightmap;
import net.minecraft.world.chunk.*;
import org.joml.Matrix4f;
import ru.abab.core.Module;
import ru.abab.core.*;

public final class Extra {
  static ChunkFly CF; static ChunkWalk CW; static SusChunk SUS;
  public static boolean chunkBypass(){ return (CF!=null&&CF.on)||(CW!=null&&CW.on); }
  public static List<String> susTop(int n){ return SUS.top(n); }
  public static void susClear(){ SUS.res.clear(); }

  public static void register(List<Module> l){
    HitDelay hd=new HitDelay(); MazeKill mk=new MazeKill(); CF=new ChunkFly(); CW=new ChunkWalk(); SUS=new SusChunk();
    l.addAll(List.of(hd,mk,new SpearKill(),new HighJump(),CF,CW,new AutoEat(),new Jesus()));
    // HitDelay is registered first: if it cancels (FAIL) MazeKill's packets are not sent for the cancelled hit.
    AttackEntityCallback.EVENT.register((p,w,hand,e,hit)->{
      if(!w.isClient()) return ActionResult.PASS;
      if(hd.on&&hd.intercept(e)) return ActionResult.FAIL;
      if(mk.on) mk.pre(e);
      return ActionResult.PASS;
    });
  }

  // ===== Knockback / hit delay: your hit is held back and lands after N seconds =====
  public static class HitDelay extends Module {
    Setting sec=num("DelaySeconds",2,0.05,10,0.05), playersOnly=bool("PlayersOnly",false);
    record P(Entity e,int due){} final List<P> q=new ArrayList<>(); boolean bypass; int t;
    public HitDelay(){ super("KBDelay",Category.COMBAT); }
    boolean intercept(Entity e){
      if(bypass) return false; if(playersOnly.b&&!(e instanceof PlayerEntity)) return false;
      for(P p:q) if(p.e==e) return true;
      q.add(new P(e,t+(int)Math.round(sec.d*20))); mc.player.swingHand(Hand.MAIN_HAND); return true;
    }
    public void onTick(){ t++; Iterator<P> it=q.iterator();
      while(it.hasNext()){ P p=it.next(); if(!p.e.isAlive()||p.e.isRemoved()){ it.remove(); continue; }
        if(t>=p.due){ it.remove(); if(mc.player.distanceTo(p.e)<=8){ bypass=true; try{ mc.interactionManager.attackEntity(mc.player,p.e); mc.player.swingHand(Hand.MAIN_HAND); } finally{ bypass=false; } } } } }
    public void onDisable(){ q.clear(); }
  }

  // ===== MazeKill (mace smash): fake a long fall with packets, then the real hit lands as a smash. You never move. =====
  // v2: no cooldown wait (IgnoreCooldown), works while jumping / in the air, range setting.
  public static class MazeKill extends Module {
    Setting h=num("Height",120,5,500,5), step=num("PacketStep",9,1,10,0.5), range=num("Range",6,3,6,0.5), needMace=bool("RequireMace",true), autoSwitch=bool("AutoSwitch",false), ignoreCd=bool("IgnoreCooldown",true);
    boolean busy;
    public MazeKill(){ super("MazeKill",Category.COMBAT); }
    double clearance(){ double c=0; Box b=mc.player.getBoundingBox(); for(int k=1;k<=(int)h.d;k++){ if(!mc.world.isSpaceEmpty(mc.player,b.offset(0,k,0))) break; c=k; } return c; }
    void pre(Entity e){
      if(busy||!(e instanceof LivingEntity)) return;
      if(needMace.b&&!mc.player.getMainHandStack().isOf(Items.MACE)){ if(autoSwitch.b){ int s=Util.findHotbar(x->x.isOf(Items.MACE)); if(s>=0) Util.sel(s); } if(!mc.player.getMainHandStack().isOf(Items.MACE)) return; }
      if(!ignoreCd.b&&mc.player.getAttackCooldownProgress(0.5f)<0.9f) return;
      if(mc.player.distanceTo(e)>range.d) return;
      double H=Math.min(h.d,clearance()); if(H<4) return; busy=true;
      try{ double x=mc.player.getX(),y=mc.player.getY(),z=mc.player.getZ(),st=step.d; boolean hc=mc.player.horizontalCollision;
        for(double d=st;d<H;d+=st) Util.send(new PlayerMoveC2SPacket.PositionAndOnGround(x,y+d,z,false,hc));
        Util.send(new PlayerMoveC2SPacket.PositionAndOnGround(x,y+H,z,false,hc));
        for(double d=H-st;d>0;d-=st) Util.send(new PlayerMoveC2SPacket.PositionAndOnGround(x,y+d,z,false,hc));
        Util.send(new PlayerMoveC2SPacket.PositionAndOnGround(x,y,z,false,hc));
        mc.player.fallDistance=(float)H;
      } finally{ busy=false; }
    }
  }

  // ===== SpearKill v3: CONTINUOUS. Hold left click on someone (or turn HoldClick off for full auto) and it keeps striking until you let go. =====
  //  Mode 0 (default) = teleport strikes: packets carry you next to the target, hit, and carry you back (your screen never moves), repeated every Delay ticks.
  //  Mode 1 = fly: you really fly back, dash in, hit, fly back, dash in... back and forth.
  public static class SpearKill extends Module {
    Setting mode=num("Mode",0,0,2,1), predict=bool("Predict",true), speed=num("Speed",3,0.5,10,0.5), back=num("BackDist",14,3,60,1), range=num("AimRange",80,10,200,5), angle=num("AimAngle",12,2,60,1),
      maxTp=num("MaxTP",9,4,22,1), delay=num("Delay",8,1,40,1), hold=bool("HoldClick",true), cont=bool("Continuous",true), pl=bool("Players",true), mobs=bool("Mobs",true), nearest=bool("NearestOnly",false);
    enum S{IDLE,BACK,DASH} S st=S.IDLE; LivingEntity tg; Vec3d origin,last,lastT,tvel; int ticks,cool,stuck;
    public SpearKill(){ super("SpearKill",Category.COMBAT); }
    static boolean mouseHeld(){ return mc.currentScreen==null&&(mc.options.attackKey.isPressed()||org.lwjgl.glfw.GLFW.glfwGetMouseButton(mc.getWindow().getHandle(),0)==org.lwjgl.glfw.GLFW.GLFW_PRESS); }
    boolean ok(Entity e){ return e!=mc.player&&e instanceof LivingEntity le&&le.isAlive()&&((e instanceof PlayerEntity&&pl.b&&!((PlayerEntity)e).isSpectator())||(!(e instanceof PlayerEntity)&&mobs.b)); }
    LivingEntity aim(){ if(nearest.b){ LivingEntity b=null; double nd=range.d; for(Entity e:mc.world.getEntities()){ if(!ok(e)) continue; double d=mc.player.distanceTo(e); if(d<nd){ nd=d; b=(LivingEntity)e; } } return b; }
      Vec3d eye=mc.player.getEyePos(), look=mc.player.getRotationVec(1f), end=eye.add(look.multiply(range.d)); LivingEntity best=null; double bd=1e9;
      for(Entity e:mc.world.getEntities()){ if(!ok(e)) continue; Optional<Vec3d> hit=e.getBoundingBox().expand(0.35).raycast(eye,end); if(hit.isPresent()){ double d=eye.distanceTo(hit.get()); if(d<bd){ bd=d; best=(LivingEntity)e; } } }
      if(best!=null) return best; double ba=angle.d;
      for(Entity e:mc.world.getEntities()){ if(!ok(e)) continue; Vec3d d=e.getBoundingBox().getCenter().subtract(eye); if(d.length()>range.d||d.length()<0.01) continue;
        double a=Math.toDegrees(Math.acos(Math.max(-1,Math.min(1,look.dotProduct(d.normalize()))))); if(a<ba){ ba=a; best=(LivingEntity)e; } }
      if(best==null&&!hold.b){ double nd=range.d; for(Entity e:mc.world.getEntities()){ if(!ok(e)) continue; double d=mc.player.distanceTo(e); if(d<nd){ nd=d; best=(LivingEntity)e; } } } // full-auto: nearest target
      return best; }
    void go(Vec3d to,double sp){ Vec3d d=to.subtract(mc.player.getEntityPos()); double len=d.length(); if(len<1e-3) return; mc.player.setVelocity(d.multiply(Math.min(sp,len)/len)); mc.player.fallDistance=0; }
    void stop(){ st=S.IDLE; tg=null; stuck=0; cool=10; if(mc.player!=null) mc.player.setVelocity(0,0,0); }
    public void onDisable(){ st=S.IDLE; tg=null; if(mc.player!=null) mc.player.setVelocity(0,0,0); }
    static void pk(Vec3d from,Vec3d to,boolean ground){ int n=(int)Math.ceil(from.distanceTo(to)/9.0); for(int i=1;i<n;i++){ Vec3d p=from.lerp(to,i/(double)n); Util.send(new PlayerMoveC2SPacket.PositionAndOnGround(p.x,p.y,p.z,false,false)); } Util.send(new PlayerMoveC2SPacket.PositionAndOnGround(to.x,to.y,to.z,ground,false)); }
    boolean tpStrike(){
      Vec3d o=mc.player.getEntityPos(), t=tg.getEntityPos().add(predict.b&&tvel!=null?tvel.multiply(2):Vec3d.ZERO); Vec3d dir=t.subtract(o).multiply(1,0,1); if(dir.length()<0.01) dir=new Vec3d(1,0,0); dir=dir.normalize(); Vec3d spot=null;
      search: for(double off:new double[]{2.0,2.6,1.5,3.2}) for(double dy:new double[]{0,1}){ Vec3d c=new Vec3d(t.x-dir.x*off,t.y+dy,t.z-dir.z*off);
        if(mc.world.isSpaceEmpty(mc.player,mc.player.getBoundingBox().offset(c.subtract(o)))){ spot=c; break search; } }
      if(spot==null||o.distanceTo(spot)>maxTp.d) return false;
      boolean gr=mc.player.isOnGround(); pk(o,spot,false); mc.interactionManager.attackEntity(mc.player,tg); mc.player.swingHand(Hand.MAIN_HAND); pk(spot,o,gr); return true; }
    Vec3d lead(Vec3d c,double dist){ return predict.b&&tvel!=null?c.add(tvel.multiply(Math.min(8,dist/Math.max(0.5,speed.d)))):c; }
    public void onTick(){ if(cool>0) cool--; ticks++; boolean held=!hold.b||mouseHeld();
      if(tg!=null){ Vec3d nowP=tg.getEntityPos(); tvel=lastT==null?null:nowP.subtract(lastT); lastT=nowP; } else { lastT=null; tvel=null; }
      if(mode.i()==2){ // CHASE: follows runners and fights in the air (3D movement, target prediction, matches their speed)
        if(!held){ if(tg!=null){ mc.player.setVelocity(0,0,0); tg=null; } return; }
        LivingEntity n=aim(); if(n!=null) tg=n; else if(tg!=null&&(!tg.isAlive()||mc.player.distanceTo(tg)>range.d)) tg=null; if(tg==null) return;
        Vec3d c=tg.getBoundingBox().getCenter(); double dist=mc.player.getEyePos().distanceTo(c); Vec3d ld=lead(c,dist); Util.face(ld); mc.player.setSprinting(true);
        if(dist<=3.2){ Vec3d v=tvel==null?Vec3d.ZERO:tvel; mc.player.setVelocity(v.x,v.y,v.z); mc.player.fallDistance=0; if(cool==0){ mc.interactionManager.attackEntity(mc.player,tg); mc.player.swingHand(Hand.MAIN_HAND); cool=(int)delay.d; } }
        else go(ld,Math.min(speed.d,Math.max(0.35,dist-2.4+(tvel==null?0:tvel.length())))); return; }
      if(mode.i()==0){ // teleport strikes (close range); far targets are approached by flying first
        if(!held) return; LivingEntity n=aim(); if(n!=null) tg=n; else if(tg!=null&&(!tg.isAlive()||mc.player.distanceTo(tg)>range.d)) tg=null;
        if(tg!=null){ if(mc.player.distanceTo(tg)>maxTp.d+1){ Vec3d c=tg.getBoundingBox().getCenter(); go(lead(c,mc.player.distanceTo(tg)),speed.d); return; } if(cool==0){ tpStrike(); cool=(int)delay.d; } } return; }
      if(st!=S.IDLE&&!held){ stop(); return; }
      switch(st){
        case IDLE -> { if(cool==0&&held){ tg=aim(); if(tg!=null){ origin=mc.player.getEntityPos(); last=origin; st=S.BACK; ticks=0; stuck=0; } } }
        case BACK -> { if(tg==null||!tg.isAlive()){ stop(); return; }
          Vec3d me=mc.player.getEntityPos(), away=me.subtract(tg.getEntityPos()).multiply(1,0,1); if(away.length()<0.01) away=new Vec3d(1,0,0); away=away.normalize();
          go(me.add(away.multiply(speed.d)),speed.d);
          stuck=me.distanceTo(last)<0.05?stuck+1:0; last=me; // wall behind you: dash anyway instead of freezing
          if(me.distanceTo(origin)>=back.d||ticks>60||stuck>=4){ st=S.DASH; ticks=0; stuck=0; } }
        case DASH -> { if(tg==null||!tg.isAlive()||ticks>120){ stop(); return; }
          Vec3d c=tg.getBoundingBox().getCenter(); Util.face(c); mc.player.setSprinting(true); double dist=mc.player.getEyePos().distanceTo(c);
          if(dist<=3.4){ mc.player.setVelocity(0,0,0); mc.interactionManager.attackEntity(mc.player,tg); mc.player.swingHand(Hand.MAIN_HAND);
            if(cont.b){ st=S.BACK; origin=mc.player.getEntityPos(); last=origin; ticks=0; stuck=0; } else stop(); } // continuous: straight back out again
          else go(c,Math.min(speed.d,Math.max(0.3,dist-2.0))); }
        default -> {}
      } }
  }

  // ===== HighJump: set how many blocks you want (200, 1000...). Uses real jump physics to compute the launch speed. =====
  public static class HighJump extends Module {
    Setting blocks=num("Blocks",30,1,300,1);
    public HighJump(){ super("HighJump",Category.MOVEMENT); }
    static double peak(double v){ double y=0; for(int i=0;i<100000&&v>0;i++){ y+=v; v=(v-0.08)*0.98; } return y; }
    static double velFor(double h){ double lo=0.1,hi=1e7; for(int i=0;i<80;i++){ double m=(lo+hi)/2; if(peak(m)<h) lo=m; else hi=m; } return hi; }
    boolean was; public void onTick(){ boolean g=mc.player.isOnGround(); /* vanilla jump() overwrites our velocity, so apply on the first airborne tick */ if(was&&!g&&mc.options.jumpKey.isPressed()&&mc.player.getVelocity().y>0.1){ Vec3d v=mc.player.getVelocity(); mc.player.setVelocity(v.x,velFor(blocks.d),v.z); } was=g; }
  }

  // ===== Move in chunks that are not loaded =====
  public static class ChunkFly extends Module {
    Setting sp=num("Speed",1.0,0.05,10,0.05), vs=num("Vertical",0.6,0.05,5,0.05), only=bool("OnlyUnloaded",true);
    public ChunkFly(){ super("ChunkFly",Category.MOVEMENT); }
    public void onTick(){ boolean unl=mc.world.getChunkManager().getWorldChunk(mc.player.getChunkPos().x,mc.player.getChunkPos().z)==null; if(only.b&&!unl) return;
      Util.move(sp.d,mc.options.jumpKey.isPressed()?vs.d:mc.options.sneakKey.isPressed()?-vs.d:0); mc.player.fallDistance=0; }
  }
  public static class ChunkWalk extends Module {
    Setting sp=num("Speed",0.25,0.05,2,0.05);
    public ChunkWalk(){ super("ChunkWalk",Category.MOVEMENT); }
    public void onTick(){ if(mc.world.getChunkManager().getWorldChunk(mc.player.getChunkPos().x,mc.player.getChunkPos().z)!=null) return; Util.move(sp.d,0); mc.player.fallDistance=0; }
  }

  public static class Jesus extends Module { public Jesus(){ super("Jesus",Category.MOVEMENT); }
    public void onTick(){ if(mc.player.isSneaking()||mc.options.jumpKey.isPressed()) return; if(mc.player.isTouchingWater()||mc.player.isInLava()){ Vec3d v=mc.player.getVelocity(); mc.player.setVelocity(v.x,0.11,v.z); } } }

  public static class AutoEat extends Module { Setting hunger=num("EatBelow",14,1,19,1); boolean eating; int old=-1; public AutoEat(){ super("AutoEat",Category.PLAYER); }
    public void onTick(){ int food=mc.player.getHungerManager().getFoodLevel();
      if(food<=hunger.d||(eating&&food<20)){ int s=Util.findHotbar(x->x.get(DataComponentTypes.FOOD)!=null&&!x.isOf(Items.ROTTEN_FLESH)&&!x.isOf(Items.SPIDER_EYE)&&!x.isOf(Items.PUFFERFISH)&&!x.isOf(Items.POISONOUS_POTATO)&&!x.isOf(Items.CHORUS_FRUIT));
        if(s>=0){ if(!eating){ old=Util.sel(); eating=true; } Util.sel(s); mc.options.useKey.setPressed(true); return; } }
      if(eating){ eating=false; mc.options.useKey.setPressed(false); if(old>=0) Util.sel(old); } }
    public void onDisable(){ if(eating){ mc.options.useKey.setPressed(false); eating=false; } } }

  // ===== SusChunk: base finder. Scores loaded chunks and paints suspicious ones red. =====
  public static class SusChunk extends Module {
    Setting radius=num("ChunkRadius",12,2,32,1), perTick=num("ScansPerTick",1,1,8,1), min=num("MinScore",4,0.5,100,0.5), maxA=num("MaxAlpha",150,20,255,5), oy=num("OverlayY",-1,-1,1000,1),
      outline=bool("Outline",true), track=bool("TrackPlayers",true), tunnelsOn=bool("Tunnels",true), neigh=bool("NeighborBonus",true), col=color("CenterColor",0xFFFF1E1E), edge=color("EdgeColor",0xFFFFFFFF), csize=num("CenterSize",70,0,100,5);
    static class Res{ double art,be,tun,dev,act,base,fin; int tick; }
    final Map<Long,Res> res=new HashMap<>(); final Map<Long,Integer> seen=new HashMap<>(); final Map<Long,Double> ent=new HashMap<>();
    byte[] grid; int gH,t,orderR=-1; List<int[]> order=new ArrayList<>(); static final IdentityHashMap<Block,Double> W=new IdentityHashMap<>();
    public SusChunk(){ super("SusChunk",Category.RENDER); }
    static long key(int x,int z){ return ((long)z<<32)|(x&0xFFFFFFFFL); }
    // how "player-made" a block is. strong=1, weak (also in mineshafts etc)=0.25
    static double weight(Block b){ Double c=W.get(b); if(c!=null) return c; String n=Registries.BLOCK.getId(b).getPath(); double w=0;
      if(n.endsWith("_planks")||n.contains("fence")||n.equals("rail")||n.endsWith("_rail")||n.contains("torch")||n.equals("chest")||n.equals("cobblestone")||n.equals("crafting_table")||n.equals("ladder")) w=0.25;
      if(n.contains("concrete")||n.contains("glass")||n.endsWith("_wool")||n.endsWith("_slab")||n.endsWith("_stairs")||n.endsWith("_door")||n.endsWith("trapdoor")||n.contains("lantern")||n.equals("hopper")||n.contains("furnace")||n.equals("smoker")||n.contains("shulker")||n.endsWith("_bed")||n.equals("barrel")
        ||n.equals("bookshelf")||n.equals("anvil")||n.contains("enchanting")||n.equals("beacon")||n.equals("observer")||n.contains("piston")||n.equals("dispenser")||n.equals("dropper")||n.equals("repeater")||n.equals("comparator")||n.equals("redstone_lamp")||n.equals("tnt")||n.equals("sea_lantern")
        ||n.equals("iron_block")||n.equals("diamond_block")||n.equals("emerald_block")||n.equals("netherite_block")||n.equals("redstone_block")||n.equals("lapis_block")||n.equals("coal_block")||n.contains("glazed_terracotta")||n.startsWith("smooth_")||n.endsWith("_wall")||n.contains("sign")
        ||(n.contains("polished")&&!n.contains("blackstone"))||(n.contains("bricks")&&!n.contains("nether")&&!n.contains("stone_brick")&&!n.contains("deepslate")&&!n.contains("end_stone")&&!n.contains("mud"))) w=1;
      W.put(b,w); return w; }
    int g(int x,int y,int z){ if(y<0||y>=gH||x<0||x>15||z<0||z>15) return 1; return grid[y*256+z*16+x]; }
    boolean cell(int x,int y,int z,boolean ax){ if(g(x,y,z)!=0||g(x,y+1,z)!=0||g(x,y-1,z)!=1||g(x,y+2,z)!=1) return false;
      return ax ? (g(x,y,z-1)==1&&g(x,y+1,z-1)==1&&g(x,y,z+1)==1&&g(x,y+1,z+1)==1) : (g(x-1,y,z)==1&&g(x-1,y+1,z)==1&&g(x+1,y,z)==1&&g(x+1,y+1,z)==1); }
    Res scan(WorldChunk c){
      Res r=new Res(); r.tick=t; int bottom=mc.world.getBottomY(), top=bottom+mc.world.getHeight(); boolean nether=mc.world.getDimension().hasCeiling(); if(nether) top=Math.min(top,bottom+128);
      gH=top-bottom; if(grid==null||grid.length<gH*256) grid=new byte[gH*256];
      BlockPos.Mutable mp=new BlockPos.Mutable(); int bx=c.getPos().getStartX(), bz=c.getPos().getStartZ(); double art=0;
      for(int y=bottom;y<top;){
        ChunkSection sec=c.getSection(c.getSectionIndex(y));
        if(sec.isEmpty()){ int base=(y-bottom)*256; Arrays.fill(grid,base,base+Math.min(16,top-y)*256,(byte)0); y+=16; continue; }
        int yEnd=Math.min(y+16,top);
        for(;y<yEnd;y++) for(int z=0;z<16;z++) for(int x=0;x<16;x++){ BlockState s=c.getBlockState(mp.set(bx+x,y,bz+z)); byte gv;
          if(s.isAir()) gv=0; else if(!s.getFluidState().isEmpty()) gv=2; else { gv=(byte)(s.isOpaque()?1:0); art+=weight(s.getBlock()); } grid[(y-bottom)*256+z*16+x]=gv; }
      }
      r.art=Math.min(art/40.0,5);
      double be=0; for(BlockEntity b:c.getBlockEntities().values()){ be+= b instanceof ShulkerBoxBlockEntity?2: b instanceof ChestBlockEntity||b instanceof BarrelBlockEntity?1: b instanceof HopperBlockEntity?0.7: b instanceof AbstractFurnaceBlockEntity?0.6: b instanceof DispenserBlockEntity||b instanceof BedBlockEntity?0.5: b instanceof SignBlockEntity?0.3: b instanceof BeaconBlockEntity?3:0; }
      r.be=Math.min(be,6);
      if(tunnelsOn.b){ int tun=0; for(int y=1;y<gH-2;y++) for(int a=0;a<16;a++){ int r1=0,r2=0;
          for(int b=0;b<16;b++){ if(cell(b,y,a,true)) r1++; else { if(r1>=6) tun++; r1=0; } if(cell(a,y,b,false)) r2++; else { if(r2>=6) tun++; r2=0; } }
          if(r1>=6) tun++; if(r2>=6) tun++; }
        r.tun=Math.min(tun*1.2,6); }
      if(!nether){ int[][] hm=new int[16][16]; int flat=0,tot=0,water=0,surf=0;
        for(int x=0;x<16;x++) for(int z=0;z<16;z++) hm[x][z]=c.sampleHeightmap(Heightmap.Type.WORLD_SURFACE,x,z);
        for(int x=0;x<15;x++) for(int z=0;z<15;z++){ tot++; if(hm[x][z]==hm[x+1][z]&&hm[x][z]==hm[x][z+1]) flat++; }
        for(int x=0;x<16;x++) for(int z=0;z<16;z++){ BlockState s=c.getBlockState(mp.set(bx+x,hm[x][z]-1,bz+z)); if(!s.getFluidState().isEmpty()) water++; else if(weight(s.getBlock())>=0.5) surf++; }
        double dev=Math.min(4,surf*0.15); if(water<64) dev+=Math.max(0,(double)flat/tot-0.75)*8; r.dev=Math.min(dev,5); }
      long k=key(c.getPos().x,c.getPos().z); r.act=Math.min(seen.getOrDefault(k,0)/40.0+ent.getOrDefault(k,0.0),4);
      int ind=(r.art>1?1:0)+(r.be>1?1:0)+(r.tun>0?1:0)+(r.dev>1?1:0)+(r.act>0.5?1:0);
      r.base=(r.art+r.be+r.tun+r.dev+r.act)*(ind>=3?1.4:1.0); r.fin=r.base; return r; }
    public void onTick(){ t++;
      if(t%20==0){ ent.clear(); for(Entity e:mc.world.getEntities()){ double w=0; if(e instanceof PlayerEntity&&e!=mc.player){ w=1; if(track.b) seen.merge(key(e.getChunkPos().x,e.getChunkPos().z),20,Integer::sum); }
          else if(e instanceof ArmorStandEntity||e instanceof ItemFrameEntity||e instanceof AbstractMinecartEntity) w=0.4; if(w>0) ent.merge(key(e.getChunkPos().x,e.getChunkPos().z),w,Double::sum); } }
      if(t%2400==0) seen.replaceAll((k,v)->v/2);
      int R=radius.i(); if(R!=orderR){ orderR=R; order.clear(); for(int x=-R;x<=R;x++) for(int z=-R;z<=R;z++) order.add(new int[]{x,z}); order.sort(Comparator.comparingInt(a->a[0]*a[0]+a[1]*a[1])); }
      ChunkPos pc=mc.player.getChunkPos(); int done=0;
      for(int[] o:order){ long k=key(pc.x+o[0],pc.z+o[1]); Res rs=res.get(k); if(rs!=null&&t-rs.tick<2400) continue; WorldChunk c=mc.world.getChunkManager().getWorldChunk(pc.x+o[0],pc.z+o[1]); if(c==null) continue;
        res.put(k,scan(c)); if(++done>=perTick.i()) break; }
      if(t%20==0) for(Map.Entry<Long,Res> en:res.entrySet()){ long k=en.getKey(); int cx=(int)k,cz=(int)(k>>32); double sum=0; int hot=0;
        for(int dx=-1;dx<=1;dx++) for(int dz=-1;dz<=1;dz++){ if(dx==0&&dz==0) continue; Res n=res.get(key(cx+dx,cz+dz)); if(n!=null){ sum+=n.base; if(n.base>=min.d*0.5) hot++; } }
        Res r=en.getValue(); r.fin=r.base+(neigh.b?Math.min(sum*0.3,6)+(hot>=3?1.5:0):0); } }
    public void onRender(Matrix4f m,Vec3d cam,float td){ ChunkPos pc=mc.player.getChunkPos(); int RR=radius.i(); double y=oy.d<0?Math.floor(mc.player.getY()):oy.d;
      for(Map.Entry<Long,Res> en:res.entrySet()){ Res r=en.getValue(); if(r.fin<min.d) continue; int cx=(int)(long)en.getKey(),cz=(int)(en.getKey()>>32); if(Math.abs(cx-pc.x)>RR||Math.abs(cz-pc.z)>RR) continue;
        int a=(int)Math.max(40,Math.min(maxA.d,r.fin/(min.d*3)*maxA.d)); int rgb=col.c&0xFFFFFF, erg=edge.c&0xFFFFFF; double off=8*(1-csize.d/100.0);
        R.box(m,new Box(cx*16,y,cz*16,cx*16+16,y+0.06,cz*16+16).offset(-cam.x,-cam.y,-cam.z),((a/3)<<24)|erg,outline.b?(0xFF000000|erg):0);
        if(csize.d>0) R.box(m,new Box(cx*16+off,y,cz*16+off,cx*16+16-off,y+0.06,cz*16+16-off).offset(-cam.x,-cam.y,-cam.z),(a<<24)|rgb,0); } }
    List<String> top(int n){ List<Map.Entry<Long,Res>> l=new ArrayList<>(); for(Map.Entry<Long,Res> e:res.entrySet()) if(e.getValue().fin>=min.d) l.add(e); l.sort((a,b)->Double.compare(b.getValue().fin,a.getValue().fin));
      List<String> out=new ArrayList<>(); out.add("§7"+l.size()+" suspicious chunks (of "+res.size()+" scanned)");
      for(int i=0;i<Math.min(n,l.size());i++){ Res r=l.get(i).getValue(); long k=l.get(i).getKey(); out.add(String.format("§c%d, %d §7score §f%.1f §7(blk %.1f be %.1f tun %.1f dev %.1f act %.1f)",((int)k)*16+8,((int)(k>>32))*16+8,r.fin,r.art,r.be,r.tun,r.dev,r.act)); }
      return out; }
  }
}
