package ru.abab.mods;
import ru.abab.core.Module;
import java.util.*;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import net.minecraft.block.*;
import net.minecraft.block.entity.*;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.*;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.effect.*;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.*;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.chunk.WorldChunk;
import org.joml.Matrix4f;
import ru.abab.AbabClient;
import ru.abab.core.*;

public final class Mods {
  public static HudMod HUD; static BlockEsp BLOCKESP;
  public static void register(List<Module> l){
    HUD=new HudMod(); BLOCKESP=new BlockEsp();
    l.addAll(List.of(new KillAura(),new AutoCrystal(),new AutoTotem(),new AutoArmor(),new Surround(),new AutoLog(),new Trigger(),
      new NoFall(),new Reach(),new XPThrower(),
      new Sprint(),new Flight(),new Speed(),new Step(),new AutoWalk(),new AutoJump(),new Spider(),new Glide(),new Sneak(),new AntiAFK(),new Scaffold(),
      new Esp(),new Tracers(),new StorageEsp(),BLOCKESP,new HoleEsp(),new Fullbright(),new CustomFov(),HUD,
      new Nuker()));
    Extra.register(l);
    Pack2.register(l);
    Pack3.register(l);
    Pack4.register(l);
    Pack5.register(l);
    Pack6.register(l);
    Pack7.register(l);
    Pack8.register(l);
  }
  public static boolean blockEspAdd(String n){ Block b=Registries.BLOCK.get(Identifier.tryParse(n.contains(":")?n:"minecraft:"+n.toLowerCase())); if(b==Blocks.AIR) return false; BLOCKESP.blocks.add(b); return true; }
  public static void blockEspRemove(String n){ Block b=Registries.BLOCK.get(Identifier.tryParse(n.contains(":")?n:"minecraft:"+n.toLowerCase())); BLOCKESP.blocks.remove(b); }
  public static void blockEspClear(){ BLOCKESP.blocks.clear(); }
  public static boolean blockEspHas(Block b){ return BLOCKESP.blocks.contains(b); }
  public static void blockEspToggle(Block b){ if(!BLOCKESP.blocks.remove(b)) BLOCKESP.blocks.add(b); }
  public static int blockEspAddOres(){ int n=0; for(Block b:Registries.BLOCK){ String p=Registries.BLOCK.getId(b).getPath(); if(p.endsWith("_ore")||p.equals("ancient_debris")){ if(BLOCKESP.blocks.add(b)) n++; } } return n; }
  public static java.util.Set<Block> blockEspSet(){ return BLOCKESP.blocks; }
  public static List<String> blockEspNames(){ List<String> l=new ArrayList<>(); for(Block b:BLOCKESP.blocks) l.add(Registries.BLOCK.getId(b).getPath()); return l; }

  // ================= HUD =================
  public static class HudMod extends Module { public Setting watermark=bool("Watermark",true), list=bool("HacksList",true), keys=bool("Keystrokes",true),
      scale=num("KeysScale",0.8,0.4,2.5,0.1), x=num("KeysX%",2,0,95,1), y=num("KeysY%",55,0,95,1), fovFix=num("FovFix",1.0,0.5,1.5,0.01);
    public HudMod(){ super("HUD",Category.RENDER); on=true; } }

  // ================= COMBAT =================
  public static class KillAura extends Module { Setting range=num("Range",4.2,2,6,0.1), players=bool("Players",true), mobs=bool("Mobs",false), rotate=bool("Rotate",true), delay=num("Delay",0,0,20,1), cd=bool("WaitCooldown",true), sw=bool("AutoSwitchWeapon",true), hitMode=num("HitMode",0,0,3,1); int dt; // HitMode: 0 normal, 1 crit, 2 sweep, 3 auto
    public KillAura(){ super("KillAura",Category.COMBAT); }
    public void onTick(){ Entity best=null; double bd=1e9;
      for(Entity e:mc.world.getEntities()){ if(e==mc.player||!(e instanceof LivingEntity le)||!le.isAlive()) continue;
        if(!((e instanceof PlayerEntity p&&players.b&&!p.isSpectator())||(e instanceof Monster&&mobs.b))) continue;
        double d=mc.player.distanceTo(e); if(d<=range.d&&d<bd){ bd=d; best=e; } }
      if(best==null) return; if(rotate.b) Util.face(best.getBoundingBox().getCenter());
      dt++; if((!cd.b||mc.player.getAttackCooldownProgress(0)>=0.95f)&&dt>delay.i()){ int old=Util.sel(); if(sw.b){ int ws=Util.findHotbar(s->{ String pp=Registries.ITEM.getId(s.getItem()).getPath(); return pp.endsWith("_sword")||pp.endsWith("_axe")||pp.endsWith("_spear")||pp.equals("mace"); }); if(ws>=0) Util.sel(ws); } Pack8.pre(hitMode.i(),best); mc.interactionManager.attackEntity(mc.player,best); mc.player.swingHand(Hand.MAIN_HAND); Pack8.post(); Util.sel(old); dt=0; } } }

  public static class Trigger extends Module { Setting delay=num("Delay",0,0,20,1), cd=bool("WaitCooldown",true); int dt; public Trigger(){ super("Trigger",Category.COMBAT); }
    public void onTick(){ dt++; if(mc.crosshairTarget instanceof EntityHitResult r&&r.getEntity() instanceof LivingEntity&&(!cd.b||mc.player.getAttackCooldownProgress(0)>=0.95f)&&dt>delay.i()){ mc.interactionManager.attackEntity(mc.player,r.getEntity()); mc.player.swingHand(Hand.MAIN_HAND); dt=0; } } }

  public static class AutoCrystal extends Module { Setting rep=num("PerTick",1,1,10,1), range=num("Range",4.5,2,6,0.1), brk=bool("Break",true), place=bool("Place",true), bdelay=num("BreakDelay",0,0,20,1), pdelay=num("PlaceDelay",0,0,20,1), tr=num("TargetRange",9,3,16,1), safe=num("MinSelfDist",2.5,1,6,0.5);
    int t; public AutoCrystal(){ super("AutoCrystal",Category.COMBAT); }
    public void onTick(){ int n=rep.i(); for(int i=0;i<n;i++){ boolean w=t>0; step(); if(w) break; } }
    void step(){ if(t>0){ t--; return; }
      if(brk.b) for(Entity e:mc.world.getEntities()) if(e instanceof EndCrystalEntity&&mc.player.distanceTo(e)<=range.d){ mc.interactionManager.attackEntity(mc.player,e); mc.player.swingHand(Hand.MAIN_HAND); t=(int)bdelay.d; return; }
      if(!place.b) return;
      boolean off=mc.player.getOffHandStack().isOf(Items.END_CRYSTAL); int slot=off?-1:Util.findHotbar(s->s.isOf(Items.END_CRYSTAL)); if(!off&&slot<0) return;
      PlayerEntity tg=null; double bd=tr.d; for(PlayerEntity p:mc.world.getPlayers()) if(p!=mc.player&&p.isAlive()&&mc.player.distanceTo(p)<bd){ bd=mc.player.distanceTo(p); tg=p; }
      if(tg==null) return;
      BlockPos bp=mc.player.getBlockPos(),best=null; double bs=1e9; int r=(int)Math.ceil(range.d);
      for(int x=-r;x<=r;x++) for(int y=-r;y<=r;y++) for(int z=-r;z<=r;z++){ BlockPos p=bp.add(x,y,z); Block b=mc.world.getBlockState(p).getBlock();
        if(b!=Blocks.OBSIDIAN&&b!=Blocks.BEDROCK) continue; if(!mc.world.getBlockState(p.up()).isAir()||!mc.world.getBlockState(p.up(2)).isAir()) continue;
        Vec3d c=new Vec3d(p.getX()+.5,p.getY()+1,p.getZ()+.5); if(mc.player.getEyePos().distanceTo(c)>range.d) continue; if(c.distanceTo(mc.player.getEntityPos())<safe.d) continue;
        if(!mc.world.getOtherEntities(null,new Box(p.up()).stretch(0,1,0)).isEmpty()) continue;
        double s=c.distanceTo(tg.getEntityPos()); if(s<bs&&s<=6){ bs=s; best=p; } }
      if(best==null) return; int old=Util.sel(); if(!off) Util.sel(slot); Hand h=off?Hand.OFF_HAND:Hand.MAIN_HAND;
      mc.interactionManager.interactBlock(mc.player,h,new net.minecraft.util.hit.BlockHitResult(Vec3d.ofCenter(best).add(0,.5,0),Direction.UP,best,false)); mc.player.swingHand(h);
      if(!off) Util.sel(old); t=(int)pdelay.d; } }

  public static class AutoTotem extends Module { Setting hp=num("Health",20,1,20,1); public AutoTotem(){ super("AutoTotem",Category.COMBAT); }
    public void onTick(){ if(mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)||mc.player.getHealth()>hp.d) return;
      for(int i=0;i<36;i++) if(mc.player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)){ int slot=i<9?i+36:i; mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId,slot,40,SlotActionType.SWAP,mc.player); return; } } }

  public static class AutoArmor extends Module { int t; public AutoArmor(){ super("AutoArmor",Category.COMBAT); }
    public void onTick(){ if(t-->0) return;
      for(int i=0;i<36;i++){ ItemStack s=mc.player.getInventory().getStack(i); var eq=s.get(DataComponentTypes.EQUIPPABLE); if(eq==null||!eq.slot().isArmorSlot()) continue;
        if(!mc.player.getEquippedStack(eq.slot()).isEmpty()) continue; int slot=i<9?i+36:i;
        mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId,slot,0,SlotActionType.QUICK_MOVE,mc.player); t=3; return; } } }

  public static class Surround extends Module { public Surround(){ super("Surround",Category.COMBAT); }
    public void onTick(){ int slot=Util.findHotbar(s->s.isOf(Items.OBSIDIAN)); if(slot<0) return; BlockPos base=mc.player.getBlockPos(); int old=Util.sel(),n=0;
      for(Direction d:Direction.Type.HORIZONTAL){ BlockPos p=base.offset(d); if(n>=3) break; if(mc.world.getBlockState(p).isReplaceable()&&mc.world.getOtherEntities(mc.player,new Box(p)).isEmpty()){ Util.sel(slot); if(Util.place(p)) n++; } }
      if(n>0) Util.sel(old); } }

  public static class AutoLog extends Module { Setting hp=num("Health",6,1,19,1); public AutoLog(){ super("AutoLog",Category.COMBAT); }
    public void onTick(){ if(mc.player.getHealth()<=hp.d){ mc.player.networkHandler.getConnection().disconnect(Text.literal("[АБАБ] AutoLog")); set(false); } } }

  // ================= PLAYER =================
  public static class NoFall extends Module { public NoFall(){ super("NoFall",Category.PLAYER); }
    public void onTick(){ if(mc.player.fallDistance>2.5f) Util.send(new PlayerMoveC2SPacket.OnGroundOnly(true,mc.player.horizontalCollision)); } }
  public static class Reach extends Module { Setting ent=num("Entity",4.5,3,6,0.1), blk=num("Block",5.5,4.5,6,0.1); public Reach(){ super("Reach",Category.PLAYER); }
    public void onTick(){ mc.player.getAttributeInstance(EntityAttributes.ENTITY_INTERACTION_RANGE).setBaseValue(ent.d); mc.player.getAttributeInstance(EntityAttributes.BLOCK_INTERACTION_RANGE).setBaseValue(blk.d); }
    public void onDisable(){ mc.player.getAttributeInstance(EntityAttributes.ENTITY_INTERACTION_RANGE).setBaseValue(3.0); mc.player.getAttributeInstance(EntityAttributes.BLOCK_INTERACTION_RANGE).setBaseValue(4.5); } }
  public static class XPThrower extends Module { int t; public XPThrower(){ super("EXPThrower",Category.PLAYER); }
    public void onTick(){ if(t-->0) return; int s=Util.findHotbar(x->x.isOf(Items.EXPERIENCE_BOTTLE)); if(s<0) return; int old=Util.sel(); Util.sel(s); mc.player.setPitch(90); mc.interactionManager.interactItem(mc.player,Hand.MAIN_HAND); Util.sel(old); t=2; } }

  // ================= MOVEMENT =================
  public static class Sprint extends Module { public Sprint(){ super("Sprint",Category.MOVEMENT); }
    public void onTick(){ if(Util.fwd()>0&&!mc.player.horizontalCollision&&!mc.player.isSneaking()&&mc.player.getHungerManager().getFoodLevel()>6) mc.player.setSprinting(true); } }
  public static class Flight extends Module { Setting sp=num("Speed",1.0,0.1,100,0.1), vs=num("Vertical",0.5,0.1,100,0.1), ak=bool("AntiKick",true); int kt; public Flight(){ super("Flight",Category.MOVEMENT); }
    public void onTick(){ double vy=mc.options.jumpKey.isPressed()?vs.d:mc.options.sneakKey.isPressed()?-vs.d:0; if(vy==0&&ak.b&&++kt%20==0) vy=-0.04; Util.move(sp.d,vy); mc.player.fallDistance=0; } }
  public static class Speed extends Module { Setting sp=num("Speed",0.32,0.1,3,0.01), hop=bool("Bhop",true); public Speed(){ super("Speed",Category.MOVEMENT); }
    public void onTick(){ if(!Util.moving()) return; if(hop.b&&mc.player.isOnGround()) mc.player.jump(); Util.move(sp.d,mc.player.getVelocity().y); } }
  public static class Step extends Module { Setting h=num("Height",2.0,0.6,10,0.1); public Step(){ super("Step",Category.MOVEMENT); }
    public void onTick(){ mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT).setBaseValue(h.d); } public void onDisable(){ mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT).setBaseValue(0.6); } }
  public static class HighJump extends Module { Setting p=num("Power",0.8,0.42,2,0.02); public HighJump(){ super("HighJump",Category.MOVEMENT); }
    public void onTick(){ mc.player.getAttributeInstance(EntityAttributes.JUMP_STRENGTH).setBaseValue(p.d); } public void onDisable(){ mc.player.getAttributeInstance(EntityAttributes.JUMP_STRENGTH).setBaseValue(0.42); } }
  public static class AutoWalk extends Module { public AutoWalk(){ super("AutoWalk",Category.MOVEMENT); } public void onTick(){ mc.options.forwardKey.setPressed(true); } public void onDisable(){ mc.options.forwardKey.setPressed(false); } }
  public static class AutoJump extends Module { public AutoJump(){ super("AutoJump",Category.MOVEMENT); } public void onTick(){ if(mc.player.isOnGround()&&Util.moving()) mc.player.jump(); } }
  public static class Spider extends Module { public Spider(){ super("Spider",Category.MOVEMENT); } public void onTick(){ if(mc.player.horizontalCollision){ Vec3d v=mc.player.getVelocity(); mc.player.setVelocity(v.x,0.2,v.z); } } }
  public static class Glide extends Module { public Glide(){ super("Glide",Category.MOVEMENT); } public void onTick(){ Vec3d v=mc.player.getVelocity(); if(v.y<-0.08&&!mc.player.isOnGround()) mc.player.setVelocity(v.x,-0.05,v.z); } }
  public static class Sneak extends Module { public Sneak(){ super("Sneak",Category.MOVEMENT); } public void onTick(){ mc.options.sneakKey.setPressed(true); } public void onDisable(){ mc.options.sneakKey.setPressed(false); } }
  public static class AntiAFK extends Module { int t; public AntiAFK(){ super("AntiAFK",Category.MOVEMENT); }
    public void onTick(){ if(++t%200==0) mc.player.jump(); if(t%400==0){ mc.player.swingHand(Hand.MAIN_HAND); mc.player.setYaw(mc.player.getYaw()+((t/400)%2==0?15:-15)); } } }
  public static class Scaffold extends Module { public Scaffold(){ super("Scaffold",Category.MOVEMENT); }
    public void onTick(){ BlockPos p=mc.player.getBlockPos().down(); if(!mc.world.getBlockState(p).isReplaceable()) return;
      int s=Util.findHotbar(x->x.getItem() instanceof BlockItem bi&&!(bi.getBlock() instanceof ShulkerBoxBlock)&&bi.getBlock().getDefaultState().isFullCube(mc.world,BlockPos.ORIGIN)); if(s<0) return; Util.sel(s); Util.place(p); } }

  // ================= WORLD =================
  public static class Nuker extends Module { Setting r=num("Range",4,1,6,0.5); public Nuker(){ super("Nuker",Category.WORLD); }
    public void onTick(){ BlockPos c=mc.player.getBlockPos(),best=null; double bd=1e9; int R=(int)Math.ceil(r.d);
      for(int x=-R;x<=R;x++) for(int y=-R;y<=R;y++) for(int z=-R;z<=R;z++){ BlockPos p=c.add(x,y,z); BlockState s=mc.world.getBlockState(p);
        if(s.isAir()||s.getBlock()==Blocks.BEDROCK||!s.getFluidState().isEmpty()) continue; double d=Vec3d.ofCenter(p).distanceTo(mc.player.getEyePos()); if(d<=r.d&&d<bd){ bd=d; best=p; } }
      if(best!=null){ mc.interactionManager.updateBlockBreakingProgress(best,Direction.UP); mc.player.swingHand(Hand.MAIN_HAND); } } }

  // ================= RENDER =================
  public static class Fullbright extends Module { public Fullbright(){ super("Fullbright",Category.RENDER); }
    public void onTick(){ if(!mc.player.hasStatusEffect(StatusEffects.NIGHT_VISION)) mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION,1000,0,false,false)); }
    public void onDisable(){ mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION); } }
  public static class CustomFov extends Module { Setting f=num("FOV",100,30,110,1); int old=-1; public CustomFov(){ super("CustomFov",Category.RENDER); }
    public void onEnable(){ old=mc.options.getFov().getValue(); } public void onTick(){ mc.options.getFov().setValue(f.i()); }
    public void onDisable(){ if(old>0) mc.options.getFov().setValue(old); } }

  public static class Esp extends Module {
    Setting mode=num("Mode",0,0,2,1), // 0 = 3D wire box, 1 = 2D box, 2 = corner brackets
      pl=bool("Players",true), ho=bool("Hostile",true), an=bool("Animals",true), it=bool("Items",false), ot=bool("OtherMobs",true), fill=num("FillAlpha",0,0,255,5), maxD=num("MaxDist",128,16,300,8),
      names=bool("Names",true), dist=bool("Distance",true), health=bool("Health",true), hbar=bool("HealthBar",true), armor=bool("Armor",true), ench=bool("Enchants",true), trc=bool("Tracers",true),
      cP=color("PlayerColor",0xFFFFFFFF), cH=color("HostileColor",0xFFFF9A1F), cA=color("AnimalColor",0xFF3BFF6A), cI=color("ItemColor",0xFFFFFFFF), cO=color("OtherColor",0xFF3BC8FF);
    static final class T{ Entity e; double[] r; }
    final List<T> tg=new ArrayList<>();
    public Esp(){ super("ESP",Category.RENDER); }
    boolean en(int c){ return switch(c){ case 0->pl.b; case 1->ho.b; case 2->an.b; case 3->it.b; default->ot.b; }; }
    int col(int c){ return switch(c){ case 0->cP.c; case 1->cH.c; case 2->cA.c; case 3->cI.c; default->cO.c; }; }
    public void onDisable(){ tg.clear(); }
    public void onRender(Matrix4f m,Vec3d cam,float td){
      tg.clear(); double md2=maxD.d*maxD.d; int md=mode.i();
      for(Entity e:mc.world.getEntities()){ if(e==mc.player) continue; int c=Util.cat(e); if(c<0||!en(c)||mc.player.squaredDistanceTo(e)>md2) continue;
        int col=col(c); Box b=Util.lerpBox(e,td);
        // symmetric footprint so the box is centered on the entity from every angle
        Vec3d ct=b.getCenter(); double hw=Math.max(b.getLengthX(),b.getLengthZ())/2;
        Box sb=new Box(ct.x-hw,b.minY,ct.z-hw,ct.x+hw,b.maxY,ct.z+hw).offset(-cam.x,-cam.y,-cam.z);
        boolean vis=AbabClient.visible(new Vec3d(ct.x-cam.x,ct.y-cam.y,ct.z-cam.z),Math.max(hw,b.getLengthY())); double[] r=vis?R.rect(sb):null; if(trc.b) R.tracer(new Vec3d(ct.x-cam.x,b.minY-cam.y,ct.z-cam.z),col,false);
        if(md==0){ if(vis) R.box(m,sb,(fill.i()<<24)|(col&0xFFFFFF),col); } else if(r!=null) R.box2d(r,col,(fill.i()<<24)|(col&0xFFFFFF),md==2);
        if(r!=null){ T t=new T(); t.e=e; t.r=r; tg.add(t); } } }
    static String ab(String path,int lvl){ String[] p=path.split("_"); String s; if(p.length==1) s=Character.toUpperCase(path.charAt(0))+path.substring(1,Math.min(3,path.length())); else{ StringBuilder sb=new StringBuilder(); for(String x:p) sb.append(Character.toUpperCase(x.charAt(0))); s=sb.toString(); } return s+lvl; }
    public void onHud(DrawContext g,float td){
      TextRenderer tr=mc.textRenderer;
      for(T t:tg){ Entity e=t.e; if(e.isRemoved()) continue; int x=(int)((t.r[0]+t.r[2])/2), top=(int)t.r[1], bot=(int)t.r[3];
        if(hbar.b&&e instanceof LivingEntity le&&mode.i()!=0){ float h=le.getHealth()+le.getAbsorptionAmount(), mx=Math.max(1f,le.getMaxHealth()); int bx=(int)t.r[0]-4, hh=bot-top, f=(int)(hh*Math.min(1f,h/mx));
          g.fill(bx-1,top-1,bx+2,bot+1,0xAA000000); g.fill(bx,bot-f,bx+1,bot,h>14?0xFF3BFF6A:h>7?0xFFFFE23B:0xFFFF3B3B); }
        String label=""; if(names.b) label+="§f"+(e instanceof ItemEntity ie?ie.getStack().getName().getString()+" x"+ie.getStack().getCount():e.getName().getString());
        if(dist.b) label+=" §7"+(int)mc.player.distanceTo(e)+"m"; if(health.b&&e instanceof LivingEntity le){ float h=le.getHealth()+le.getAbsorptionAmount(); String hc=h>14?"§a":h>7?"§e":"§c"; label+=" "+hc+"♥"+(int)Math.ceil(h); }
        int y=top-2;
        if(!label.isEmpty()){ int w=tr.getWidth(label); g.fill(x-w/2-2,y-10,x+w/2+2,y,0x99000000); g.drawTextWithShadow(tr,label,x-w/2,y-9,0xFFFFFFFF); }
        if((armor.b||ench.b)&&e instanceof LivingEntity le){
          EquipmentSlot[] sl={EquipmentSlot.MAINHAND,EquipmentSlot.HEAD,EquipmentSlot.CHEST,EquipmentSlot.LEGS,EquipmentSlot.FEET,EquipmentSlot.OFFHAND};
          int cx=x-sl.length*14/2, iy=y-26;
          for(int i=0;i<sl.length;i++){ ItemStack s=le.getEquippedStack(sl[i]); if(s.isEmpty()) continue; int ix=cx+i*14;
            if(armor.b){ g.getMatrices().pushMatrix(); g.getMatrices().translate((float)(ix),(float)(iy)); g.getMatrices().scale(0.8f,0.8f); g.drawItem(s,0,0); g.getMatrices().popMatrix(); }
            if(ench.b){ int ly=iy-4; for(Object2IntMap.Entry<net.minecraft.registry.entry.RegistryEntry<net.minecraft.enchantment.Enchantment>> en:s.getEnchantments().getEnchantmentEntries()){
                String id=en.getKey().getKey().map(k->k.getValue().getPath()).orElse("?"); g.getMatrices().pushMatrix(); g.getMatrices().translate((float)(ix),(float)(ly)); g.getMatrices().scale(0.5f,0.5f);
                g.drawTextWithShadow(tr,ab(id,en.getIntValue()),0,0,0xFFFFE23B); g.getMatrices().popMatrix(); ly-=5; } } } } } } }

  public static class Tracers extends Module {
    Setting pl=bool("Players",true), ho=bool("Hostile",true), an=bool("Animals",true), it=bool("Items",false), ot=bool("OtherMobs",false), maxD=num("MaxDist",200,16,400,8),
      maxN=num("MaxCount",30,1,200,1), bottom=bool("FromBottom",false), fade=bool("FadeByDistance",true),
      cP=color("PlayerColor",0xFFFF3B3B), cH=color("HostileColor",0xFFFF9A1F), cA=color("AnimalColor",0xFF3BFF6A), cI=color("ItemColor",0xFFFFFFFF), cO=color("OtherColor",0xFF3BC8FF);
    final List<Entity> cand=new ArrayList<>(); final List<Double> dist=new ArrayList<>(); int fr;
    public Tracers(){ super("Tracers",Category.RENDER); }
    public void onRender(Matrix4f m,Vec3d cam,float td){
      // candidate list is rebuilt every 3rd frame and only the nearest MaxCount are drawn
      if(fr++%3==0){ cand.clear(); dist.clear(); double md2=maxD.d*maxD.d; List<Entity> all=new ArrayList<>();
        for(Entity e:mc.world.getEntities()){ if(e==mc.player) continue; int c=Util.cat(e); if(c<0) continue;
          boolean en=switch(c){ case 0->pl.b; case 1->ho.b; case 2->an.b; case 3->it.b; default->ot.b; }; if(!en||mc.player.squaredDistanceTo(e)>md2) continue; all.add(e); }
        all.sort(Comparator.comparingDouble(e->mc.player.squaredDistanceTo(e)));
        for(int i=0;i<Math.min(all.size(),maxN.i());i++){ cand.add(all.get(i)); dist.add((double)mc.player.distanceTo(all.get(i))); } }
      for(int i=0;i<cand.size();i++){ Entity e=cand.get(i); if(e.isRemoved()) continue; int c=Util.cat(e);
        int col=switch(c){ case 0->cP.c; case 1->cH.c; case 2->cA.c; case 3->cI.c; default->cO.c; };
        if(fade.b){ double f=Math.max(0.35,1-dist.get(i)/maxD.d); col=((int)(((col>>>24)&0xFF)*f)<<24)|(col&0xFFFFFF); }
        R.tracer(Util.lerpBox(e,td).getCenter().subtract(cam),col,bottom.b); } } }

  public static class StorageEsp extends Module {
    Setting mode=num("Mode",0,0,1,1), // 0 = 3D box, 1 = 2D box
      tChest=bool("Chests",true), tEnder=bool("EnderChests",true), tShulker=bool("Shulkers",true), tBarrel=bool("Barrels",true), tHopper=bool("Hoppers",false), tFurnace=bool("Furnaces",false), tDisp=bool("Dispensers",false),
      chest=color("Chest",0xFFFF9A1F), trapped=color("TrappedChest",0xFFFF3B3B), ender=color("EnderChest",0xFF3BC8FF), shulker=color("Shulker",0xFFFF6AD5), barrel=color("Barrel",0xFF3BFF6A), other=color("Other",0xFFB0B0B0), fill=num("FillAlpha",70,0,255,5), maxD=num("MaxDist",1024,32,2048,32), tracer=bool("Tracers",true), pre=bool("OnlySusChunks",false);
    final List<Box> boxes=new ArrayList<>(); final List<Integer> cols=new ArrayList<>(); int t;
    public StorageEsp(){ super("StorageESP",Category.RENDER); }
    public void onDisable(){ boxes.clear(); cols.clear(); }
    public void onTick(){ if(t++%20!=0) return; boxes.clear(); cols.clear(); int cx=mc.player.getChunkPos().x,cz=mc.player.getChunkPos().z,r=mc.options.getViewDistance().getValue();
      for(int x=-r;x<=r;x++) for(int z=-r;z<=r;z++){ WorldChunk c=mc.world.getChunkManager().getWorldChunk(cx+x,cz+z); if(c==null||(pre.b&&!Pack7.flagged(cx+x,cz+z))) continue;
        for(BlockEntity be:c.getBlockEntities().values()){ int col; BlockPos p=be.getPos(); BlockState st=be.getCachedState(); Box box=null;
          if(be instanceof EnderChestBlockEntity){ if(!tEnder.b) continue; col=ender.c; }
          else if(be instanceof ChestBlockEntity){ if(!tChest.b) continue; col=(be instanceof TrappedChestBlockEntity)?trapped.c:chest.c;
            if(st.getBlock() instanceof ChestBlock&&st.contains(ChestBlock.CHEST_TYPE)&&st.get(ChestBlock.CHEST_TYPE)!=net.minecraft.block.enums.ChestType.SINGLE){ // merge double chests into ONE box
              BlockPos o=p.offset(ChestBlock.getFacing(st)); if(o.asLong()<p.asLong()) continue; box=new Box(p).union(new Box(o)).contract(0.06,0.1,0.06); } }
          else if(be instanceof ShulkerBoxBlockEntity){ if(!tShulker.b) continue; col=shulker.c; }
          else if(be instanceof BarrelBlockEntity){ if(!tBarrel.b) continue; col=barrel.c; }
          else if(be instanceof HopperBlockEntity){ if(!tHopper.b) continue; col=other.c; }
          else if(be instanceof AbstractFurnaceBlockEntity){ if(!tFurnace.b) continue; col=other.c; }
          else if(be instanceof DispenserBlockEntity){ if(!tDisp.b) continue; col=other.c; }
          else continue;
          if(box==null){ VoxelShape sh=st.getOutlineShape(mc.world,p); box=sh.isEmpty()?new Box(p):sh.getBoundingBox().offset(p); }
          boxes.add(box); cols.add(col); } } }
    public void onRender(Matrix4f m,Vec3d cam,float td){ double md2=maxD.d*maxD.d;
      for(int i=0;i<boxes.size();i++){ int col=cols.get(i); Box w=boxes.get(i); Vec3d c=w.getCenter(); if(c.squaredDistanceTo(cam)>md2) continue; Box b=w.offset(-cam.x,-cam.y,-cam.z);
        int fl=(fill.i()<<24)|(col&0xFFFFFF); if(AbabClient.visible(b.getCenter(),2)){ if(mode.i()==0) R.box(m,b,fl,col); else R.box2d(R.rect(b),col,fl,false); }
        if(tracer.b) R.tracer(b.getCenter(),col,false); } } }

  public static class BlockEsp extends Module {
    public final Set<Block> blocks=new LinkedHashSet<>(); Setting color=color("Color",0xFF3BC8FF), multi=bool("ColorPerBlock",true), fill=num("FillAlpha",50,0,255,5), radius=num("Radius",16,4,32,2), maxDraw=num("MaxDraw",250,20,2000,10), tracer=bool("Tracers",true), pre=bool("OnlySusChunks",false);
    final List<BlockPos> found=new ArrayList<>(); final List<Integer> cols=new ArrayList<>(); int t;
    public BlockEsp(){ super("BlockESP",Category.RENDER); blocks.add(Blocks.DIAMOND_ORE); blocks.add(Blocks.DEEPSLATE_DIAMOND_ORE); blocks.add(Blocks.ANCIENT_DEBRIS); }
    public void onDisable(){ found.clear(); cols.clear(); }
    public void onTick(){ if(t++%15!=0) return; found.clear(); cols.clear(); if(blocks.isEmpty()) return; BlockPos c=mc.player.getBlockPos(); int r=radius.i(); BlockPos.Mutable mp=new BlockPos.Mutable();
      List<BlockPos> tmp=new ArrayList<>();
      for(int x=-r;x<=r;x++) for(int y=-r;y<=r;y++) for(int z=-r;z<=r;z++){ mp.set(c.getX()+x,c.getY()+y,c.getZ()+z); if(!blocks.contains(mc.world.getBlockState(mp).getBlock())) continue; if(pre.b&&!Pack7.flagged(mp.getX()>>4,mp.getZ()>>4)) continue; tmp.add(mp.toImmutable()); if(tmp.size()>6000) break; }
      tmp.sort(Comparator.comparingDouble(p->p.getSquaredDistance(c))); // nearest first -> MaxDraw keeps the closest ones
      for(int i=0;i<Math.min(tmp.size(),maxDraw.i());i++){ BlockPos p=tmp.get(i); found.add(p); int h=Registries.BLOCK.getId(mc.world.getBlockState(p).getBlock()).hashCode(); cols.add(multi.b?R.hsb((Math.abs(h)%360)/360f,0.8f,1f):color.c); } }
    public void onRender(Matrix4f m,Vec3d cam,float td){
      for(int i=0;i<found.size();i++){ BlockPos p=found.get(i); int col=cols.get(i); Box b=new Box(p).offset(-cam.x,-cam.y,-cam.z); if(AbabClient.visible(b.getCenter(),1.5)) R.box(m,b,(fill.i()<<24)|(col&0xFFFFFF),col); if(tracer.b) R.tracer(b.getCenter(),col,false); } } }

  public static class HoleEsp extends Module { Setting bed=color("Bedrock",0xFF3BFF6A), obi=color("Obsidian",0xFFFF9A1F), radius=num("Radius",8,3,16,1), fill=num("FillAlpha",70,0,255,5), pre=bool("OnlySusChunks",false);
    final List<BlockPos> hs=new ArrayList<>(); final List<Boolean> bd=new ArrayList<>(); int t; public HoleEsp(){ super("HoleESP",Category.RENDER); }
    public void onTick(){ if(t++%10!=0) return; hs.clear(); bd.clear(); BlockPos c=mc.player.getBlockPos(); int r=radius.i();
      for(int x=-r;x<=r;x++) for(int y=-r/2;y<=r/2;y++) for(int z=-r;z<=r;z++){ BlockPos p=c.add(x,y,z); if(pre.b&&!Pack7.flagged(p.getX()>>4,p.getZ()>>4)) continue; if(!mc.world.getBlockState(p).isAir()||!mc.world.getBlockState(p.up()).isAir()||mc.world.getBlockState(p.down()).isAir()) continue;
        boolean ok=true,allBed=true; for(Direction d:Direction.Type.HORIZONTAL){ Block b=mc.world.getBlockState(p.offset(d)).getBlock(); if(b==Blocks.BEDROCK) continue; allBed=false; if(b!=Blocks.OBSIDIAN){ ok=false; break; } }
        Block dn=mc.world.getBlockState(p.down()).getBlock(); if(dn!=Blocks.BEDROCK&&dn!=Blocks.OBSIDIAN) ok=false; if(ok){ hs.add(p); bd.add(allBed); } } }
    public void onRender(Matrix4f m,Vec3d cam,float td){ for(int i=0;i<hs.size();i++){ BlockPos p=hs.get(i); int col=bd.get(i)?bed.c:obi.c; R.box(m,new Box(p.getX(),p.getY(),p.getZ(),p.getX()+1,p.getY()+0.08,p.getZ()+1).offset(-cam.x,-cam.y,-cam.z),(fill.i()<<24)|(col&0xFFFFFF),col); } } }
}
