package ru.abab.mods;
import java.nio.file.*;
import java.util.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.*;
import net.minecraft.world.chunk.*;
import org.joml.Matrix4f;
import ru.abab.AbabClient;
import ru.abab.core.Module;
import ru.abab.core.*;

/** Batch 7: SusChunk v3 (base hunter), SpearAura, BackCTP, scaffold item, whitelist storage, pre-filter helper. */
public final class Pack7 {
  static SusChunk SC;
  public static void register(List<Module> l){ SC=new SusChunk(); l.addAll(List.of(SC,new SpearAura(),new BackCTP())); }
  static Path cfg(String n){ return FabricLoader.getInstance().getConfigDir().resolve(n); }

  // ---------- pre-filter used by StorageESP / BlockESP / XRay / HoleESP / Spawner/Bed/... finders ("OnlySusChunks") ----------
  public static boolean flagged(int cx,int cz){ if(SC==null||!SC.on) return true; return SC.isFlagged(cx,cz); }

  // ---------- scaffold item (CrystalPvP) + SusChunk whitelist, saved in config/ ----------
  public static Item scaffoldItem=Items.OBSIDIAN; static boolean loaded; static String lastSaved="";
  public static final Set<Block> WL=new LinkedHashSet<>();
  static void load(){ if(loaded) return; loaded=true;
    try{ Path f=cfg("abab-scaffold.txt"); if(Files.exists(f)){ Item it=Registries.ITEM.get(Identifier.tryParse(Files.readString(f).trim())); if(it!=Items.AIR) scaffoldItem=it; } }catch(Exception e){ e.printStackTrace(); }
    try{ Path f=cfg("abab-sus-whitelist.txt"); if(Files.exists(f)) for(String s:Files.readAllLines(f)){ if(s.isBlank()) continue; Block b=Registries.BLOCK.get(Identifier.tryParse("minecraft:"+s.trim())); if(b!=Blocks.AIR) WL.add(b); } }catch(Exception e){ e.printStackTrace(); } }
  /** called from Config.save(): writes only when something changed */
  public static void saveExtra(){ if(!loaded) return; StringBuilder sb=new StringBuilder(Registries.ITEM.getId(scaffoldItem).toString()).append('|'); for(Block b:WL) sb.append(Registries.BLOCK.getId(b).getPath()).append(',');
    String now=sb.toString(); if(now.equals(lastSaved)) return; lastSaved=now;
    try{ Files.writeString(cfg("abab-scaffold.txt"),Registries.ITEM.getId(scaffoldItem).toString()); List<String> l=new ArrayList<>(); for(Block b:WL) l.add(Registries.BLOCK.getId(b).getPath()); Files.write(cfg("abab-sus-whitelist.txt"),l); }catch(Exception e){ e.printStackTrace(); } }
  public static Set<Block> whitelist(){ load(); return WL; }
  public static Item scaffold(){ load(); return scaffoldItem; }
  public static void setScaffold(Item i){ scaffoldItem=i; saveExtra(); }

  // ===== SusChunk v3 =====
  //  * scores every loaded chunk: block entities (chests, trapped chests, barrels, furnaces, hoppers, shulkers, beds, signs, spawners), unnatural blocks for the dimension
  //    (obsidian, smooth stone, glass, planks/stripped wood, concrete, wool, nether blocks in the overworld...), valuable blocks, redstone, rails...
  //  * big farms: bamboo, kelp, sea pickles, sugar cane, cactus, melons/pumpkins, crops, nether wart...
  //  * chunk age: OLD = generated before 1.18 (no deepslate), NEW = 1.18+ terrain.  (Overworld only)
  //  * world overlay (colored plane + edge lines + optional tracers), screen labels, minimap; other ESPs can use it as a pre-filter ("OnlySusChunks").
  public static class SusChunk extends Module {
    record Info(float score,int be,int farm,boolean old,boolean known){}
    static final Map<Block,Float> W=new HashMap<>(); static final Map<Block,String> PATH=new HashMap<>(); static String dimCache="";
    static String path(Block b){ return PATH.computeIfAbsent(b,x->Registries.BLOCK.getId(x).getPath()); }
    static boolean farmBlock(String p){ return p.equals("bamboo")||p.equals("kelp")||p.equals("kelp_plant")||p.equals("sea_pickle")||p.equals("sugar_cane")||p.equals("cactus")||p.equals("melon")||p.equals("pumpkin")||p.equals("wheat")||p.equals("carrots")||p.equals("potatoes")||p.equals("beetroots")||p.equals("nether_wart")||p.equals("sweet_berry_bush")||p.equals("cocoa"); }
    static boolean beBlock(String p){ return p.contains("chest")||p.equals("barrel")||p.contains("shulker_box")||p.contains("furnace")||p.equals("smoker")||p.equals("hopper")||p.equals("dropper")||p.equals("dispenser")||p.endsWith("_bed")||p.endsWith("_sign")||p.equals("spawner")||p.equals("trial_spawner")||p.equals("brewing_stand"); }
    float calc(Block b,String dim){ String p=path(b);
      if(p.contains("air")||farmBlock(p)) return 0;
      if(p.contains("chest")||p.equals("barrel")||p.contains("shulker_box")) return 2.5f;
      if(p.contains("furnace")||p.equals("smoker")||p.equals("hopper")||p.equals("dropper")||p.equals("dispenser")||p.equals("brewing_stand")||p.equals("crafting_table")||p.equals("enchanting_table")||p.equals("anvil")||p.equals("spawner")) return 1.5f;
      if(p.endsWith("_bed")||p.endsWith("_sign")||p.endsWith("_banner")) return 1.2f;
      if(p.equals("netherite_block")||p.equals("diamond_block")||p.equals("emerald_block")||p.equals("gold_block")||p.equals("iron_block")||p.equals("lapis_block")||p.equals("beacon")) return 3f;
      if(p.equals("torch")||p.equals("wall_torch")||p.equals("lantern")||p.equals("soul_lantern")||p.contains("rail")||p.equals("redstone_wire")||p.equals("repeater")||p.equals("comparator")||p.equals("piston")||p.equals("sticky_piston")||p.equals("observer")||p.equals("redstone_lamp")||p.equals("tnt")||p.equals("bookshelf")) return 0.5f;
      if(p.equals("obsidian")||p.equals("crying_obsidian")) return dim.equals("the_end")?0:0.5f;
      if(p.equals("smooth_stone")||p.startsWith("polished_")||p.startsWith("cut_")||p.startsWith("stripped_")||p.endsWith("_concrete")||p.endsWith("_concrete_powder")||p.endsWith("_wool")||p.endsWith("_carpet")||p.endsWith("glass")||p.endsWith("glass_pane")||p.endsWith("_planks")) return 0.4f;
      if(p.endsWith("_door")||p.endsWith("_trapdoor")||p.endsWith("_fence")||p.endsWith("_fence_gate")||p.endsWith("_stairs")||p.endsWith("_slab")) return 0.25f;
      boolean netherLike=p.contains("netherrack")||p.contains("nether_brick")||p.equals("soul_sand")||p.equals("soul_soil")||p.contains("basalt")||p.contains("blackstone")||p.equals("magma_block")||p.startsWith("crimson_")||p.startsWith("warped_")||p.equals("glowstone")||p.contains("quartz_block");
      if(netherLike&&dim.equals("overworld")) return 0.4f;
      boolean overLike=p.equals("cobblestone")||p.equals("stone_bricks")||p.equals("dirt")||p.equals("grass_block")||p.equals("oak_log")||p.endsWith("_leaves");
      if(overLike&&(dim.equals("the_nether")||dim.equals("the_end"))) return 0.4f;
      return 0; }
    float weigh(Block b,String dim){ if(WL.contains(b)) return 0; if(!dim.equals(dimCache)){ W.clear(); dimCache=dim; } return W.computeIfAbsent(b,x->calc(x,dim)); }
    Setting center=color("CenterColor",0xFFFF1E1E), edge=color("EdgeColor",0xFFFFFFFF), csize=num("CenterSize",70,0,100,5), fillA=num("FillAlpha",90,0,255,5),
      dist=num("RenderDistance",10,2,32,1), minScore=num("MinScore",10,1,500,1), minBE=num("MinBlockEntities",3,0,50,1), farmMin=num("FarmMin",350,50,5000,50), age=num("ChunkAge",0,0,2,1),
      per=num("ScansPerTick",2,1,10,1), maxShow=num("MaxShow",24,3,200,1), up=num("HeightAboveYou",0,-30,60,1), labels=bool("Labels",true), tr=num("TracerCount",3,0,20,1),
      mini=bool("Minimap",true), msize=num("MinimapSize",11,5,25,2), mx=num("MapX%",98,0,100,1), my=num("MapY%",24,0,100,1);
    final Map<Long,Info> info=new HashMap<>(); final Map<Long,Integer> last=new HashMap<>(); final List<long[]> flags=new ArrayList<>(); int tick; Object world;
    public SusChunk(){ super("SusChunk",Category.RENDER); load(); }
    public void onDisable(){ info.clear(); last.clear(); flags.clear(); }
    boolean sus(Info i){ if(i==null) return false; if(age.i()==1&&i.known()&&!i.old()) return false; if(age.i()==2&&i.known()&&i.old()) return false;
      return i.score()>=minScore.d||(minBE.i()>0&&i.be()>=minBE.i())||i.farm()>=farmMin.d; }
    public boolean isFlagged(int cx,int cz){ return sus(info.get(ChunkPos.toLong(cx,cz))); }
    Info scan(WorldChunk c,String dim){ float s=0; int farm=0, be=0; boolean overworld=dim.equals("overworld"), low=false, deep=false; int bottom=mc.world.getBottomSectionCoord();
      for(BlockEntity b:c.getBlockEntities().values()) if(beBlock(path(b.getCachedState().getBlock()))) be++;
      ChunkSection[] secs=c.getSectionArray();
      for(int i=0;i<secs.length;i++){ ChunkSection sec=secs[i]; if(sec==null||sec.isEmpty()) continue; int sy=bottom+i;
        if(overworld&&sy<0){ low=true; if(!deep&&sec.hasAny(st->st.isOf(Blocks.DEEPSLATE))) deep=true; }
        if(!sec.hasAny(st->{ String p=path(st.getBlock()); return farmBlock(p)||weigh(st.getBlock(),dim)>0; })) continue;
        for(int x=0;x<16;x++) for(int y=0;y<16;y++) for(int z=0;z<16;z++){ Block b=sec.getBlockState(x,y,z).getBlock(); String p=path(b); if(farmBlock(p)){ farm++; continue; } float w=weigh(b,dim); if(w>0) s+=w; } }
      return new Info(s,be,farm,overworld&&low&&!deep,overworld&&low); }
    public void onTick(){ tick++; String dim=mc.world.getRegistryKey().getValue().getPath(); if(world!=mc.world){ world=mc.world; info.clear(); last.clear(); }
      int vd=Math.min(dist.i(),mc.options.getViewDistance().getValue()), n=0, lim=per.i(); ChunkPos pc=mc.player.getChunkPos();
      for(int r=0;r<=vd&&n<lim;r++) for(int dx=-r;dx<=r&&n<lim;dx++) for(int dz=-r;dz<=r&&n<lim;dz++){ if(Math.max(Math.abs(dx),Math.abs(dz))!=r) continue;
        long k=ChunkPos.toLong(pc.x+dx,pc.z+dz); Integer l=last.get(k); if(l!=null&&tick-l<400) continue; WorldChunk c=mc.world.getChunkManager().getWorldChunk(pc.x+dx,pc.z+dz); if(c==null) continue;
        info.put(k,scan(c,dim)); last.put(k,tick); n++; }
      if(tick%10==0) rebuild(vd,pc); }
    void rebuild(int vd,ChunkPos pc){ flags.clear(); List<Map.Entry<Long,Info>> l=new ArrayList<>();
      for(Map.Entry<Long,Info> e:info.entrySet()){ ChunkPos cp=new ChunkPos(e.getKey()); if(Math.abs(cp.x-pc.x)>vd||Math.abs(cp.z-pc.z)>vd||!sus(e.getValue())) continue; l.add(e); }
      l.sort((a,b)->Float.compare(b.getValue().score()+b.getValue().be()*3,a.getValue().score()+a.getValue().be()*3));
      for(int i=0;i<Math.min(l.size(),maxShow.i());i++){ ChunkPos cp=new ChunkPos(l.get(i).getKey()); flags.add(new long[]{cp.x,cp.z,l.get(i).getKey()}); } }
    public void onRender(Matrix4f m,Vec3d cam,float td){ double y=mc.player.getY()+up.d; int cc=center.c&0xFFFFFF, ee=edge.c&0xFFFFFF; double off=8*(1-csize.d/100.0); int shown=0;
      for(long[] f:flags){ Info i=info.get(f[2]); if(i==null) continue; double x=f[0]*16, z=f[1]*16; int a=(int)Math.max(35,Math.min(fillA.d,(i.score()/(minScore.d*3))*fillA.d)); if(i.farm()>=farmMin.d&&i.score()<minScore.d) a=(int)(fillA.d*0.6);
        double cx=x+8-cam.x, cz=z+8-cam.z; if(!AbabClient.visible(new Vec3d(cx,y-cam.y,cz),12)){ if(shown<tr.i()) R.tracer(new Vec3d(cx,y-cam.y,cz),0xFF000000|cc,false); shown++; continue; }
        Vec3d[] outer={new Vec3d(x-cam.x,y-cam.y,z-cam.z),new Vec3d(x+16-cam.x,y-cam.y,z-cam.z),new Vec3d(x+16-cam.x,y-cam.y,z+16-cam.z),new Vec3d(x-cam.x,y-cam.y,z+16-cam.z)};
        R.quad(outer,((a/3)<<24)|ee,0xFF000000|ee);
        if(csize.d>0){ Vec3d[] in={new Vec3d(x+off-cam.x,y-cam.y,z+off-cam.z),new Vec3d(x+16-off-cam.x,y-cam.y,z+off-cam.z),new Vec3d(x+16-off-cam.x,y-cam.y,z+16-off-cam.z),new Vec3d(x+off-cam.x,y-cam.y,z+16-off-cam.z)}; R.quad(in,(a<<24)|cc,0); }
        for(Vec3d v:outer) R.seg3(v,v.add(0,6,0),0xAA000000|ee);
        if(shown<tr.i()) R.tracer(new Vec3d(cx,y-cam.y,cz),0xFF000000|cc,false); shown++; } }
    public void onHud(DrawContext g,float td){ double y=mc.player.getY()+up.d; int w=mc.getWindow().getScaledWidth(), h=mc.getWindow().getScaledHeight();
      if(labels.b){ int n=0; for(long[] f:flags){ if(n++>=10) break; Info i=info.get(f[2]); if(i==null) continue; Vec3d s=AbabClient.project(new Vec3d(f[0]*16+8,y+1,f[1]*16+8)); if(s==null) continue;
          String t="§cSUS §f"+(int)i.score()+(i.be()>0?" §eBE"+i.be():"")+(i.farm()>=farmMin.d?" §aFARM":"")+(i.known()?(i.old()?" §6OLD":" §bNEW"):"")+" §7"+(int)Math.hypot(f[0]*16+8-mc.player.getX(),f[1]*16+8-mc.player.getZ())+"m"; int tw=mc.textRenderer.getWidth(t);
          g.fill((int)s.x-tw/2-2,(int)s.y-10,(int)s.x+tw/2+2,(int)s.y,0x99000000); g.drawTextWithShadow(mc.textRenderer,t,(int)s.x-tw/2,(int)s.y-9,0xFFFFFFFF); } }
      if(mini.b){ int n=msize.i(), cell=4, side=n*cell; int bx=(int)((w-side-6)*mx.d/100.0)+3, by=(int)((h-side-6)*my.d/100.0)+3; ChunkPos pc=mc.player.getChunkPos();
        g.fill(bx-1,by-1,bx+side+1,by+side+1,0xCC000000); g.fill(bx,by,bx+side,by+side,0x66222233);
        for(int dz=-n/2;dz<=n/2;dz++) for(int dx=-n/2;dx<=n/2;dx++){ Info i=info.get(ChunkPos.toLong(pc.x+dx,pc.z+dz)); int px=bx+(dx+n/2)*cell, pz=by+(dz+n/2)*cell;
          if(i==null){ g.fill(px,pz,px+cell-1,pz+cell-1,0x33111111); continue; }
          int col=sus(i)?(0xFF000000|(center.c&0xFFFFFF)):(i.score()>minScore.d*0.4?0x66FFB03B:0x44445566); if(sus(i)&&i.known()) col=i.old()?(0xFF000000|(center.c&0xFFFFFF)):0xFF3BC8FF; g.fill(px,pz,px+cell-1,pz+cell-1,col); }
        double fx=(mc.player.getX()-pc.getStartX())/16.0, fz=(mc.player.getZ()-pc.getStartZ())/16.0; int px=bx+(n/2)*cell+(int)(fx*cell), pz=by+(n/2)*cell+(int)(fz*cell); g.fill(px-1,pz-1,px+2,pz+2,0xFFFFFFFF); } }
  }

  // ===== SpearAura: auto-selects a spear and keeps striking the NEAREST target in range. Mode 0 = teleport strikes (back and forth with packets), Mode 1 = really fly in and out =====
  public static class SpearAura extends Module {
    final Extra.SpearKill core=new Extra.SpearKill();
    Setting mode=num("Mode",0,0,2,1), range=num("Range",20,3,100,1), speed=num("Speed",3,0.5,10,0.5), back=num("BackDist",12,3,60,1), delay=num("Delay",6,1,40,1), pl=bool("Players",true), mobs=bool("Mobs",false), auto=bool("AutoSelectSpear",true);
    public SpearAura(){ super("SpearAura",Category.COMBAT); }
    static boolean spear(ItemStack s){ return Registries.ITEM.getId(s.getItem()).getPath().endsWith("_spear"); }
    public void onDisable(){ core.onDisable(); }
    public void onTick(){ core.mode.d=mode.d; core.range.d=range.d; core.speed.d=speed.d; core.back.d=back.d; core.delay.d=delay.d; core.maxTp.d=9; core.predict.b=true; core.hold.b=false; core.cont.b=true; core.pl.b=pl.b; core.mobs.b=mobs.b; core.nearest.b=true;
      if(auto.b){ int s=Util.findHotbar(SpearAura::spear); if(s>=0&&s!=Util.sel()) Util.sel(s); }
      core.onTick(); }
  }

  // ===== BackCTP: when an enemy places a crystal near you -> teleport back out of its damage range; if it lands right next to you -> vclip up/down instead =====
  public static class BackCTP extends Module {
    Setting safe=num("SafeDistance",12.5,4,40,0.5), near=num("VClipWhenWithin",3,1,8,0.5), vdown=num("VClipDown",-10,-60,0,1), vup=num("VClipUp",10,0,60,1), useV=bool("UseVClip",true), useBack=bool("UseBack",true), ret=num("ReturnAfterTicks",40,0,400,5), enemyR=num("EnemyRadius",9,3,20,1);
    final Set<Integer> seen=new HashSet<>(); Vec3d home; int back;
    public BackCTP(){ super("BackCTP",Category.COMBAT); }
    public void onDisable(){ seen.clear(); home=null; back=0; }
    boolean free(Vec3d from,Vec3d to){ return mc.world.isSpaceEmpty(mc.player,mc.player.getBoundingBox().offset(to.subtract(from))); }
    void go(Vec3d to){ Vec3d o=mc.player.getEntityPos(); Extra.SpearKill.pk(o,to,false); mc.player.setPosition(to); }
    void handle(Entity c){ boolean enemy=false; for(PlayerEntity p:mc.world.getPlayers()) if(p!=mc.player&&p.isAlive()&&p.distanceTo(c)<=enemyR.d){ enemy=true; break; } if(!enemy) return;
      Vec3d o=mc.player.getEntityPos(); double d=mc.player.distanceTo(c);
      if(useV.b&&d<=near.d){ for(double dy:new double[]{vdown.d,vup.d}){ if(dy==0) continue; Vec3d t=o.add(0,dy,0); if(free(o,t)){ go(t); return; } } }
      if(useBack.b&&d<safe.d){ Vec3d dir=o.subtract(c.getEntityPos()).multiply(1,0,1); if(dir.length()<0.01) dir=new Vec3d(1,0,0); dir=dir.normalize(); double need=safe.d+0.7;
        for(double dy:new double[]{0,1,-1,2,-2}){ Vec3d t=new Vec3d(c.getX()+dir.x*need,o.y+dy,c.getZ()+dir.z*need); if(free(o,t)){ if(home==null) home=o; go(t); back=ret.i(); return; } } } }
    public void onTick(){ boolean any=false; for(Entity e:mc.world.getEntities()) if(e.getType()==EntityType.END_CRYSTAL){ any=true; if(seen.add(e.getId())) handle(e); }
      if(!any) seen.clear(); else if(mc.player.age%200==0){ Set<Integer> now=new HashSet<>(); for(Entity e:mc.world.getEntities()) now.add(e.getId()); seen.retainAll(now); }
      if(home!=null&&back>0&&--back==0){ Vec3d o=mc.player.getEntityPos(); if(free(o,home)) go(home); home=null; } }
  }
}
