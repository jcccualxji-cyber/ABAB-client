package ru.abab.mods;
import java.nio.file.*;
import java.util.*;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.entity.*;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.*;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.*;
import ru.abab.core.Module;
import ru.abab.core.*;

/** Batch 8: hit modes (crit / sweep) for aura modules, TPToPlayer, HitSound (+mute vanilla), ChatStyle. */
public final class Pack8 {
  public static void register(List<Module> l){ l.addAll(List.of(new TPToPlayer(),new HitSound(),new ChatStyle())); }
  static Path cfg(String n){ return FabricLoader.getInstance().getConfigDir().resolve(n); }

  // ---------- critical / sweeping hits ----------
  static boolean sprintWas;
  /** crit packets: tiny fake jump so the server counts the next hit as a critical */
  public static void crit(Vec3d at){ for(double y:new double[]{0.11,0.1100013579,0.0000013579}) Util.send(new PlayerMoveC2SPacket.PositionAndOnGround(at.x,at.y+y,at.z,false,false)); }
  /** mode: 0 normal, 1 crit, 2 sweep (stops sprinting for the hit), 3 auto (sweep when another mob/player stands next to the target, crit otherwise) */
  public static void pre(int mode,Entity t){ int m=mode;
    if(m==3){ int near=0; for(Entity e:Module.mc.world.getOtherEntities(t,t.getBoundingBox().expand(1.5,0.25,1.5))) if(e instanceof LivingEntity&&e!=Module.mc.player) near++; m=near>=1?2:1; }
    if(m==1) crit(Module.mc.player.getEntityPos());
    else if(m==2&&Module.mc.player.isSprinting()){ sprintWas=true; Module.mc.player.setSprinting(false); Util.send(new ClientCommandC2SPacket(Module.mc.player,ClientCommandC2SPacket.Mode.STOP_SPRINTING)); } }
  public static void post(){ if(sprintWas){ sprintWas=false; Module.mc.player.setSprinting(true); Util.send(new ClientCommandC2SPacket(Module.mc.player,ClientCommandC2SPacket.Mode.START_SPRINTING)); } }

  // ===== TPToPlayer: teleports you to the nearest player. Route: straight line if it is free, otherwise over the top (sky route) so walls do not matter;
  //       if no safe route exists (or the server pulls you back) it flies toward them until a route is possible. Up to 5 packets / ~22 blocks per tick is what vanilla servers accept. =====
  public static class TPToPlayer extends Module {
    Setting bpt=num("BlocksPerTick",20,2,120,1), maxD=num("MaxDistance",300,20,3000,10), stop=num("StopDistance",2.5,1,6,0.5), flyFb=bool("FlightFallback",true), sky=bool("SkyRoute",true), autoOff=bool("AutoDisable",false);
    List<Vec3d> path=new ArrayList<>(); int replan,fail,flyTicks; Vec3d expected;
    public TPToPlayer(){ super("TPToPlayer",Category.MOVEMENT); }
    public void onDisable(){ path.clear(); expected=null; fail=0; flyTicks=0; }
    boolean free(Vec3d p){ return mc.world.isSpaceEmpty(mc.player,mc.player.getBoundingBox().offset(p.x-mc.player.getX(),p.y-mc.player.getY(),p.z-mc.player.getZ())); }
    boolean lineFree(Vec3d a,Vec3d b){ double len=a.distanceTo(b); int n=(int)Math.ceil(len/0.75); for(int i=1;i<=n;i++) if(!free(a.lerp(b,i/(double)n))) return false; return true; }
    List<Vec3d> plan(Vec3d me,Vec3d to){ List<Vec3d> p=new ArrayList<>();
      if(lineFree(me,to)){ p.add(to); return p; }
      if(sky.b){ double top=mc.world.getBottomY()+mc.world.getHeight()-4; Vec3d up=new Vec3d(me.x,top,me.z), over=new Vec3d(to.x,top,to.z);
        if(lineFree(me,up)&&lineFree(up,over)&&lineFree(over,to)){ p.add(up); p.add(over); p.add(to); return p; } }
      return null; }
    void fly(Vec3d to){ Vec3d d=to.subtract(mc.player.getEntityPos()); if(d.length()<0.01) return; mc.player.setVelocity(d.normalize().multiply(Math.min(1.2,d.length()))); mc.player.fallDistance=0; }
    public void onTick(){ PlayerEntity t=null; double bd=maxD.d; for(PlayerEntity p:mc.world.getPlayers()){ if(p==mc.player||!p.isAlive()||p.isSpectator()) continue; double d=mc.player.distanceTo(p); if(d<bd){ bd=d; t=p; } }
      if(t==null) return; Vec3d me=mc.player.getEntityPos(), to=t.getEntityPos(); double dist=me.distanceTo(to);
      if(dist<=stop.d){ path.clear(); if(autoOff.b) set(false); return; }
      if(expected!=null&&me.distanceTo(expected)>2.5) fail++; expected=null; if(fail>=3){ fail=0; flyTicks=40; path.clear(); }
      if(flyTicks>0){ flyTicks--; fly(to); return; }
      if(--replan<=0||path.isEmpty()){ List<Vec3d> np=plan(me,to); replan=10; if(np==null){ path.clear(); if(flyFb.b) fly(to); return; } path=np; }
      double per=bpt.d/5.0; Vec3d cur=me; List<Vec3d> out=new ArrayList<>();
      for(int k=0;k<5&&!path.isEmpty();k++){ double left=per; while(left>1e-6&&!path.isEmpty()){ Vec3d wp=path.get(0); double d=cur.distanceTo(wp); if(d<=left){ cur=wp; left-=d; path.remove(0); } else { cur=cur.lerp(wp,left/d); left=0; } } out.add(cur); }
      for(Vec3d v:out) Util.send(new PlayerMoveC2SPacket.PositionAndOnGround(v.x,v.y,v.z,false,false));
      mc.player.setPosition(cur); mc.player.setVelocity(Vec3d.ZERO); mc.player.fallDistance=0; expected=cur; }
  }

  // ===== HitSound: your own sounds when you hit a player, when a crystal appears near you, when someone pops a totem. Can also mute the vanilla sounds (SoundMixin). =====
  public static class HitSound extends Module {
    static final String[] SND={"off","block.note_block.pling","entity.experience_orb.pickup","entity.arrow.hit_player","block.anvil.land","entity.player.levelup","block.amethyst_block.chime","entity.ender_eye.death","block.bell.use","entity.firework_rocket.blast","block.note_block.bell","block.note_block.chime","entity.lightning_bolt.thunder","item.trident.return","block.beacon.activate","entity.villager.yes","block.glass.break","ui.toast.challenge_complete","entity.blaze.hurt","block.note_block.hat","block.note_block.xylophone"};
    static HitSound I;
    Setting hit=num("HitSound",1,0,20,1), crystal=num("CrystalSound",5,0,20,1), pop=num("PopSound",8,0,20,1), vol=num("Volume",1,0.1,2,0.1), pitch=num("Pitch",1.2,0.5,2,0.05), vary=bool("RandomPitch",true),
      muteHit=bool("MuteVanillaHit",true), muteTotem=bool("MuteVanillaTotem",false), muteExp=bool("MuteVanillaExplosion",false);
    final Set<Integer> seen=new HashSet<>(); final Map<UUID,Integer> last=new HashMap<>(); int tick;
    public HitSound(){ super("HitSound",Category.PLAYER); I=this;
      AttackEntityCallback.EVENT.register((pl,w,h,e,hr)->{ if(on&&pl==mc.player&&e instanceof PlayerEntity) play(hit.i()); return ActionResult.PASS; }); }
    public static boolean muted(String path){ HitSound s=I; if(s==null||!s.on) return false;
      return (s.muteHit.b&&path.startsWith("entity.player.attack"))||(s.muteTotem.b&&path.equals("item.totem.use"))||(s.muteExp.b&&path.equals("entity.generic.explode")); }
    void play(int idx){ if(idx<=0||idx>=SND.length) return; float p=(float)pitch.d+(vary.b?(float)(Math.random()*0.2-0.1):0f);
      mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvent.of(Identifier.of("minecraft",SND[idx])),p,(float)vol.d)); }
    public void onDisable(){ seen.clear(); }
    public void onTick(){ tick++; boolean any=false;
      for(Entity e:mc.world.getEntities()) if(e.getType()==EntityType.END_CRYSTAL){ any=true; if(seen.add(e.getId())&&mc.player.distanceTo(e)<=10) play(crystal.i()); }
      if(!any) seen.clear();
      if(pop.i()>0) for(PlayerEntity p:mc.world.getPlayers()){ var reg=p.getStatusEffect(StatusEffects.REGENERATION); var ab=p.getStatusEffect(StatusEffects.ABSORPTION);
        if(reg!=null&&ab!=null&&reg.getAmplifier()==1&&ab.getAmplifier()==1&&reg.getDuration()>=860&&tick-last.getOrDefault(p.getUuid(),-100)>=40){ last.put(p.getUuid(),tick); play(pop.i()); } }
      if(last.size()>200) last.clear(); }
  }

  // ===== ChatStyle: adds your prefix / suffix to every message you send and can restyle the letters (edit the texts in the module menu) =====
  public static String prefix="", suffix=" -ABAB CLIENT"; static boolean loaded; static ChatStyle CS;
  static void load(){ if(loaded) return; loaded=true; try{ Path f=cfg("abab-chat.txt"); if(Files.exists(f)){ List<String> l=Files.readAllLines(f); if(l.size()>0) prefix=l.get(0); if(l.size()>1) suffix=l.get(1); } }catch(Exception e){ e.printStackTrace(); } }
  public static void saveTexts(String p,String s){ prefix=p; suffix=s; try{ Files.write(cfg("abab-chat.txt"),List.of(p,s)); }catch(Exception e){ e.printStackTrace(); } }
  public static final String[] STYLES={"normal","small caps","fullwidth","circled","bold","alternating"};
  public static String restyle(String s,int style){ if(style<=0) return s; StringBuilder b=new StringBuilder(); int idx=0;
    for(int i=0;i<s.length();i++){ char c=s.charAt(i); boolean lo=c>='a'&&c<='z', up=c>='A'&&c<='Z', dg=c>='0'&&c<='9';
      switch(style){
        case 1 -> { if(lo||up){ String sc="ᴀʙᴄᴅᴇғɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢ"; b.append(sc.charAt(Character.toLowerCase(c)-'a')); } else b.append(c); }
        case 2 -> { if(lo||up||dg) b.appendCodePoint((c>='0'&&c<='9'?0xFF10:(lo?0xFF41:0xFF21))+(dg?c-'0':(lo?c-'a':c-'A'))); else if(c==' ') b.append('\u3000'); else b.append(c); }
        case 3 -> { if(lo) b.appendCodePoint(0x24D0+(c-'a')); else if(up) b.appendCodePoint(0x24B6+(c-'A')); else b.append(c); }
        case 4 -> { if(lo) b.appendCodePoint(0x1D41A+(c-'a')); else if(up) b.appendCodePoint(0x1D400+(c-'A')); else b.append(c); }
        default -> { if(lo||up){ b.append((idx++%2==0)?Character.toLowerCase(c):Character.toUpperCase(c)); } else b.append(c); } } }
    return b.toString(); }
  /** the text that is really sent for a chat message (also used by Spam) */
  public static String styled(String msg){ load(); ChatStyle c=CS; if(c==null||!c.on) return msg; String body=restyle(msg,c.style.i()); String suf=c.useSuffix.b?(c.styleSuffix.b?restyle(suffix,c.style.i()):suffix):""; String pre=c.usePrefix.b?prefix:"";
    String out=pre+body+suf; return out.length()>256?out.substring(0,256):out; }
  public static class ChatStyle extends Module {
    Setting style=num("Style",0,0,5,1), usePrefix=bool("Prefix",false), useSuffix=bool("Suffix",true), styleSuffix=bool("StyleTheSuffix",false);
    public ChatStyle(){ super("ChatStyle",Category.PLAYER); CS=this; load();
      ClientSendMessageEvents.MODIFY_CHAT.register(m->{ if(!on||m.startsWith(".")) return m; return styled(m); }); }
  }
}
