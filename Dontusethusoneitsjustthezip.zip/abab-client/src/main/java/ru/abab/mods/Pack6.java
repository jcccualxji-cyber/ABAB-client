package ru.abab.mods;
import java.nio.file.*;
import java.util.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.entity.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;
import net.minecraft.network.packet.c2s.play.*;
import net.minecraft.registry.Registries;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.*;
import net.minecraft.world.chunk.*;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;
import ru.abab.AbabClient;
import ru.abab.core.Module;
import ru.abab.core.*;

/** Batch 6: real NoClip, Phase, CrystalPvP, new SusChunk, Spam, InventoryMove, YawLock, FastFall, HoleSnap, AutoPanic, Crosshair. */
public final class Pack6 {
  static Crosshair CH; static NoClip NC;
  public static void register(List<Module> l){
    CH=new Crosshair(); NC=new NoClip();
    l.addAll(List.of(NC,new Phase(),new CrystalPvP(),new Spam(),new InventoryMove(),new YawLock(),new FastFall(),new HoleSnap(),new AutoPanic(),CH));
  }
  /** used by ClientPlayerMixin: collisions are switched off for this tick */
  public static boolean noclipNow(){ return NoClip.active||Phase.now; }
  /** where Phase wants you to stay (ignores the server setback that tries to pull you out of the wall), or null */
  public static Vec3d phaseKeep(){ return Phase.now&&Phase.antiOn?Phase.keep:null; }
  public static boolean holdMove(){ return NoClip.active&&NoClip.hold; }
  public static boolean crosshairOn(){ return CH!=null&&CH.on; }
  public static void reset(){ NoClip.active=false; Phase.now=false; if(NC!=null) NC.on=false; }
  static Path cfg(String n){ return FabricLoader.getInstance().getConfigDir().resolve(n); }

  // ===== NoClip: REAL noclip. Collisions are turned off for your player (ClientPlayerMixin), you fly through blocks with Speed/Vertical.
  //       The server may still pull you back when you end up inside blocks (vanilla servers check that); HoldPackets hides it from the server. =====
  public static class NoClip extends Module {
    static boolean active, hold; Setting sp=num("Speed",0.5,0.05,10,0.05), vs=num("Vertical",0.5,0.05,10,0.05), holdS=bool("HoldPackets",false); Vec3d home;
    public NoClip(){ super("NoClip",Category.MOVEMENT); }
    public void onEnable(){ active=true; hold=holdS.b; home=mc.player.getEntityPos(); }
    public void onDisable(){ active=false; boolean h=hold; hold=false; if(h&&home!=null&&mc.player!=null) mc.player.setPosition(home); }
    public void onTick(){ active=true; hold=holdS.b; double vy=mc.options.jumpKey.isPressed()?vs.d:mc.options.sneakKey.isPressed()?-vs.d:0; Util.move(sp.d,vy); mc.player.fallDistance=0; }
  }

  // ===== Phase: walk straight into / through walls (noclip only while you touch or are inside blocks); normal physics in open air =====
  public static class Phase extends Module {
    static boolean now, antiOn; static Vec3d keep; Setting sp=num("Speed",0.2,0.05,3,0.05), vs=num("Vertical",0.3,0.05,3,0.05), anti=bool("AntiSetback",true);
    public Phase(){ super("Phase",Category.MOVEMENT); }
    public void onDisable(){ now=false; keep=null; }
    public void onTick(){ Box b=mc.player.getBoundingBox(); boolean inside=!mc.world.isSpaceEmpty(mc.player,b.contract(0.01,0.01,0.01)), touching=!mc.world.isSpaceEmpty(mc.player,b.expand(0.05,-0.05,0.05));
      now=inside||(touching&&Util.moving());
      if(now){ double vy=mc.options.jumpKey.isPressed()?vs.d:mc.options.sneakKey.isPressed()?-vs.d:0; Util.move(Util.moving()?sp.d:0,vy); mc.player.fallDistance=0; }
      antiOn=anti.b; keep=now?mc.player.getEntityPos():null; }
  }

  // ===== CrystalPvP: breaks crystals, builds the obsidian base (beside grounded enemies / under airborne ones, in the air if needed), then places crystals. Three separate delays. =====
  public static class CrystalPvP extends Module {
    Setting range=num("Range",5,2,6,0.5), tr=num("TargetRange",9,3,16,1), odelay=num("ObsidianDelay",2,0,20,1), pdelay=num("PlaceDelay",1,0,20,1), bdelay=num("BreakDelay",0,0,20,1),
      minHp=num("MinSelfHealth",6,0,20,1), selfDist=num("MinSelfDist",2.5,1,5,0.5), obs=bool("PlaceObsidian",true), air=bool("AirPlace",true), rep=num("PerTick",1,1,6,1), scaf=bool("ScaffoldAround",false), scafMode=num("ScaffoldMode",2,0,2,1), scafDelay=num("ScaffoldDelay",1,0,10,1); int ot,pt,bt,sc;
    public CrystalPvP(){ super("CrystalPvP",Category.COMBAT); }
    boolean freeAbove(BlockPos b){ return mc.world.getBlockState(b.up()).isAir()&&mc.world.getBlockState(b.up(2)).isAir()&&mc.world.getOtherEntities(null,new Box(b.getX(),b.getY()+1,b.getZ(),b.getX()+1,b.getY()+3,b.getZ()+1)).isEmpty(); }
    /** places the item you picked in the menu (any item that is in your inventory) around you: under your feet / around your feet */
    void scaffold(){ if(sc>0){ sc--; return; } Item it=Pack7.scaffold(); int slot=Util.findHotbar(s->s.isOf(it));
      if(slot<0){ for(int i=9;i<36;i++) if(mc.player.getInventory().getStack(i).isOf(it)){ mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId,i,8,net.minecraft.screen.slot.SlotActionType.SWAP,mc.player); break; } return; }
      BlockPos f=mc.player.getBlockPos(); List<BlockPos> ps=new ArrayList<>(); int md=scafMode.i(); if(md!=1) ps.add(f.down()); if(md!=0) for(Direction d:Direction.Type.HORIZONTAL) ps.add(f.offset(d));
      int old=Util.sel(); for(BlockPos p:ps){ if(!Pack2.free(p)) continue; Util.sel(slot); boolean ok=Util.place(p);
        if(!ok&&air.b){ mc.interactionManager.interactBlock(mc.player,Hand.MAIN_HAND,new BlockHitResult(Vec3d.ofCenter(p),Direction.UP,p,false)); mc.player.swingHand(Hand.MAIN_HAND); ok=true; } if(ok) break; }
      Util.sel(old); sc=(int)scafDelay.d; }
    public void onTick(){ if(mc.player.getHealth()<minHp.d) return; if(scaf.b) scaffold(); int n=rep.i(); for(int i=0;i<n;i++){ if(ot>0) ot--; if(pt>0) pt--; if(bt>0) bt--; step(); } }
    void step(){
      PlayerEntity t=Pack2.nearestPlayer(tr.d); if(t==null) return; Vec3d eye=mc.player.getEyePos();
      if(bt==0){ boolean hit=false; for(Entity e:mc.world.getEntities()){ if(e.getType()!=EntityType.END_CRYSTAL||mc.player.distanceTo(e)>range.d+0.5||e.distanceTo(t)>7) continue; Util.send(PlayerInteractEntityC2SPacket.attack(e,mc.player.isSneaking())); hit=true; }
        if(hit){ Util.send(new HandSwingC2SPacket(Hand.MAIN_HAND)); bt=(int)bdelay.d; } }
      BlockPos tp=t.getBlockPos(); List<BlockPos> cand=new ArrayList<>();
      if(t.isOnGround()){ for(Direction d:Direction.Type.HORIZONTAL){ cand.add(tp.offset(d).down()); cand.add(tp.offset(d)); } }
      else { cand.add(tp.down()); cand.add(tp.down(2)); for(Direction d:Direction.Type.HORIZONTAL) cand.add(tp.offset(d).down()); }
      BlockPos ready=null, build=null;
      for(BlockPos p:cand){ if(Vec3d.ofCenter(p).distanceTo(eye)>range.d||Vec3d.ofCenter(p).add(0,1,0).distanceTo(mc.player.getEntityPos())<selfDist.d) continue; BlockState s=mc.world.getBlockState(p);
        if((s.isOf(Blocks.OBSIDIAN)||s.isOf(Blocks.BEDROCK))&&freeAbove(p)){ if(ready==null) ready=p; }
        else if(obs.b&&build==null&&s.isReplaceable()&&mc.world.getOtherEntities(null,new Box(p)).isEmpty()) build=p; }
      if(ready!=null&&pt==0){ int slot=Util.findHotbar(x->x.isOf(Items.END_CRYSTAL));
        if(slot>=0){ int old=Util.sel(); Util.sel(slot); mc.interactionManager.interactBlock(mc.player,Hand.MAIN_HAND,new BlockHitResult(Vec3d.ofCenter(ready).add(0,0.5,0),Direction.UP,ready,false)); mc.player.swingHand(Hand.MAIN_HAND); Util.sel(old); pt=(int)pdelay.d; return; } }
      if(build!=null&&ot==0){ int slot=Util.findHotbar(x->x.getItem() instanceof BlockItem bi&&bi.getBlock()==Blocks.OBSIDIAN);
        if(slot>=0){ int old=Util.sel(); Util.sel(slot); boolean ok=Util.place(build);
          if(!ok&&air.b){ mc.interactionManager.interactBlock(mc.player,Hand.MAIN_HAND,new BlockHitResult(Vec3d.ofCenter(build),Direction.UP,build,false)); mc.player.swingHand(Hand.MAIN_HAND); }
          Util.sel(old); ot=(int)odelay.d; } } }
  }

  // ===== SusChunk v2: scores every loaded chunk by how much player-made stuff it holds (storage, furnaces, beds, signs, glass, concrete, rails, redstone, valuable blocks...) =====
  public static class SusChunk extends Module {
    static final Map<Block,Float> W=new HashMap<>();
    static float calc(Block b){ String p=Registries.BLOCK.getId(b).getPath();
      if(p.contains("air")) return 0;
      if(p.contains("chest")||p.equals("barrel")||p.contains("shulker_box")) return 2.5f;
      if(p.contains("furnace")||p.equals("smoker")||p.equals("hopper")||p.equals("dropper")||p.equals("dispenser")||p.equals("brewing_stand")||p.equals("crafting_table")||p.equals("enchanting_table")||p.equals("anvil")) return 1.5f;
      if(p.endsWith("_bed")||p.endsWith("_sign")||p.endsWith("_banner")) return 1.2f;
      if(p.endsWith("netherite_block")||p.equals("diamond_block")||p.equals("emerald_block")||p.equals("gold_block")||p.equals("iron_block")||p.equals("lapis_block")||p.equals("beacon")) return 3f;
      if(p.equals("torch")||p.equals("wall_torch")||p.equals("lantern")||p.equals("soul_lantern")||p.contains("rail")||p.equals("redstone_wire")||p.equals("repeater")||p.equals("comparator")||p.equals("piston")||p.equals("sticky_piston")||p.equals("observer")||p.equals("redstone_lamp")||p.equals("tnt")||p.equals("bookshelf")) return 0.5f;
      if(p.equals("obsidian")||p.equals("crying_obsidian")) return 0.4f;
      if(p.endsWith("_concrete")||p.endsWith("_concrete_powder")||p.endsWith("_wool")||p.endsWith("_carpet")||p.endsWith("glass")||p.endsWith("glass_pane")||p.endsWith("_planks")) return 0.35f;
      if(p.endsWith("_door")||p.endsWith("_trapdoor")||p.endsWith("_fence")||p.endsWith("_fence_gate")||p.endsWith("_stairs")||p.endsWith("_slab")) return 0.25f;
      return 0; }
    static float weigh(Block b){ return W.computeIfAbsent(b,SusChunk::calc); }
    Setting center=color("CenterColor",0xFFFF1E1E), edge=color("EdgeColor",0xFFFFFFFF), csize=num("CenterSize",70,0,100,5), fillA=num("FillAlpha",90,0,255,5), min=num("MinScore",14,1,300,1),
      per=num("ScansPerTick",2,1,10,1), maxShow=num("MaxShow",40,5,200,5), up=num("HeightAboveYou",0,-30,60,1), labels=bool("Labels",true), best=bool("TracerToBest",false);
    record Flag(int cx,int cz,float sc){}
    final Map<Long,Float> score=new HashMap<>(); final Map<Long,Integer> last=new HashMap<>(); final List<Flag> flags=new ArrayList<>(); int tick; Object world;
    public SusChunk(){ super("SusChunk",Category.RENDER); }
    public void onDisable(){ score.clear(); last.clear(); flags.clear(); }
    float scan(WorldChunk c){ float s=0;
      for(ChunkSection sec:c.getSectionArray()){ if(sec==null||sec.isEmpty()||!sec.hasAny(st->weigh(st.getBlock())>0)) continue;
        for(int x=0;x<16;x++) for(int y=0;y<16;y++) for(int z=0;z<16;z++){ float w=weigh(sec.getBlockState(x,y,z).getBlock()); if(w>0) s+=w; } }
      return s; }
    public void onTick(){ tick++; if(world!=mc.world){ world=mc.world; score.clear(); last.clear(); }
      int vd=mc.options.getViewDistance().getValue(), n=0, lim=per.i(); ChunkPos pc=mc.player.getChunkPos();
      for(int r=0;r<=vd&&n<lim;r++) for(int dx=-r;dx<=r&&n<lim;dx++) for(int dz=-r;dz<=r&&n<lim;dz++){ if(Math.max(Math.abs(dx),Math.abs(dz))!=r) continue;
        long k=ChunkPos.toLong(pc.x+dx,pc.z+dz); Integer l=last.get(k); if(l!=null&&tick-l<400) continue; WorldChunk c=mc.world.getChunkManager().getWorldChunk(pc.x+dx,pc.z+dz); if(c==null) continue;
        score.put(k,scan(c)); last.put(k,tick); n++; } }
    public void onRender(Matrix4f m,Vec3d cam,float td){ flags.clear(); ChunkPos pc=mc.player.getChunkPos(); int vd=mc.options.getViewDistance().getValue();
      for(Map.Entry<Long,Float> e:score.entrySet()){ if(e.getValue()<min.d) continue; ChunkPos cp=new ChunkPos(e.getKey()); if(Math.abs(cp.x-pc.x)>vd||Math.abs(cp.z-pc.z)>vd) continue; flags.add(new Flag(cp.x,cp.z,e.getValue())); }
      flags.sort((a,b)->Float.compare(b.sc(),a.sc())); while(flags.size()>maxShow.i()) flags.remove(flags.size()-1);
      double y=mc.player.getY()+up.d; int cc=center.c&0xFFFFFF, ee=edge.c&0xFFFFFF; double off=8*(1-csize.d/100.0);
      for(Flag f:flags){ int a=(int)Math.max(30,Math.min(fillA.d,f.sc()/(min.d*3)*fillA.d)); double x=f.cx()*16, z=f.cz()*16;
        R.box(m,new Box(x,y,z,x+16,y+0.06,z+16).offset(-cam.x,-cam.y,-cam.z),((a/3)<<24)|ee,0xFF000000|ee);
        if(csize.d>0) R.box(m,new Box(x+off,y,z+off,x+16-off,y+0.06,z+16-off).offset(-cam.x,-cam.y,-cam.z),(a<<24)|cc,0);
        R.line(m,new Vec3d(x-cam.x,y-cam.y,z-cam.z),new Vec3d(x-cam.x,y+6-cam.y,z-cam.z),0xFF000000|ee); R.line(m,new Vec3d(x+16-cam.x,y-cam.y,z-cam.z),new Vec3d(x+16-cam.x,y+6-cam.y,z-cam.z),0xFF000000|ee);
        R.line(m,new Vec3d(x-cam.x,y-cam.y,z+16-cam.z),new Vec3d(x-cam.x,y+6-cam.y,z+16-cam.z),0xFF000000|ee); R.line(m,new Vec3d(x+16-cam.x,y-cam.y,z+16-cam.z),new Vec3d(x+16-cam.x,y+6-cam.y,z+16-cam.z),0xFF000000|ee); }
      if(best.b&&!flags.isEmpty()){ Flag f=flags.get(0); R.tracer(new Vec3d(f.cx()*16+8-cam.x,y-cam.y,f.cz()*16+8-cam.z),0xFF000000|cc,false); } }
    public void onHud(DrawContext g,float td){ if(!labels.b) return; double y=mc.player.getY()+up.d; int shown=0;
      for(Flag f:flags){ if(shown++>=12) break; Vec3d s=AbabClient.project(new Vec3d(f.cx()*16+8,y+1,f.cz()*16+8)); if(s==null) continue;
        String t="§cSUS §f"+(int)f.sc()+" §7"+(int)Math.hypot(f.cx()*16+8-mc.player.getX(),f.cz()*16+8-mc.player.getZ())+"m"; int w=mc.textRenderer.getWidth(t);
        g.fill((int)s.x-w/2-2,(int)s.y-10,(int)s.x+w/2+2,(int)s.y,0x99000000); g.drawTextWithShadow(mc.textRenderer,t,(int)s.x-w/2,(int)s.y-9,0xFFFFFFFF); } }
  }

  // ===== Spam: each saved message has its OWN delay (0.05 s = very fast ... 600 s = very slow). Edit them in the module menu ("Edit messages...") =====
  static final List<String> MSGS=new ArrayList<>(); static final List<Double> DELAYS=new ArrayList<>(); static boolean sloaded;
  static void sload(){ if(sloaded) return; sloaded=true; try{ Path f=cfg("abab-spam.txt"); if(Files.exists(f)) for(String l:Files.readAllLines(f)){ if(l.isBlank()) continue; double d=8; String t=l.trim(); int i=l.indexOf('|');
        if(i>0&&l.substring(0,i).trim().matches("[0-9.]+")){ try{ d=Double.parseDouble(l.substring(0,i).trim()); }catch(Exception e){} t=l.substring(i+1).trim(); } MSGS.add(t); DELAYS.add(d); } }catch(Exception e){ e.printStackTrace(); } }
  static void ssave(){ try{ List<String> out=new ArrayList<>(); for(int i=0;i<MSGS.size();i++) out.add(DELAYS.get(i)+"|"+MSGS.get(i)); Files.write(cfg("abab-spam.txt"),out); }catch(Exception e){ e.printStackTrace(); } }
  public static void spamAdd(String s){ spamAdd(s,8); }
  public static void spamAdd(String s,double d){ sload(); MSGS.add(s); DELAYS.add(Math.max(0.05,Math.min(600,d))); ssave(); }
  public static void spamRemove(int i){ sload(); if(i>=0&&i<MSGS.size()){ MSGS.remove(i); DELAYS.remove(i); ssave(); } }
  public static void spamClear(){ sload(); MSGS.clear(); DELAYS.clear(); ssave(); }
  public static List<String> spamList(){ sload(); return MSGS; }
  public static double spamDelay(int i){ sload(); return i>=0&&i<DELAYS.size()?DELAYS.get(i):8; }
  public static void spamSetDelay(int i,double d){ sload(); if(i>=0&&i<DELAYS.size()){ DELAYS.set(i,Math.max(0.05,Math.min(600,Math.round(d*100)/100.0))); ssave(); } }
  public static class Spam extends Module {
    Setting scale=num("SpeedMultiplier",1,0.1,10,0.1), burst=num("MessagesPerSend",1,1,5,1), rnd=bool("RandomOrder",false), tag=bool("RandomTag",true), style=bool("UseChatStyle",true); int t,idx;
    public Spam(){ super("Spam",Category.PLAYER); }
    public void onTick(){ if(t-->0) return; sload(); if(MSGS.isEmpty()||mc.getNetworkHandler()==null) return;
      for(int b=0;b<burst.i();b++){ int i=rnd.b?new Random().nextInt(MSGS.size()):(idx++%MSGS.size()); String m=MSGS.get(i); boolean cmd=m.startsWith("/");
        if(!cmd&&style.b) m=Pack8.styled(m); if(!cmd&&tag.b) m+=" ["+(1000+new Random().nextInt(9000))+"]";
        if(cmd) mc.getNetworkHandler().sendChatCommand(m.substring(1)); else mc.getNetworkHandler().sendChatMessage(m.length()>256?m.substring(0,256):m);
        t=Math.max(1,(int)Math.round(DELAYS.get(i)*20/scale.d)); } }
  }

  // ===== misc =====
  public static class InventoryMove extends Module {
    public InventoryMove(){ super("InventoryMove",Category.MOVEMENT); }
    public void onTick(){ if(!(mc.currentScreen instanceof HandledScreen<?>)) return;
      mc.options.forwardKey.setPressed(Util.keyDown(GLFW.GLFW_KEY_W)); mc.options.backKey.setPressed(Util.keyDown(GLFW.GLFW_KEY_S)); mc.options.leftKey.setPressed(Util.keyDown(GLFW.GLFW_KEY_A)); mc.options.rightKey.setPressed(Util.keyDown(GLFW.GLFW_KEY_D)); mc.options.jumpKey.setPressed(Util.keyDown(GLFW.GLFW_KEY_SPACE)); }
  }
  public static class YawLock extends Module {
    Setting step=num("Step",45,15,90,15), pit=bool("LockPitch",false);
    public YawLock(){ super("YawLock",Category.PLAYER); }
    public void onTick(){ float s=(float)step.d; mc.player.setYaw(Math.round(mc.player.getYaw()/s)*s); if(pit.b) mc.player.setPitch(0); }
  }
  public static class FastFall extends Module {
    Setting sp=num("Speed",1.5,0.5,5,0.1);
    public FastFall(){ super("FastFall",Category.MOVEMENT); }
    public void onTick(){ if(!mc.player.isOnGround()&&mc.player.getVelocity().y<-0.1&&mc.player.fallDistance>0.5){ Vec3d v=mc.player.getVelocity(); mc.player.setVelocity(v.x,-sp.d,v.z); } }
  }
  public static class HoleSnap extends Module {
    Setting range=num("Range",5,2,8,1), sp=num("Speed",0.3,0.1,1,0.05);
    public HoleSnap(){ super("HoleSnap",Category.COMBAT); }
    public void onTick(){ BlockPos c=mc.player.getBlockPos(); if(Pack4.HoleFiller.hole(c)) return; BlockPos best=null; double bd=1e9; int r=range.i();
      for(int x=-r;x<=r;x++) for(int y=-2;y<=1;y++) for(int z=-r;z<=r;z++){ BlockPos p=c.add(x,y,z); if(!Pack4.HoleFiller.hole(p)) continue; double d=Vec3d.ofCenter(p).distanceTo(mc.player.getEntityPos()); if(d<bd){ bd=d; best=p; } }
      if(best==null) return; Vec3d d=new Vec3d(best.getX()+0.5,0,best.getZ()+0.5).subtract(mc.player.getX(),0,mc.player.getZ()); double len=d.length();
      if(len>0.1){ Vec3d v=d.multiply(Math.min(sp.d,len)/len); mc.player.setVelocity(v.x,mc.player.getVelocity().y,v.z); } }
  }
  public static class AutoPanic extends Module {
    Setting hp=num("Health",8,1,20,1);
    public AutoPanic(){ super("AutoPanic",Category.PLAYER); }
    public void onTick(){ if(mc.player.getHealth()<=hp.d&&!ModuleManager.panicked) ModuleManager.panic(); }
  }

  // ===== Crosshair: replaces the vanilla one (HudMixin hides it while this is ON). Style 0 cross, 1 dot, 2 circle, 3 cross+dot, 4 X, 5 your own drawing =====
  static final boolean[][] GRID=new boolean[15][15]; static boolean gridLoaded;
  public static boolean[][] grid(){ if(!gridLoaded){ gridLoaded=true; try{ Path f=cfg("abab-crosshair.txt"); if(Files.exists(f)){ String s=Files.readString(f).trim(); for(int i=0;i<225&&i<s.length();i++) GRID[i/15][i%15]=s.charAt(i)=='1'; } }catch(Exception e){ e.printStackTrace(); } } return GRID; }
  public static void saveGrid(){ StringBuilder sb=new StringBuilder(); for(boolean[] r:GRID) for(boolean b:r) sb.append(b?'1':'0'); try{ Files.writeString(cfg("abab-crosshair.txt"),sb.toString()); }catch(Exception e){ e.printStackTrace(); } }
  public static class Crosshair extends Module {
    Setting style=num("Style",0,0,5,1), size=num("Size",6,1,20,1), gap=num("Gap",2,0,12,1), thick=num("Thickness",1,1,4,1), col=color("Color",0xFFFFFFFF), outline=bool("Outline",true), dyn=bool("Dynamic",false);
    public Crosshair(){ super("Crosshair",Category.RENDER); }
    public void onHud(DrawContext g,float td){ int cx=mc.getWindow().getScaledWidth()/2, cy=mc.getWindow().getScaledHeight()/2, sz=size.i(), th=thick.i(), gp=gap.i()+((dyn.b&&Util.moving())?3:0); List<int[]> rs=new ArrayList<>();
      switch(style.i()){
        case 1 -> { int s=Math.max(2,sz/2); rs.add(new int[]{cx-s/2,cy-s/2,s,s}); }
        case 2 -> { int n=Math.max(16,(int)(6.3*sz)); for(int i=0;i<n;i++){ double a=i*Math.PI*2/n; rs.add(new int[]{cx+(int)Math.round(Math.cos(a)*sz),cy+(int)Math.round(Math.sin(a)*sz),th,th}); } }
        case 4 -> { for(int i=gp;i<=gp+sz;i++){ rs.add(new int[]{cx+i,cy+i,th,th}); rs.add(new int[]{cx-i,cy+i,th,th}); rs.add(new int[]{cx+i,cy-i,th,th}); rs.add(new int[]{cx-i,cy-i,th,th}); } }
        case 5 -> { boolean[][] gr=grid(); for(int y=0;y<15;y++) for(int x=0;x<15;x++) if(gr[y][x]) rs.add(new int[]{cx+(x-7)*th-th/2,cy+(y-7)*th-th/2,th,th}); }
        default -> { rs.add(new int[]{cx-th/2,cy-gp-sz,th,sz}); rs.add(new int[]{cx-th/2,cy+gp,th,sz}); rs.add(new int[]{cx-gp-sz,cy-th/2,sz,th}); rs.add(new int[]{cx+gp,cy-th/2,sz,th});
          if(style.i()==3) rs.add(new int[]{cx-1,cy-1,2,2}); }
      }
      if(outline.b) for(int[] r:rs) g.fill(r[0]-1,r[1]-1,r[0]+r[2]+1,r[1]+r[3]+1,0xFF000000);
      for(int[] r:rs) g.fill(r[0],r[1],r[0]+r[2],r[1]+r[3],col.c|0xFF000000); }
  }
}
