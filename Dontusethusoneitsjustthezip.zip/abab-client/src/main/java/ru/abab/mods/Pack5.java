package ru.abab.mods;
import java.util.*;
import net.minecraft.block.*;
import net.minecraft.entity.*;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;
import net.minecraft.network.packet.c2s.play.*;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.*;
import net.minecraft.util.math.*;
import org.joml.Matrix4f;
import ru.abab.AbabClient;
import ru.abab.core.Module;
import ru.abab.core.*;

/** Batch 5: PvP (TPAura, MaceAura, FakeLag, AutoObsidian, FastCrystal, AnchorAura, TargetStrafe), NoClip, Chams, PopChams. */
public final class Pack5 {
  public static void register(List<Module> l){
    l.addAll(List.of(new Chams(),new PopChams(),new FakeLag(),new TPAura(),new MaceAura(),new AutoObsidian(),new FastCrystal(),new AnchorAura(),new TargetStrafe()));
  }
  /** movement packets are held back (FakeLag / NoClip) */
  public static boolean moveHeld(){ return FakeLag.holding||Pack6.holdMove(); }
  public static void reset(){ FakeLag.holding=false; Pack6.reset(); }

  static LivingEntity nearest(double range,boolean pl,boolean mobs){ LivingEntity best=null; double bd=range;
    for(Entity e:Module.mc.world.getEntities()){ if(e==Module.mc.player||!(e instanceof LivingEntity le)||!le.isAlive()) continue;
      if(!((e instanceof PlayerEntity p&&pl&&!p.isSpectator())||(!(e instanceof PlayerEntity)&&mobs))) continue;
      double d=Module.mc.player.distanceTo(e); if(d<bd){ bd=d; best=le; } }
    return best; }
  static boolean free(Vec3d from,Vec3d to){ return Module.mc.world.isSpaceEmpty(Module.mc.player,Module.mc.player.getBoundingBox().offset(to.subtract(from))); }

  // ===== silhouette drawing for Chams / PopChams =====
  static void part(Vec3d cam,Vec3d base,float yawDeg,double lx,double cy,double lz,double hx,double hy,double hz,int fill,int line){
    double yaw=Math.toRadians(yawDeg), cs=Math.cos(yaw), sn=Math.sin(yaw); List<double[]> pts=new ArrayList<>();
    for(int i=0;i<8;i++){ double x=lx+((i&1)==0?-hx:hx), y=cy+((i&2)==0?-hy:hy), z=lz+((i&4)==0?-hz:hz);
      Vec3d s=AbabClient.projectRel(new Vec3d(base.x+cs*x-sn*z-cam.x,base.y+y-cam.y,base.z+sn*x+cs*z-cam.z)); if(s==null) return; pts.add(new double[]{s.x,s.y}); }
    R.fillHull(pts,fill,line); }
  static void body(Vec3d cam,boolean player,double w,double h,Vec3d base,float yaw,int col,int fillA,boolean outline){
    int f=(fillA<<24)|(col&0xFFFFFF), ln=outline?(0xCC000000|(col&0xFFFFFF)):0;
    if(player){ double sy=h/1.8;
      part(cam,base,yaw,0,1.65*sy,0,.25,.25*sy,.25,f,ln); part(cam,base,yaw,0,1.05*sy,0,.25,.35*sy,.125,f,ln);
      part(cam,base,yaw,.375,1.05*sy,0,.125,.35*sy,.125,f,ln); part(cam,base,yaw,-.375,1.05*sy,0,.125,.35*sy,.125,f,ln);
      part(cam,base,yaw,.125,.35*sy,0,.125,.35*sy,.125,f,ln); part(cam,base,yaw,-.125,.35*sy,0,.125,.35*sy,.125,f,ln);
    } else part(cam,base,yaw,0,h/2,0,w/2,h/2,w/2,f,ln); }

  // ===== Chams: filled body silhouettes through walls (players get a real head/torso/arms/legs shape) =====
  public static class Chams extends Module {
    Setting pl=bool("Players",true), ho=bool("Hostile",true), an=bool("Animals",false), ot=bool("OtherMobs",false), fill=num("FillAlpha",90,0,255,5), outline=bool("Outline",true), maxN=num("MaxCount",14,1,60,1), maxD=num("MaxDist",64,8,200,4),
      cP=color("PlayerColor",0xFFFF3B3B), cH=color("HostileColor",0xFFFF9A1F), cA=color("AnimalColor",0xFF3BFF6A), cO=color("OtherColor",0xFF3BC8FF);
    public Chams(){ super("Chams",Category.RENDER); }
    public void onRender(Matrix4f m,Vec3d cam,float td){ double md2=maxD.d*maxD.d; List<Entity> l=new ArrayList<>();
      for(Entity e:mc.world.getEntities()){ if(e==mc.player||!(e instanceof LivingEntity)) continue; int c=Util.cat(e);
        boolean en=switch(c){ case 0->pl.b; case 1->ho.b; case 2->an.b; case 3->false; default->ot.b; }; if(!en||mc.player.squaredDistanceTo(e)>md2) continue; l.add(e); }
      l.sort(Comparator.comparingDouble(e->mc.player.squaredDistanceTo(e)));
      for(int i=0;i<Math.min(l.size(),maxN.i());i++){ Entity e=l.get(i); int c=Util.cat(e); int col=switch(c){ case 0->cP.c; case 1->cH.c; case 2->cA.c; default->cO.c; };
        body(cam,e instanceof PlayerEntity,e.getWidth(),e.getHeight(),e.getLerpedPos(td),e.getBodyYaw(),col,fill.i(),outline.b); } }
  }

  // ===== PopChams: a fading ghost where someone popped a totem (detected from the totem's Regeneration II + Absorption II) =====
  public static class PopChams extends Module {
    Setting secs=num("Seconds",1.5,0.5,5,0.1), self=bool("Self",false), notify=bool("Notify",true), col=color("Color",0xFF3BC8FF), fillA=num("FillAlpha",120,0,255,5);
    record Ghost(Vec3d pos,float yaw,long t,double h){}
    final List<Ghost> gh=new ArrayList<>(); final Map<UUID,Integer> last=new HashMap<>(); final Map<UUID,Integer> pops=new HashMap<>(); int tick;
    public PopChams(){ super("PopChams",Category.RENDER); }
    public void onDisable(){ gh.clear(); }
    public void onTick(){ tick++; if(pops.size()>200) pops.clear();
      for(PlayerEntity p:mc.world.getPlayers()){ if(p==mc.player&&!self.b) continue; var reg=p.getStatusEffect(StatusEffects.REGENERATION); var ab=p.getStatusEffect(StatusEffects.ABSORPTION);
        if(reg!=null&&ab!=null&&reg.getAmplifier()==1&&ab.getAmplifier()==1&&reg.getDuration()>=860&&tick-last.getOrDefault(p.getUuid(),-100)>=40){
          last.put(p.getUuid(),tick); int n=pops.merge(p.getUuid(),1,Integer::sum); gh.add(new Ghost(p.getEntityPos(),p.getBodyYaw(),System.currentTimeMillis(),p.getHeight()));
          if(notify.b) Util.msg("§e"+p.getName().getString()+" §7popped §c"+n+" §7totem"+(n>1?"s":"")); } } }
    public void onRender(Matrix4f m,Vec3d cam,float td){ long now=System.currentTimeMillis(); double dur=secs.d*1000; gh.removeIf(g->now-g.t()>dur);
      for(Ghost g:gh){ double age=(now-g.t())/dur; int a=(int)(fillA.i()*(1-age)); if(a<4) continue; body(cam,true,0.6,g.h(),g.pos().add(0,age*0.6,0),g.yaw(),col.c,a,true); } }
  }

  // ===== NoClip: you move through blocks on your screen. HoldPackets keeps the server from seeing it (it won't rubber-band you), but the SERVER still thinks you stand where you started =====
  public static class NoClip extends Module {
    static boolean active, holdFlag; Setting sp=num("Speed",0.35,0.05,5,0.05), hold=bool("HoldPackets",true), keep=bool("KeepPosition",false); Vec3d home,pos;
    public NoClip(){ super("NoClip",Category.MOVEMENT); }
    public void onEnable(){ active=true; holdFlag=hold.b; home=mc.player.getEntityPos(); pos=home; }
    public void onTick(){ holdFlag=hold.b;
      if(mc.currentScreen==null){ double yaw=Math.toRadians(mc.player.getYaw());
        Vec3d f=new Vec3d(-Math.sin(yaw),0,Math.cos(yaw)), left=new Vec3d(Math.cos(yaw),0,Math.sin(yaw));
        double fw=(mc.options.forwardKey.isPressed()?1:0)-(mc.options.backKey.isPressed()?1:0), sd=(mc.options.leftKey.isPressed()?1:0)-(mc.options.rightKey.isPressed()?1:0), up=(mc.options.jumpKey.isPressed()?1:0)-(mc.options.sneakKey.isPressed()?1:0);
        Vec3d mv=f.multiply(fw).add(left.multiply(sd)).add(0,up,0); if(mv.lengthSquared()>0) pos=pos.add(mv.normalize().multiply(sp.d)); }
      mc.player.setPosition(pos); mc.player.setVelocity(Vec3d.ZERO); mc.player.fallDistance=0; }
    public void onDisable(){ active=false; holdFlag=false; if(pos==null||home==null) return;
      if(hold.b){ boolean ok=mc.world.isSpaceEmpty(mc.player,mc.player.getBoundingBox()); if(keep.b&&ok) Extra.SpearKill.pk(home,pos,mc.player.isOnGround()); else mc.player.setPosition(home); } }
  }

  // ===== FakeLag: your position updates are sent in short bursts; you keep playing normally on your screen =====
  public static class FakeLag extends Module {
    static boolean holding; Setting delay=num("Delay",4,1,20,1), near=bool("OnlyNearPlayers",false), range=num("Range",12,3,40,1); int ph;
    public FakeLag(){ super("FakeLag",Category.COMBAT); }
    public void onDisable(){ holding=false; }
    public void onTick(){ ph=(ph+1)%(delay.i()+1); boolean ok=!near.b;
      if(near.b) for(PlayerEntity p:mc.world.getPlayers()) if(p!=mc.player&&p.isAlive()&&mc.player.distanceTo(p)<=range.d){ ok=true; break; }
      holding=ph!=0&&ok; }
  }

  // ===== TPAura: like KillAura, but every hit comes from a different spot around the target (you are back at your place right after) =====
  public static class TPAura extends Module {
    Setting range=num("Range",9,3,22,1), delay=num("Delay",5,1,40,1), radius=num("Radius",2.2,1.5,3.2,0.1), stay=bool("StayThere",false), pl=bool("Players",true), mobs=bool("Mobs",false), hitMode=num("HitMode",1,0,3,1); int cool,n; // HitMode: 0 normal, 1 crit, 2 sweep, 3 auto
    public TPAura(){ super("TPAura",Category.COMBAT); }
    public void onTick(){ if(cool>0){ cool--; return; } LivingEntity t=nearest(range.d,pl.b,mobs.b); if(t==null) return;
      Vec3d o=mc.player.getEntityPos(), c=t.getEntityPos(), spot=null;
      for(int k=0;k<8&&spot==null;k++){ double a=Math.toRadians((n*47+k*45)%360); Vec3d s=new Vec3d(c.x+Math.cos(a)*radius.d,c.y,c.z+Math.sin(a)*radius.d); if(free(o,s)) spot=s; }
      cool=(int)delay.d; if(spot==null) return; boolean gr=mc.player.isOnGround(); n++;
      int hm=hitMode.i(); if(hm==3){ int near=0; for(Entity e:mc.world.getOtherEntities(t,t.getBoundingBox().expand(1.5,0.25,1.5))) if(e instanceof LivingEntity&&e!=mc.player) near++; hm=near>=1?2:1; }
      Extra.SpearKill.pk(o,spot,hm==2); if(hm==1) Pack8.crit(spot); mc.interactionManager.attackEntity(mc.player,t); mc.player.swingHand(Hand.MAIN_HAND);
      if(stay.b) mc.player.setPosition(spot); else Extra.SpearKill.pk(spot,o,gr); }
  }

  // ===== MaceAura: TPAura + MazeKill in one: teleport next to the target, fake a long fall from there, smash, go back, repeat =====
  public static class MaceAura extends Module {
    Setting range=num("Range",9,3,22,1), delay=num("Delay",10,2,40,1), height=num("Height",60,5,300,5), radius=num("Radius",1.8,1.2,3,0.1), pl=bool("Players",true), mobs=bool("Mobs",false); int cool;
    public MaceAura(){ super("MaceAura",Category.COMBAT); }
    public void onTick(){ if(cool>0){ cool--; return; } int slot=Util.findHotbar(s->s.isOf(Items.MACE)); if(slot<0) return; LivingEntity t=nearest(range.d,pl.b,mobs.b); if(t==null) return;
      Vec3d o=mc.player.getEntityPos(), c=t.getEntityPos(), spot=null; double fall=0;
      for(int k=0;k<8&&spot==null;k++){ double a=Math.toRadians(k*45); Vec3d s=new Vec3d(c.x+Math.cos(a)*radius.d,c.y,c.z+Math.sin(a)*radius.d); if(!free(o,s)) continue;
        Box b=mc.player.getBoundingBox().offset(s.subtract(o)); double H=0; for(int j=1;j<=height.i();j++){ if(!mc.world.isSpaceEmpty(mc.player,b.offset(0,j,0))) break; H=j; }
        if(H>=5){ spot=s; fall=H; } }
      cool=(int)delay.d; if(spot==null||o.distanceTo(spot)>range.d+radius.d) return;
      int old=Util.sel(); boolean gr=mc.player.isOnGround(); double st=9;
      Util.send(new UpdateSelectedSlotC2SPacket(slot)); Extra.SpearKill.pk(o,spot,false);
      for(double d=st;d<fall;d+=st) Util.send(new PlayerMoveC2SPacket.PositionAndOnGround(spot.x,spot.y+d,spot.z,false,false));
      Util.send(new PlayerMoveC2SPacket.PositionAndOnGround(spot.x,spot.y+fall,spot.z,false,false));
      for(double d=fall-st;d>0;d-=st) Util.send(new PlayerMoveC2SPacket.PositionAndOnGround(spot.x,spot.y+d,spot.z,false,false));
      Util.send(new PlayerMoveC2SPacket.PositionAndOnGround(spot.x,spot.y,spot.z,false,false));
      Util.send(PlayerInteractEntityC2SPacket.attack(t,mc.player.isSneaking())); Util.send(new HandSwingC2SPacket(Hand.MAIN_HAND));
      Extra.SpearKill.pk(spot,o,gr); Util.send(new UpdateSelectedSlotC2SPacket(old)); }
  }

  // ===== AutoObsidian: obsidian where crystals can go. Enemy on the ground -> beside their feet. Enemy in the air -> under them (air placing) =====
  public static class AutoObsidian extends Module {
    Setting range=num("Range",5,2,6,0.5), tr=num("TargetRange",9,3,16,1), per=num("PerTick",1,1,4,1), delay=num("Delay",1,0,10,1), air=bool("AirPlace",true); int cd;
    public AutoObsidian(){ super("AutoObsidian",Category.COMBAT); }
    public void onTick(){ if(cd-->0) return; PlayerEntity t=Pack2.nearestPlayer(tr.d); if(t==null) return; int slot=Util.findHotbar(s->s.getItem() instanceof BlockItem bi&&bi.getBlock()==Blocks.OBSIDIAN); if(slot<0) return;
      BlockPos tp=t.getBlockPos(); List<BlockPos> cand=new ArrayList<>();
      if(t.isOnGround()){ for(Direction d:Direction.Type.HORIZONTAL) cand.add(tp.offset(d)); }
      else { cand.add(tp.down()); cand.add(tp.down(2)); for(Direction d:Direction.Type.HORIZONTAL) cand.add(tp.offset(d).down()); }
      int old=Util.sel(), n=0; Vec3d eye=mc.player.getEyePos();
      for(BlockPos p:cand){ if(!Pack2.free(p)||Vec3d.ofCenter(p).distanceTo(eye)>range.d) continue; Util.sel(slot);
        boolean ok=Util.place(p); if(!ok&&air.b){ mc.interactionManager.interactBlock(mc.player,Hand.MAIN_HAND,new BlockHitResult(Vec3d.ofCenter(p),Direction.UP,p,false)); mc.player.swingHand(Hand.MAIN_HAND); ok=true; }
        if(ok&&++n>=per.i()) break; }
      Util.sel(old); cd=(int)delay.d; }
  }

  // ===== FastCrystal: place ONE crystal and every crystal in reach is hit at once, several per tick =====
  public static class FastCrystal extends Module {
    Setting range=num("Range",5.5,2,6,0.1), delay=num("Delay",0,0,10,1), near=bool("OnlyNearEnemy",false), minHp=num("MinSelfHealth",4,0,20,1); int t;
    public FastCrystal(){ super("FastCrystal",Category.COMBAT); }
    public void onTick(){ if(t>0){ t--; return; } if(mc.player.getHealth()<minHp.d) return; boolean hit=false;
      for(Entity e:mc.world.getEntities()){ if(e.getType()!=EntityType.END_CRYSTAL||mc.player.distanceTo(e)>range.d) continue;
        if(near.b){ boolean ok=false; for(PlayerEntity p:mc.world.getPlayers()) if(p!=mc.player&&p.distanceTo(e)<=7){ ok=true; break; } if(!ok) continue; }
        Util.send(PlayerInteractEntityC2SPacket.attack(e,mc.player.isSneaking())); hit=true; }
      if(hit){ Util.send(new HandSwingC2SPacket(Hand.MAIN_HAND)); t=(int)delay.d; } }
  }

  // ===== AnchorAura: places a respawn anchor next to the enemy, charges it with glowstone, then blows it (Overworld) =====
  public static class AnchorAura extends Module {
    Setting range=num("Range",5,2,6,0.5), tr=num("TargetRange",9,3,16,1), delay=num("Delay",2,0,10,1), selfMin=num("MinSelfDist",3.5,1,8,0.5), air=bool("AirPlace",true), rep=num("PerTick",1,1,6,1); int cd; BlockPos anchor;
    public AnchorAura(){ super("AnchorAura",Category.COMBAT); }
    void use(BlockPos p){ mc.interactionManager.interactBlock(mc.player,Hand.MAIN_HAND,new BlockHitResult(Vec3d.ofCenter(p),Direction.UP,p,false)); mc.player.swingHand(Hand.MAIN_HAND); }
    public void onTick(){ int n=rep.i(); for(int i=0;i<n;i++){ boolean w=cd>0; step(); if(w) break; } }
    void step(){ if(cd-->0) return; PlayerEntity t=Pack2.nearestPlayer(tr.d); if(t==null){ anchor=null; return; } Vec3d eye=mc.player.getEyePos(); int old=Util.sel();
      if(anchor==null||!mc.world.getBlockState(anchor).isOf(Blocks.RESPAWN_ANCHOR)){ anchor=null; int a=Util.findHotbar(s->s.isOf(Items.RESPAWN_ANCHOR)); if(a<0) return;
        BlockPos tp=t.getBlockPos(); List<BlockPos> cand=new ArrayList<>(); cand.add(tp.up(2)); for(Direction d:Direction.Type.HORIZONTAL) cand.add(tp.offset(d).up()); cand.add(tp.down());
        for(BlockPos p:cand){ if(!Pack2.free(p)||Vec3d.ofCenter(p).distanceTo(eye)>range.d||Vec3d.ofCenter(p).distanceTo(mc.player.getEntityPos())<selfMin.d) continue; Util.sel(a); if(Util.place(p)){ anchor=p; break; } else if(air.b){ use(p); anchor=p; break; } }
        Util.sel(old); cd=(int)delay.d; return; }
      if(Vec3d.ofCenter(anchor).distanceTo(eye)>range.d+1||Vec3d.ofCenter(anchor).distanceTo(mc.player.getEntityPos())<selfMin.d){ return; }
      int charges=mc.world.getBlockState(anchor).get(RespawnAnchorBlock.CHARGES);
      if(charges<1){ int g=Util.findHotbar(s->s.isOf(Items.GLOWSTONE)); if(g<0) return; Util.sel(g); use(anchor); Util.sel(old); }
      else { int other=-1; for(int i=0;i<9;i++){ ItemStack s=mc.player.getInventory().getStack(i); if(!s.isOf(Items.GLOWSTONE)&&!s.isOf(Items.RESPAWN_ANCHOR)){ other=i; break; } }
        if(other>=0){ Util.sel(other); use(anchor); Util.sel(old); anchor=null; } }
      cd=(int)delay.d; }
  }

  // ===== TargetStrafe: while you hold attack you circle around the nearest player =====
  public static class TargetStrafe extends Module {
    Setting radius=num("Radius",2.8,1.5,5,0.1), speed=num("Speed",0.26,0.1,0.6,0.01), onlyAtk=bool("OnlyWhileAttack",true); int dir=1;
    public TargetStrafe(){ super("TargetStrafe",Category.COMBAT); }
    public void onTick(){ if(onlyAtk.b&&!mc.options.attackKey.isPressed()) return; LivingEntity t=nearest(7,true,false); if(t==null) return;
      Vec3d d=mc.player.getEntityPos().subtract(t.getEntityPos()).multiply(1,0,1); double dist=d.length(); if(dist<0.1) return; Vec3d n=d.normalize();
      if(mc.player.horizontalCollision) dir=-dir; double corr=Math.max(-0.2,Math.min(0.2,(radius.d-dist)*0.4));
      Vec3d v=new Vec3d(-n.z*dir,0,n.x*dir).multiply(speed.d).add(n.multiply(corr)); mc.player.setVelocity(v.x,mc.player.getVelocity().y,v.z); }
  }
}
