package ru.abab.mixin;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.abab.mods.Pack6;
/** hides the vanilla crosshair while the ABAB Crosshair module is ON. If the game does not start, remove "HudMixin" from abab.mixins.json. */
@Mixin(InGameHud.class)
public abstract class HudMixin {
  @Inject(method="renderCrosshair", at=@At("HEAD"), cancellable=true, require=0)
  private void abab$crosshair(CallbackInfo ci){ if(Pack6.crosshairOn()) ci.cancel(); }
}
