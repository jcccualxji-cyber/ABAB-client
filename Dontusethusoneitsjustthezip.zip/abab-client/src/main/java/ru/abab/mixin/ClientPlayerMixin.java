package ru.abab.mixin;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.abab.mods.Extra;
import ru.abab.mods.Pack3;
import ru.abab.mods.Pack6;
/** ChunkFly/ChunkWalk lift the "unloaded chunk" freeze; Freecam stops sending movement packets. */
@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerMixin {
  @Redirect(method="tick", at=@At(value="INVOKE", target="Lnet/minecraft/world/World;isPosLoaded(II)Z"), require=0)
  private boolean abab$loaded(World w,int x,int z){ return Extra.chunkBypass() || w.isPosLoaded(x,z); }
  @Inject(method="tickMovement", at=@At("HEAD"), require=0)
  private void abab$noclip(CallbackInfo ci){ if(Pack6.noclipNow()) ((ClientPlayerEntity)(Object)this).noClip=true; }
  @Inject(method="pushOutOfBlocks", at=@At("HEAD"), cancellable=true, require=0)
  private void abab$noPush(CallbackInfo ci){ if(Pack6.noclipNow()) ci.cancel(); }
  @Inject(method="sendMovementPackets", at=@At("HEAD"), cancellable=true, require=0)
  private void abab$freecamNoPackets(CallbackInfo ci){ if(Pack3.cancelMove()) ci.cancel(); }
}
