package ru.abab.mixin;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.client.sound.SoundManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.abab.mods.Pack8;
/** HitSound can mute vanilla sounds (attack / totem / explosion). If the game does not start, remove "SoundMixin" from abab.mixins.json. */
@Mixin(SoundManager.class)
public abstract class SoundMixin {
  @Inject(method="play(Lnet/minecraft/client/sound/SoundInstance;)V", at=@At("HEAD"), cancellable=true, require=0)
  private void abab$mute(SoundInstance s,CallbackInfo ci){ try{ if(Pack8.HitSound.muted(s.getId().getPath())) ci.cancel(); }catch(Throwable ignored){} }
}
