package ru.abab.mixin;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.abab.mods.Pack4;
import ru.abab.mods.Pack6;
import net.minecraft.util.math.Vec3d;
/** AntiKnockback: drop the velocity packet the server sends for YOU. If the game does not start, remove "NetMixin" from abab.mixins.json. */
@Mixin(ClientPlayNetworkHandler.class)
public abstract class NetMixin {
  /** Phase: after the vanilla client applied a server setback, put you back where Phase wants you */
  @Inject(method="onPlayerPositionLook", at=@At("TAIL"), require=0)
  private void abab$phaseKeep(CallbackInfo ci){ MinecraftClient mc=MinecraftClient.getInstance(); Vec3d k=Pack6.phaseKeep(); if(mc.player!=null&&k!=null) mc.player.setPosition(k); }
  @Inject(method="onEntityVelocityUpdate", at=@At("HEAD"), cancellable=true, require=0)
  private void abab$kb(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci){
    MinecraftClient mc=MinecraftClient.getInstance();
    if(mc.player!=null&&packet.getEntityId()==mc.player.getId()&&Pack4.cancelKnockback()) ci.cancel();
  }
}
