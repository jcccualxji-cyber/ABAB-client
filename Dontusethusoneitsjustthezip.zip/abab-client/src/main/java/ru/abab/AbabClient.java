package ru.abab;
import ru.abab.core.Module;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.util.math.Vec3d;
import org.joml.*;
import org.lwjgl.glfw.GLFW;
import ru.abab.core.*;
import ru.abab.gui.*;
import ru.abab.mods.Mods;
import ru.abab.mods.Pack3;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
public class AbabClient implements ClientModInitializer {
  public static final MinecraftClient mc=MinecraftClient.getInstance();
  public static Matrix4f view=new Matrix4f();
  public static Vec3d cam=Vec3d.ZERO;
  static boolean guiDown, panicDown;
  // camera basis, computed ONCE per frame (forward, right, up, tan(fov/2), aspect, screen size)
  static double fx,fy,fz,rx,ry,rz,ux,uy,uz,th,asp; static int sW=1,sH=1;
  static void basis(double yawDeg,double pitDeg){
    double yaw=java.lang.Math.toRadians(yawDeg), pit=java.lang.Math.toRadians(pitDeg), cp=java.lang.Math.cos(pit);
    fx=-java.lang.Math.sin(yaw)*cp; fy=-java.lang.Math.sin(pit); fz=java.lang.Math.cos(yaw)*cp;
    rx=-java.lang.Math.cos(yaw); ry=0; rz=-java.lang.Math.sin(yaw);
    ux=ry*fz-rz*fy; uy=rz*fx-rx*fz; uz=rx*fy-ry*fx;
    sW=mc.getWindow().getScaledWidth(); sH=mc.getWindow().getScaledHeight();
    double fix=Mods.HUD!=null?Mods.HUD.fovFix.d:1.0;
    th=java.lang.Math.tan(java.lang.Math.toRadians(mc.options.getFov().getValue()*fix)/2); asp=(double)sW/sH;
  }
  /** camera-relative vector -> {right, up, forward} */
  public static void camSpace(Vec3d d,double[] o){ o[0]=d.x*rx+d.y*ry+d.z*rz; o[1]=d.x*ux+d.y*uy+d.z*uz; o[2]=d.x*fx+d.y*fy+d.z*fz; }
  /** {right,up,forward} (forward>0) -> {screenX,screenY} */
  public static double[] scr(double[] o){ double nx=o[0]/(o[2]*th*asp), ny=o[1]/(o[2]*th); return new double[]{(nx*0.5+0.5)*sW,(0.5-ny*0.5)*sH}; }
  /** camera-relative world vector -> scaled GUI coords; null if behind the camera. */
  public static Vec3d projectRel(Vec3d d){
    double z=d.x*fx+d.y*fy+d.z*fz; if(z<=0.05) return null;
    double x=d.x*rx+d.y*ry+d.z*rz, y=d.x*ux+d.y*uy+d.z*uz;
    double nx=x/(z*th*asp), ny=y/(z*th);
    return new Vec3d((nx*0.5+0.5)*sW,(0.5-ny*0.5)*sH,0);
  }
  /** cheap frustum test for a camera-relative point with a radius (used to skip drawing things you cannot see) */
  public static boolean visible(Vec3d d,double r){ double z=d.x*fx+d.y*fy+d.z*fz; if(z<-r) return false; if(z<1) return true;
    double x=d.x*rx+d.y*ry+d.z*rz, y=d.x*ux+d.y*uy+d.z*uz; return java.lang.Math.abs(x)<=(z+r)*th*asp*1.25&&java.lang.Math.abs(y)<=(z+r)*th*1.25; }
  /** absolute world pos -> screen */
  public static Vec3d project(Vec3d w){ return projectRel(w.subtract(cam)); }
  @Override public void onInitializeClient(){
    ModuleManager.init(); Config.load();
    ClientTickEvents.END_CLIENT_TICK.register(c->{
      if(c.currentScreen!=null&&c.currentScreen.getClass()==TitleScreen.class&&AbabTitle.enabled) c.setScreen(new AbabTitle());
      if(c.player==null||c.world==null){ Pack3.freecamReset(); return; }
      ModuleManager.tick();
      if(c.currentScreen==null){
        boolean d=Util.keyDown(GLFW.GLFW_KEY_RIGHT_SHIFT); if(d&&!guiDown) c.setScreen(new ClickGui()); guiDown=d;
        boolean p=Util.keyDown(GLFW.GLFW_KEY_END); if(p&&!panicDown) ModuleManager.panic(); panicDown=p;
      }
    });
    HudRenderCallback.EVENT.register((g,t)->{
      if(mc.player==null||mc.world==null||mc.options.hudHidden) return;
      float td=t.getTickProgress(false);
      cam=Pack3.freecamActive()?Pack3.freecamPos(td):mc.player.getLerpedPos(td).add(0,mc.player.getStandingEyeHeight(),0);
      basis(mc.player.getYaw(td),mc.player.getPitch(td));
      R.begin(g);
      for(Module m:ModuleManager.all) if(m.on){ try{ m.onRender(view,cam,td); }catch(Exception e){ e.printStackTrace(); m.set(false);} }
      R.end();
      Hud.render(g,td);
    });
    ScreenEvents.AFTER_INIT.register((client,screen,w,h)->{ if(screen instanceof MultiplayerScreen) Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("Alts"),b->client.setScreen(new AltScreen(screen))).dimensions(6,6,48,20).build()); });
    ClientSendMessageEvents.ALLOW_CHAT.register(Commands::chat);
    ClientSendMessageEvents.ALLOW_COMMAND.register(Commands::command);
    ClientLifecycleEvents.CLIENT_STOPPING.register(c->Config.save());
  }
}
