package ru.abab.gui;
import java.util.*;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import ru.abab.mods.Pack6;
/** Spam messages editor: every message has its own delay (seconds, 0.05 = very fast). Saved automatically. A message that starts with / is sent as a command. */
public class SpamEditor extends Screen {
  record H(int kind,int x,int y,int w,int h,int idx){}
  final Screen parent; final List<H> hits=new ArrayList<>(); TextFieldWidget input, delayF; int px,py,pw,ph,rows,scroll; boolean pressed,dragged; double py0; float acc; static final int RH=20;
  public SpamEditor(Screen p){ super(Text.literal("Spam")); parent=p; }
  @Override protected void init(){ pw=Math.min(340,width-10); ph=Math.min(250,height-10); px=width/2-pw/2; py=height/2-ph/2; rows=Math.max(1,(ph-112)/RH);
    input=new TextFieldWidget(textRenderer,px+10,py+52,pw-132,16,Text.literal("msg")); input.setMaxLength(200); addDrawableChild(input);
    delayF=new TextFieldWidget(textRenderer,px+pw-118,py+52,44,16,Text.literal("delay")); delayF.setMaxLength(6); delayF.setText("8"); addDrawableChild(delayF); setInitialFocus(input); }
  @Override public boolean shouldPause(){ return false; }
  @Override public void renderBackground(DrawContext g,int mx,int my,float d){ }
  void btn(DrawContext g,int kind,int x,int y,int w,int h,String t,int col,int idx,int mx,int my){ boolean hv=mx>=x&&mx<x+w&&my>=y&&my<y+h; UI.rr(g,x,y,w,h,4,hv?(0xFF000000|col):(0xAA000000|col)); g.drawCenteredTextWithShadow(textRenderer,t,x+w/2,y+(h-8)/2,0xFFFFFFFF); hits.add(new H(kind,x,y,w,h,idx)); }
  static String fmt(double d){ return d<1?String.format("%.2f",d):(d<10?String.format("%.1f",d):String.valueOf((int)Math.round(d))); }
  @Override public void render(DrawContext g,int mx,int my,float delta){
    hits.clear(); g.fillGradient(0,0,width,height,0x77000000,0xAA000010);
    UI.rr(g,px-1,py-1,pw+2,ph+2,9,0x40FFFFFF); UI.rr(g,px,py,pw,ph,8,0xB00B0B12); g.fill(px+10,py,px+pw/2,py+2,Hud.RED); g.fill(px+pw/2,py,px+pw-10,py+2,Hud.BLUE);
    g.getMatrices().pushMatrix(); g.getMatrices().translate((float)(px+12),(float)(py+9)); g.getMatrices().scale(1.5f,1.5f); g.drawTextWithShadow(textRenderer,"Spam messages",0,0,0xFFFFFFFF); g.getMatrices().popMatrix();
    g.drawTextWithShadow(textRenderer,"§7Type a message + its delay in seconds (0.05 = very fast, 600 = very slow), press Add.",px+12,py+28,0xFFFFFFFF);
    g.drawTextWithShadow(textRenderer,"§7Use §f-§7 / §f+§7 on a row to change its delay. Saved automatically. /command = sent as command.",px+12,py+38,0xFFFFFFFF);
    input.render(g,mx,my,delta); if(input.getText().isEmpty()&&!input.isFocused()) g.drawTextWithShadow(textRenderer,"§7message",px+14,py+56,0xFFFFFFFF);
    delayF.render(g,mx,my,delta); g.drawTextWithShadow(textRenderer,"§7s",px+pw-70,py+56,0xFFFFFFFF); btn(g,1,px+pw-62,py+51,52,18,"Add",0x2F9F4F,0,mx,my);
    List<String> l=Pack6.spamList(); int y=py+76, x0=px+10, x1=px+pw-10; scroll=Math.max(0,Math.min(scroll,Math.max(0,l.size()-rows)));
    for(int i=scroll;i<Math.min(l.size(),scroll+rows);i++){ UI.rr(g,x0,y,x1-x0,RH-3,4,0x30FFFFFF); String d=fmt(Pack6.spamDelay(i))+"s";
      g.drawTextWithShadow(textRenderer,"§e"+d,x0+6,y+5,0xFFFFFFFF); g.drawTextWithShadow(textRenderer,textRenderer.trimToWidth(l.get(i),x1-x0-150),x0+46,y+5,0xFFFFFFFF);
      btn(g,5,x1-106,y+2,22,RH-7,"-",0x555566,i,mx,my); btn(g,6,x1-80,y+2,22,RH-7,"+",0x555566,i,mx,my); btn(g,2,x1-34,y+2,32,RH-7,"X",0xD41F26,i,mx,my); y+=RH; }
    if(l.isEmpty()) g.drawCenteredTextWithShadow(textRenderer,"§7No messages yet",px+pw/2,py+96,0xFFFFFFFF);
    btn(g,3,px+10,py+ph-24,80,18,"Clear all",0xB8641A,0,mx,my); btn(g,4,px+pw-70,py+ph-24,60,18,"Back",0x555566,0,mx,my);
  }
  static double step(double d){ return d<1?0.05:(d<10?0.5:5); }
  void act(H h){ switch(h.kind){
    case 1 -> { String s=input.getText().trim(); double d=8; try{ d=Double.parseDouble(delayF.getText().trim()); }catch(Exception e){} if(!s.isEmpty()){ Pack6.spamAdd(s,d); input.setText(""); } }
    case 2 -> Pack6.spamRemove(h.idx); case 3 -> Pack6.spamClear(); case 4 -> client.setScreen(parent);
    case 5 -> { double d=Pack6.spamDelay(h.idx); Pack6.spamSetDelay(h.idx,d-step(d<=1?d-0.0001:d)); }
    case 6 -> { double d=Pack6.spamDelay(h.idx); Pack6.spamSetDelay(h.idx,d+step(d)); } default -> {} } }
  @Override public boolean mouseClicked(Click click,boolean doubled){ pressed=true; dragged=false; py0=click.y(); acc=0; if(click.y()>=py+50&&click.y()<py+70&&click.x()<px+pw-64) return super.mouseClicked(click,doubled); return true; }
  @Override public boolean mouseDragged(Click click,double dx,double dy){ if(pressed&&Math.abs(click.y()-py0)>4) dragged=true; if(dragged){ acc-=dy; while(acc>=RH){ acc-=RH; scroll++; } while(acc<=-RH){ acc+=RH; scroll--; } return true; } return super.mouseDragged(click,dx,dy); }
  @Override public boolean mouseReleased(Click click){ boolean wd=dragged; pressed=false; dragged=false; if(wd||click.button()!=0) return true;
    for(int i=hits.size()-1;i>=0;i--){ H h=hits.get(i); if(click.x()>=h.x&&click.x()<h.x+h.w&&click.y()>=h.y&&click.y()<h.y+h.h){ act(h); return true; } } return super.mouseReleased(click); }
  @Override public boolean mouseScrolled(double mx,double my,double hA,double vA){ scroll=Math.max(0,scroll-(int)Math.signum(vA)); return true; }
  @Override public boolean keyPressed(KeyInput input){ int k=input.key(); if(k==GLFW.GLFW_KEY_ENTER||k==GLFW.GLFW_KEY_KP_ENTER){ act(new H(1,0,0,0,0,0)); return true; } if(k==GLFW.GLFW_KEY_ESCAPE){ client.setScreen(parent); return true; } return super.keyPressed(input); }
}
