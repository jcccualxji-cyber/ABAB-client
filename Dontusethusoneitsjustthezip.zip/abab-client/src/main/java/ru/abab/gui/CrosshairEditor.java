package ru.abab.gui;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import ru.abab.mods.Pack6;
/** Draw your own crosshair: click or drag on the grid. Then set the Crosshair module Style to 5. */
public class CrosshairEditor extends Screen {
  final Screen parent; static final int N=15, CELL=12; int gx,gy,pw,ph,px,py; boolean paint, mode;
  public CrosshairEditor(Screen p){ super(Text.literal("Crosshair")); parent=p; }
  @Override protected void init(){ pw=Math.min(300,width-10); ph=Math.min(230,height-10); px=width/2-pw/2; py=height/2-ph/2; gx=px+14; gy=py+34; Pack6.grid(); }
  @Override public boolean shouldPause(){ return false; }
  @Override public void renderBackground(DrawContext g,int mx,int my,float d){ }
  @Override public void render(DrawContext g,int mx,int my,float delta){
    g.fillGradient(0,0,width,height,0x77000000,0xAA000010);
    UI.rr(g,px-1,py-1,pw+2,ph+2,9,0x40FFFFFF); UI.rr(g,px,py,pw,ph,8,0xB00B0B12); g.fill(px+10,py,px+pw/2,py+2,Hud.RED); g.fill(px+pw/2,py,px+pw-10,py+2,Hud.BLUE);
    g.drawTextWithShadow(textRenderer,"Draw your crosshair  §7(click / drag)",px+12,py+10,0xFFFFFFFF);
    boolean[][] gr=Pack6.grid();
    for(int y=0;y<N;y++) for(int x=0;x<N;x++){ int cx=gx+x*CELL, cy=gy+y*CELL; boolean c=(x==7&&y==7);
      g.fill(cx,cy,cx+CELL-1,cy+CELL-1,gr[y][x]?0xFFFFFFFF:(c?0x44D41F26:0x33FFFFFF)); }
    int bx=gx+N*CELL+14, bw=pw-(bx-px)-12;
    g.drawTextWithShadow(textRenderer,"Preview",bx,gy,0xFFB0B0BC); g.fill(bx,gy+12,bx+bw,gy+12+54,0x66000000);
    int pcx=bx+bw/2, pcy=gy+12+27; for(int y=0;y<N;y++) for(int x=0;x<N;x++) if(gr[y][x]) g.fill(pcx+(x-7),pcy+(y-7),pcx+(x-7)+1,pcy+(y-7)+1,0xFFFFFFFF);
    btn(g,bx,gy+80,bw,"Clear",mx,my,0xD41F26); btn(g,bx,gy+102,bw,"Invert",mx,my,0x2F5BFF); btn(g,bx,gy+124,bw,"Save & close",mx,my,0x2F9F4F); btn(g,bx,gy+146,bw,"Cancel",mx,my,0x555566);
    g.drawTextWithShadow(textRenderer,"§7Turn the Crosshair module ON and set Style = 5",px+12,py+ph-14,0xFFFFFFFF);
  }
  void btn(DrawContext g,int x,int y,int w,String t,int mx,int my,int col){ boolean hv=mx>=x&&mx<x+w&&my>=y&&my<y+18; UI.rr(g,x,y,w,18,4,hv?(0xFF000000|col):(0xAA000000|col)); g.drawCenteredTextWithShadow(textRenderer,t,x+w/2,y+5,0xFFFFFFFF); }
  boolean cell(double mx,double my,boolean set){ int x=(int)((mx-gx)/CELL), y=(int)((my-gy)/CELL); if(mx<gx||my<gy||x<0||y<0||x>=N||y>=N) return false; Pack6.grid()[y][x]=set; return true; }
  @Override public boolean mouseClicked(Click click,boolean doubled){ double mx=click.x(), my=click.y(); int bx=gx+N*CELL+14, bw=pw-(bx-px)-12;
    int x=(int)((mx-gx)/CELL), y=(int)((my-gy)/CELL);
    if(mx>=gx&&my>=gy&&x>=0&&y>=0&&x<N&&y<N){ mode=!Pack6.grid()[y][x]; paint=true; Pack6.grid()[y][x]=mode; return true; }
    if(mx>=bx&&mx<bx+bw){
      if(my>=gy+80&&my<gy+98){ for(boolean[] r:Pack6.grid()) java.util.Arrays.fill(r,false); return true; }
      if(my>=gy+102&&my<gy+120){ for(boolean[] r:Pack6.grid()) for(int i=0;i<N;i++) r[i]=!r[i]; return true; }
      if(my>=gy+124&&my<gy+142){ Pack6.saveGrid(); client.setScreen(parent); return true; }
      if(my>=gy+146&&my<gy+164){ client.setScreen(parent); return true; } }
    return super.mouseClicked(click,doubled); }
  @Override public boolean mouseDragged(Click click,double dx,double dy){ if(paint){ cell(click.x(),click.y(),mode); return true; } return super.mouseDragged(click,dx,dy); }
  @Override public boolean mouseReleased(Click click){ paint=false; return super.mouseReleased(click); }
  @Override public boolean keyPressed(KeyInput input){ if(input.key()==GLFW.GLFW_KEY_ESCAPE){ client.setScreen(parent); return true; } return super.keyPressed(input); }
}
