package ru.abab.gui;
import java.util.*;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import ru.abab.core.Module;
import ru.abab.core.*;
/** "Open modules": the classic one-window-per-category layout. [-] / [+] on each header closes / opens that list. Drag headers to move windows. */
public class WindowsGui extends Screen {
  static final int W=112, HH=17, K_DRAG=1,K_COLLAPSE=2,K_MOD=3,K_SETSW=4,K_SLIDER=5,K_COLOR=6,K_BACK=7;
  record Hit(int kind,int x,int y,int w,int h,Module m,Setting s,int idx,int[] clip){}
  static int[] px=new int[8], py=new int[8]; static boolean[] closed=new boolean[8]; static float[] scroll=new float[8]; static boolean placed;
  final List<Hit> hits=new ArrayList<>(); Module binding; int drag=-1,dox,doy; Hit slider; boolean pressed,dragged; double px0,py0; int region=-1; final float[] maxS=new float[8];
  public WindowsGui(){ super(Text.literal("Open modules")); }
  @Override protected void init(){ if(!placed){ Category[] cs=Category.values(); int cols=Math.max(1,(width-10)/(W+8)); for(int i=0;i<cs.length;i++){ px[i]=8+(i%cols)*(W+8); py[i]=30+(i/cols)*((height-30)/2); } placed=true; } }
  @Override public boolean shouldPause(){ return false; }
  @Override public void renderBackground(DrawContext g,int mx,int my,float d){ }
  boolean in(int mx,int my,int x,int y,int w,int h){ return mx>=x&&mx<x+w&&my>=y&&my<y+h; }
  @Override public void render(DrawContext g,int mx,int my,float delta){
    hits.clear(); g.fillGradient(0,0,width,height,0x55000000,0x88000010);
    boolean hv=in(mx,my,6,5,96,16); UI.rr(g,6,5,96,16,5,hv?0xFFD41F26:0xAAD41F26); g.drawCenteredTextWithShadow(textRenderer,"« Back to menu",54,9,0xFFFFFFFF); hits.add(new Hit(K_BACK,6,5,96,16,null,null,0,null));
    g.drawTextWithShadow(textRenderer,"§7LMB toggle · RMB settings · MMB bind · [-]/[+] close or open a list · drag headers",110,9,0xFFFFFFFF);
    Category[] cs=Category.values();
    for(int i=0;i<cs.length;i++){
      int x=px[i], y=py[i]; List<Module> mods=ModuleManager.byCat(cs[i]); int en=0; for(Module m:mods) if(m.on) en++;
      int content=0; for(Module m:mods){ content+=14; if(m.expanded) for(Setting s:m.settings) content+=s.type==Setting.T.NUM?20:14; }
      int maxH=Math.max(60,height-y-8), vh=closed[i]?0:Math.min(content,maxH-HH);
      UI.rr(g,x-1,y-1,W+2,HH+vh+2+(closed[i]?0:4),7,0x40FFFFFF); UI.rr(g,x,y,W,HH+vh+(closed[i]?0:4),6,0xAA0B0B12); g.fill(x+6,y,x+W-6,y+2,Hud.RED);
      g.drawTextWithShadow(textRenderer,cs[i].label.toUpperCase()+" §7"+en+"/"+mods.size(),x+6,y+5,0xFFFFFFFF);
      boolean ch=in(mx,my,x+W-19,y+2,15,13); UI.rr(g,x+W-19,y+2,15,13,4,ch?0xFFD41F26:0x66FFFFFF); g.drawCenteredTextWithShadow(textRenderer,closed[i]?"+":"-",x+W-12,y+5,0xFFFFFFFF);
      hits.add(new Hit(K_DRAG,x,y,W-21,HH,null,null,i,null)); hits.add(new Hit(K_COLLAPSE,x+W-19,y+2,15,13,null,null,i,null));
      if(closed[i]) continue;
      int[] clip={x,y+HH,x+W,y+HH+vh}; g.enableScissor(x,y+HH,x+W,y+HH+vh); int yy=y+HH-(int)scroll[i];
      for(Module m:mods){
        boolean mh=in(mx,my,x+3,yy,W-6,13)&&my>=clip[1]&&my<clip[3];
        UI.rr(g,x+3,yy,W-6,13,3,m.on?0xCCD41F26:(mh?0x55FFFFFF:0x22FFFFFF)); g.drawTextWithShadow(textRenderer,m.name,x+7,yy+3,m.on?0xFFFFFFFF:0xFFB5B5BD);
        String k=binding==m?"...":(m.key>=0?ModuleManager.keyName(m.key):(m.settings.isEmpty()?"":(m.expanded?"-":"+"))); g.drawTextWithShadow(textRenderer,"§7"+k,x+W-7-textRenderer.getWidth(k),yy+3,0xFFFFFFFF);
        hits.add(new Hit(K_MOD,x+3,yy,W-6,13,m,null,0,clip)); yy+=14;
        if(m.expanded) for(Setting s:m.settings){
          g.fill(x+5,yy,x+W-5,yy+(s.type==Setting.T.NUM?19:13),0x44000000); g.fill(x+5,yy,x+7,yy+(s.type==Setting.T.NUM?19:13),Hud.BLUE);
          switch(s.type){
            case BOOL -> { g.drawTextWithShadow(textRenderer,textRenderer.trimToWidth(s.name,W-40),x+10,yy+2,0xFFD0D0D8); String v=s.b?"ON":"OFF"; g.drawTextWithShadow(textRenderer,v,x+W-9-textRenderer.getWidth(v),yy+2,s.b?0xFF3BFF6A:0xFFFF5555); hits.add(new Hit(K_SETSW,x+5,yy,W-10,13,m,s,0,clip)); yy+=14; }
            case NUM -> { g.drawTextWithShadow(textRenderer,textRenderer.trimToWidth(s.name,W-44),x+10,yy+1,0xFFD0D0D8); String v=s.step>=1?String.valueOf((int)Math.round(s.d)):String.format("%.2f",s.d); g.drawTextWithShadow(textRenderer,v,x+W-9-textRenderer.getWidth(v),yy+1,0xFFFFFFFF);
                          double f=(s.d-s.min)/Math.max(1e-9,s.max-s.min); g.fill(x+10,yy+13,x+W-10,yy+16,0x55FFFFFF); g.fill(x+10,yy+13,x+10+(int)((W-20)*f),yy+16,Hud.RED);
                          hits.add(new Hit(K_SLIDER,x+7,yy+9,W-14,10,m,s,0,clip)); yy+=20; }
            case COLOR -> { g.drawTextWithShadow(textRenderer,s.name,x+10,yy+2,0xFFD0D0D8); g.fill(x+W-24,yy+2,x+W-9,yy+10,s.c|0xFF000000); hits.add(new Hit(K_COLOR,x+5,yy,W-10,13,m,s,0,clip)); yy+=14; }
          } }
      }
      g.disableScissor(); maxS[i]=Math.max(0,content-vh); scroll[i]=Math.max(0,Math.min(scroll[i],maxS[i]));
    }
  }
  Hit hitAt(double x,double y){ for(int i=hits.size()-1;i>=0;i--){ Hit h=hits.get(i); if(x>=h.x&&x<h.x+h.w&&y>=h.y&&y<h.y+h.h&&(h.clip==null||(x>=h.clip[0]&&x<h.clip[2]&&y>=h.clip[1]&&y<h.clip[3]))) return h; } return null; }
  void setSlider(Hit h,double mxp){ Setting s=h.s; double bx=h.x+3, bw=h.w-6; double f=Math.max(0,Math.min(1,(mxp-bx)/bw)); double v=s.min+f*(s.max-s.min);
    if(s.step>0) v=Math.round((v-s.min)/s.step)*s.step+s.min; s.d=Math.round(Math.max(s.min,Math.min(s.max,v))*1000)/1000.0; }
  void act(Hit h,int btn){
    switch(h.kind){
      case K_BACK -> client.setScreen(new ClickGui());
      case K_COLLAPSE -> closed[h.idx]=!closed[h.idx];
      case K_MOD -> { if(btn==0) h.m.toggle(); else if(btn==1) h.m.expanded=!h.m.expanded; else if(btn==2) binding=h.m; }
      case K_SETSW -> { h.s.b=!h.s.b; Config.save(); }
      case K_COLOR -> { h.s.cycle(); Config.save(); }
      default -> {}
    }
  }
  @Override public boolean mouseClicked(Click click,boolean doubled){ double mxp=click.x(), myp=click.y(); pressed=true; dragged=false; px0=mxp; py0=myp; slider=null; drag=-1; region=-1;
    Hit h=hitAt(mxp,myp);
    if(h!=null&&h.kind==K_SLIDER){ slider=h; setSlider(h,mxp); return true; }
    if(h!=null&&h.kind==K_DRAG){ drag=h.idx; dox=(int)mxp-px[drag]; doy=(int)myp-py[drag]; return true; }
    Category[] cs=Category.values(); for(int i=0;i<cs.length;i++) if(mxp>=px[i]&&mxp<px[i]+W&&myp>=py[i]+HH&&myp<height) region=i;
    return true; }
  @Override public boolean mouseDragged(Click click,double dx,double dy){
    if(slider!=null){ setSlider(slider,click.x()); return true; }
    if(drag>=0){ px[drag]=(int)click.x()-dox; py[drag]=(int)click.y()-doy; dragged=true; return true; }
    if(pressed&&!dragged&&Math.hypot(click.x()-px0,click.y()-py0)>4) dragged=true;
    if(dragged&&region>=0){ scroll[region]=Math.max(0,Math.min(maxS[region],scroll[region]-(float)dy)); return true; }
    return super.mouseDragged(click,dx,dy); }
  @Override public boolean mouseReleased(Click click){ boolean wd=dragged; pressed=false; dragged=false; Hit sl=slider; slider=null; int dr=drag; drag=-1;
    if(sl!=null){ Config.save(); return true; } if(dr>=0) return true;
    if(!wd){ Hit h=hitAt(click.x(),click.y()); if(h!=null){ act(h,click.button()); return true; } }
    return super.mouseReleased(click); }
  @Override public boolean mouseScrolled(double mx,double my,double hA,double vA){ Category[] cs=Category.values(); for(int i=0;i<cs.length;i++) if(mx>=px[i]&&mx<px[i]+W&&my>=py[i]) scroll[i]=Math.max(0,Math.min(maxS[i],scroll[i]-(float)vA*20)); return true; }
  @Override public boolean keyPressed(KeyInput input){ int key=input.key();
    if(binding!=null){ if(key==GLFW.GLFW_KEY_BACKSPACE||key==GLFW.GLFW_KEY_DELETE) binding.key=-1; else if(key!=GLFW.GLFW_KEY_ESCAPE) binding.key=key; binding=null; Config.save(); return true; }
    if(key==GLFW.GLFW_KEY_RIGHT_SHIFT){ close(); return true; } if(key==GLFW.GLFW_KEY_END){ ModuleManager.panic(); return true; }
    return super.keyPressed(input); }
  @Override public void removed(){ Config.save(); }
}
