package ru.abab.gui;
import ru.abab.core.Module;
import java.util.*;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import ru.abab.core.*;
import ru.abab.mods.*;
/** ABAB menu: sidebar (categories) | module cards | settings + keybind. Translucent, works with touch (drag to scroll). */
public class ClickGui extends Screen {
  static final int SW=84, K_CAT=1,K_CARD=2,K_SWITCH=3,K_SETSW=4,K_SLIDER=5,K_COLOR=6,K_BIND=7,K_HOLD=8,K_PANIC=9,K_PICK=10,K_RSWITCH=11,K_ALTS=12,K_PROFILES=13,K_WINDOWS=14,K_XHAIR=15,K_SPAM=16,K_ITEM=17,K_SUSWL=18,K_CHAT=19;
  record Hit(int kind,int x,int y,int w,int h,Module m,Setting s,int idx,int[] clip){}
  static int sel=0; static String query=""; static Module selected;
  final List<Hit> hits=new ArrayList<>();
  int wx,wy,ww,wh,rw,mx0,mx1,rx0; float scrollL,scrollR,maxL,maxR;
  TextFieldWidget search; Module binding;
  boolean pressed,dragged; double px0,py0; int dragRegion; Hit slider;
  public ClickGui(){ super(Text.literal("АБАБ")); }
  @Override protected void init(){
    ww=Math.min(width-10,450); wh=Math.min(height-10,250); wx=(width-ww)/2; wy=(height-wh)/2; rw=Math.max(112,Math.min(150,ww/3));
    mx0=wx+SW; mx1=wx+ww-rw; rx0=mx1;
    int sfw=Math.max(60,Math.min(110,(mx1-mx0)/2-6));
    search=new TextFieldWidget(textRenderer,mx1-sfw-6,wy+8,sfw,14,Text.literal("search")); search.setMaxLength(24);
    search.setChangedListener(s->{ query=s.toLowerCase().trim(); scrollL=0; }); search.setText(query);
    addDrawableChild(search); setInitialFocus(search);
  }
  @Override public boolean shouldPause(){ return false; }
  @Override public void renderBackground(DrawContext g,int mx,int my,float d){ }
  /** filled circle helper (also used by the title screen) */
  static void disc(DrawContext g,float cx,float cy,float r,int rgb,int a){
    int R=(int)Math.ceil(r); for(int dy=-R;dy<=R;dy++){ double q=r*r-dy*dy; if(q<0) continue; int dx=(int)Math.sqrt(q); g.fill((int)cx-dx,(int)cy+dy,(int)cx+dx+1,(int)cy+dy+1,(a<<24)|rgb); }
  }
  static void sw(DrawContext g,int x,int y,boolean on){ int col=on?Hud.RED:0xFF4A4A56; g.fill(x+5,y,x+17,y+11,col); disc(g,x+5.5f,y+5.5f,5.5f,col&0xFFFFFF,255); disc(g,x+16.5f,y+5.5f,5.5f,col&0xFFFFFF,255); disc(g,on?x+16.5f:x+5.5f,y+5.5f,4f,0xFFFFFF,255); }
  void text(DrawContext g,String s,float x,float y,float sc,int col){ g.getMatrices().pushMatrix(); g.getMatrices().translate(x,y); g.getMatrices().scale(sc,sc); g.drawTextWithShadow(textRenderer,s,0,0,col); g.getMatrices().popMatrix(); }
  List<Module> current(){
    List<Module> l=new ArrayList<>();
    if(!query.isEmpty()){ for(Module m:ModuleManager.all) if(m.name.toLowerCase().contains(query)) l.add(m); return l; }
    if(sel>=5){ for(Module m:ModuleManager.all) if(m.on) l.add(m); return l; }
    return ModuleManager.byCat(Category.values()[sel]);
  }
  List<String> wrap(String s,float w,float sc){ List<String> out=new ArrayList<>(); String line=""; for(String word:s.split(" ")){ String t=line.isEmpty()?word:line+" "+word; if(textRenderer.getWidth(t)*sc>w&&!line.isEmpty()){ out.add(line); line=word; } else line=t; } if(!line.isEmpty()) out.add(line); return out; }
  boolean in(int mx,int my,int x,int y,int w,int h){ return mx>=x&&mx<x+w&&my>=y&&my<y+h; }
  @Override public void render(DrawContext g,int mx,int my,float delta){
    hits.clear();
    g.fillGradient(0,0,width,height,0x55000000,0x88000010);
    UI.rr(g,wx-1,wy-1,ww+2,wh+2,9,0x40FFFFFF); UI.rr(g,wx,wy,ww,wh,8,0x990B0B12);
    g.fill(wx+10,wy,wx+ww/2,wy+2,Hud.RED); g.fill(wx+ww/2,wy,wx+ww-10,wy+2,Hud.BLUE);
    // ---- sidebar
    UI.rr(g,wx+4,wy+6,SW-6,wh-12,6,0x66000000); int rowH=Math.max(13,Math.min(19,(wh-104)/9));
    text(g,"ABAB",wx+10,wy+9,1.6f,Hud.RED); text(g,"CLIENT",wx+11,wy+25,0.8f,0xFFFFFFFF);
    text(g,"MODULES",wx+10,wy+38,0.7f,0xFF7A7A88);
    Category[] cs=Category.values(); int y=wy+48;
    for(int i=0;i<=cs.length;i++){
      String nm=i<cs.length?cs[i].label:"Active"; int cnt=0; if(i<cs.length){ for(Module m:ModuleManager.byCat(cs[i])) if(m.on) cnt++; } else cnt=ModuleManager.enabledCount();
      boolean s=sel==i&&query.isEmpty(), hv=in(mx,my,wx+5,y,SW-10,rowH-2);
      UI.rr(g,wx+6,y,SW-12,rowH-2,4,s?0x66D41F26:(hv?0x28FFFFFF:0x00000000)); if(s) g.fill(wx+6,y+2,wx+8,y+rowH-4,Hud.BLUE);
      g.drawTextWithShadow(textRenderer,nm,wx+12,y+(rowH-10)/2+1,s?0xFFFFFFFF:0xFFB5B5BD);
      if(cnt>0){ String c=""+cnt; int bw=textRenderer.getWidth(c)+6; g.fill(wx+SW-8-bw,y+3,wx+SW-8,y+14,0x442F5BFF); g.drawTextWithShadow(textRenderer,c,wx+SW-5-bw,y+4,0xFFBFD0FF); }
      hits.add(new Hit(K_CAT,wx+5,y,SW-10,rowH-2,null,null,i,null)); y+=rowH;
    }
    { String[] ex={"Alts","Profiles","Open modules"}; int[] kd={K_ALTS,K_PROFILES,K_WINDOWS}; for(int e=0;e<3;e++){ boolean hv=in(mx,my,wx+5,y,SW-10,rowH-2); UI.rr(g,wx+6,y,SW-12,rowH-2,4,hv?0x28FFFFFF:(e==2?0x332F5BFF:0x00000000)); text(g,ex[e],wx+12,y+(rowH-8)/2,0.9f,e==2?0xFF9DB6FF:0xFFB5B5BD); hits.add(new Hit(kd[e],wx+5,y,SW-10,rowH-2,null,null,0,null)); y+=rowH; } }
    boolean pn=ModuleManager.panicked; int py=wy+wh-22;
    UI.rr(g,wx+8,py,SW-16,16,5,pn?0xFF1F8F3A:0xBBD41F26); g.drawCenteredTextWithShadow(textRenderer,pn?"RESTORE":"ALL OFF",wx+SW/2,py+4,0xFFFFFFFF); hits.add(new Hit(K_PANIC,wx+6,py,SW-12,16,null,null,0,null));
    int by=py-30; String un=AltScreen.user(); boolean prem=AltScreen.premium(); disc(g,wx+17,by+8,8,0x2F5BFF,255); g.drawCenteredTextWithShadow(textRenderer,un.isEmpty()?"?":un.substring(0,1).toUpperCase(),wx+17,by+4,0xFFFFFFFF);
    g.drawTextWithShadow(textRenderer,textRenderer.trimToWidth(un,SW-38),wx+29,by+1,0xFFFFFFFF); text(g,prem?"PREMIUM":"CRACKED",wx+29,by+12,0.7f,prem?0xFF3BFF6A:0xFFFFB03B);
    // ---- module cards
    List<Module> mods=current(); int en=0; for(Module m:mods) if(m.on) en++;
    String title=!query.isEmpty()?"Search":(sel<cs.length?cs[sel].label:"Active");
    text(g,title,mx0+8,wy+8,1.4f,0xFFFFFFFF); text(g,mods.size()+" modules  ·  "+en+" enabled",mx0+8,wy+23,0.8f,0xFF8A8A98);
    search.render(g,mx,my,delta); if(search.getText().isEmpty()&&!search.isFocused()) g.drawTextWithShadow(textRenderer,"§7Search modules",search.getX()+4,search.getY()+3,0xFFFFFFFF);
    int cy0=wy+38, cy1=wy+wh-6, cx0=mx0+6, cx1=mx1-6; int[] clipL={mx0,cy0,mx1,cy1};
    g.enableScissor(mx0,cy0,mx1,cy1);
    int cyy=cy0-(int)scrollL;
    for(Module m:mods){
      if(cyy+28>=cy0&&cyy<=cy1){
        boolean hv=in(mx,my,cx0,cyy,cx1-cx0,28)&&my>=cy0&&my<cy1, sl=m==selected; String ds=Desc.of(m.name);
        if(sl) UI.rr(g,cx0-1,cyy-1,cx1-cx0+2,30,6,0xFF3B6BFF);
        UI.rr(g,cx0,cyy,cx1-cx0,28,5,sl?0xF01C1C2A:(hv?0x55FFFFFF:0x2AFFFFFF));
        g.drawTextWithShadow(textRenderer,m.name,cx0+8,ds.isEmpty()?cyy+10:cyy+5,0xFFFFFFFF);
        if(!ds.isEmpty()) text(g,textRenderer.trimToWidth(ds,(int)((cx1-cx0-56)/0.75f)),cx0+8,cyy+16,0.75f,0xFFA8A8B4);
        if(m.key>=0){ String k=ModuleManager.keyName(m.key); g.drawTextWithShadow(textRenderer,"§7"+k,cx1-34-textRenderer.getWidth(k),cyy+10,0xFFFFFFFF); }
        sw(g,cx1-28,cyy+9,m.on);
        hits.add(new Hit(K_CARD,cx0,cyy,cx1-cx0,28,m,null,0,clipL)); hits.add(new Hit(K_SWITCH,cx1-30,cyy+4,28,20,m,null,0,clipL));
      }
      cyy+=32;
    }
    g.disableScissor(); maxL=Math.max(0,mods.size()*32-(cy1-cy0)); scrollL=Math.max(0,Math.min(scrollL,maxL));
    // ---- settings panel
    int rx1=wx+ww; UI.rr(g,rx0+2,wy+6,rw-8,wh-12,6,0x55000000);
    if(selected==null){ g.drawCenteredTextWithShadow(textRenderer,"§7Select a module",rx0+rw/2,wy+wh/2-4,0xFFFFFFFF); return; }
    Module m=selected; int ry0=wy+6, ry1=wy+wh-6, x=rx0+8, w=rw-16; int[] clipR={rx0,ry0,rx1,ry1};
    g.enableScissor(rx0,ry0,rx1,ry1);
    int yy=ry0-(int)scrollR, top=yy;
    text(g,m.name,x,yy+2,1.4f,0xFFFFFFFF); sw(g,rx1-30,yy+3,m.on); hits.add(new Hit(K_RSWITCH,rx1-32,yy,28,16,m,null,0,clipR)); yy+=20;
    String cl=m.cat.label.toUpperCase(); int cw=textRenderer.getWidth(cl)+8; UI.rr(g,x,yy,cw,11,3,0x552F5BFF); g.drawTextWithShadow(textRenderer,cl,x+4,yy+2,0xFF9DB6FF); yy+=15;
    for(String ln:wrap(Desc.of(m.name),w,0.8f)){ text(g,ln,x,yy,0.8f,0xFFB0B0BC); yy+=9; } yy+=4;
    if(!m.settings.isEmpty()){ g.drawTextWithShadow(textRenderer,"§8GENERAL",x,yy,0xFFFFFFFF); yy+=12;
      for(Setting s:m.settings){
        switch(s.type){
          case BOOL -> { g.drawTextWithShadow(textRenderer,textRenderer.trimToWidth(s.name,w-28),x,yy+2,0xFFE6E6EE); sw(g,rx1-30,yy,s.b); hits.add(new Hit(K_SETSW,rx1-32,yy-2,28,15,m,s,0,clipR)); yy+=17; }
          case NUM -> { g.drawTextWithShadow(textRenderer,textRenderer.trimToWidth(s.name,w-34),x,yy,0xFFE6E6EE); String v=(s.step>=1)?String.valueOf((int)Math.round(s.d)):String.format("%.2f",s.d); g.drawTextWithShadow(textRenderer,v,rx1-8-textRenderer.getWidth(v),yy,0xFFFFFFFF);
                        double f=(s.d-s.min)/Math.max(1e-9,s.max-s.min); g.fill(x,yy+13,x+w,yy+16,0x55FFFFFF); g.fill(x,yy+13,x+(int)(w*f),yy+16,Hud.RED); disc(g,x+(int)(w*f)+0.5f,yy+14.5f,3.5f,0xFFFFFF,255);
                        hits.add(new Hit(K_SLIDER,x-3,yy+8,w+6,14,m,s,0,clipR)); yy+=24; }
          case COLOR -> { g.drawTextWithShadow(textRenderer,s.name,x,yy+1,0xFFE6E6EE); g.fill(rx1-26,yy,rx1-8,yy+10,0x66FFFFFF); g.fill(rx1-25,yy+1,rx1-9,yy+9,s.c|0xFF000000); hits.add(new Hit(K_COLOR,rx1-28,yy-2,22,14,m,s,0,clipR)); yy+=16; }
        }
      }
    }
    g.drawTextWithShadow(textRenderer,"§8MODULE",x,yy+2,0xFFFFFFFF); yy+=14;
    if(m.name.equals("BlockESP")||m.name.equals("XRay")){ UI.rr(g,x,yy,w,14,4,0x883B5BFF); g.drawCenteredTextWithShadow(textRenderer,"Choose blocks...",x+w/2,yy+3,0xFFFFFFFF); hits.add(new Hit(K_PICK,x,yy,w,14,m,null,0,clipR)); yy+=18; }
    if(m.name.equals("Crosshair")){ UI.rr(g,x,yy,w,14,4,0x883B5BFF); g.drawCenteredTextWithShadow(textRenderer,"Draw your crosshair...",x+w/2,yy+3,0xFFFFFFFF); hits.add(new Hit(K_XHAIR,x,yy,w,14,m,null,0,clipR)); yy+=18; }
    for(String[] bx:new String[][]{{"Spam","Edit messages...","16"},{"CrystalPvP","Choose scaffold item...","17"},{"SusChunk","Natural-block whitelist...","18"},{"ChatStyle","Edit prefix / suffix text...","19"}}) if(m.name.equals(bx[0])){ UI.rr(g,x,yy,w,14,4,0x883B5BFF); g.drawCenteredTextWithShadow(textRenderer,bx[1],x+w/2,yy+3,0xFFFFFFFF); hits.add(new Hit(Integer.parseInt(bx[2]),x,yy,w,14,m,null,0,clipR)); yy+=18; }
    String bn=binding==m?"press a key...":(m.key>=0?ModuleManager.keyName(m.key):"None"); int bw=textRenderer.getWidth(bn)+10;
    g.drawTextWithShadow(textRenderer,"Keybind",x,yy+3,0xFFE6E6EE); UI.rr(g,rx1-8-bw,yy,bw,14,4,binding==m?0xCCD41F26:0x55FFFFFF); g.drawTextWithShadow(textRenderer,bn,rx1-3-bw,yy+3,0xFFFFFFFF); hits.add(new Hit(K_BIND,rx1-8-bw,yy,bw,14,m,null,0,clipR)); yy+=19;
    g.drawTextWithShadow(textRenderer,"Hold to enable",x,yy+2,0xFFE6E6EE); sw(g,rx1-30,yy,m.hold); hits.add(new Hit(K_HOLD,rx1-32,yy-2,28,15,m,null,0,clipR)); yy+=17;
    g.disableScissor(); maxR=Math.max(0,(yy-top)-(ry1-ry0)+4); scrollR=Math.max(0,Math.min(scrollR,maxR));
  }
  Hit hitAt(double x,double y){ for(int i=hits.size()-1;i>=0;i--){ Hit h=hits.get(i); if(x>=h.x&&x<h.x+h.w&&y>=h.y&&y<h.y+h.h&&(h.clip==null||(x>=h.clip[0]&&x<h.clip[2]&&y>=h.clip[1]&&y<h.clip[3]))) return h; } return null; }
  void setSlider(Hit h,double mxp){ Setting s=h.s; double bx=h.x+3, bw=h.w-6; double f=Math.max(0,Math.min(1,(mxp-bx)/bw)); double v=s.min+f*(s.max-s.min);
    if(s.step>0) v=Math.round((v-s.min)/s.step)*s.step+s.min; s.d=Math.round(Math.max(s.min,Math.min(s.max,v))*1000)/1000.0; }
  void act(Hit h,int btn){
    switch(h.kind){
      case K_CAT -> { sel=h.idx; query=""; search.setText(""); scrollL=0; scrollR=0; }
      case K_CARD -> { selected=h.m; scrollR=0; if(btn==1) h.m.toggle(); }
      case K_SWITCH,K_RSWITCH -> h.m.toggle();
      case K_SETSW -> { h.s.b=!h.s.b; Config.save(); }
      case K_COLOR -> { h.s.cycle(); Config.save(); }
      case K_BIND -> binding=h.m;
      case K_HOLD -> { h.m.hold=!h.m.hold; Config.save(); }
      case K_PANIC -> ModuleManager.panic();
      case K_ALTS -> client.setScreen(new AltScreen(this));
      case K_PROFILES -> client.setScreen(new ProfilesScreen(this));
      case K_WINDOWS -> client.setScreen(new WindowsGui());
      case K_XHAIR -> client.setScreen(new CrosshairEditor(this));
      case K_SPAM -> client.setScreen(new SpamEditor(this));
      case K_CHAT -> client.setScreen(new ChatStyleScreen(this));
      case K_ITEM -> client.setScreen(new ItemPicker(this));
      case K_SUSWL -> client.setScreen(new BlockPicker(this,Pack7.whitelist(),"SusChunk whitelist (ignored blocks)"));
      case K_PICK -> client.setScreen(h.m.name.equals("XRay")?new BlockPicker(this,Pack4.xraySet(),"XRay"):new BlockPicker(this,Mods.blockEspSet(),"BlockESP"));
      default -> {}
    }
  }
  @Override public boolean mouseClicked(Click click,boolean doubled){ double mxp=click.x(), myp=click.y();
    pressed=true; dragged=false; px0=mxp; py0=myp; slider=null; dragRegion=0;
    Hit h=hitAt(mxp,myp); if(h!=null&&h.kind==K_SLIDER){ slider=h; setSlider(h,mxp); return true; }
    if(mxp>=mx0&&mxp<mx1&&myp>=wy+38) dragRegion=1; else if(mxp>=rx0&&mxp<wx+ww) dragRegion=2;
    if(search!=null&&in((int)mxp,(int)myp,search.getX(),search.getY(),search.getWidth(),search.getHeight())) return super.mouseClicked(click,doubled);
    return true;
  }
  @Override public boolean mouseDragged(Click click,double dx,double dy){
    if(slider!=null){ setSlider(slider,click.x()); return true; }
    if(pressed&&!dragged&&Math.hypot(click.x()-px0,click.y()-py0)>4) dragged=true;
    if(dragged){ if(dragRegion==1) scrollL=Math.max(0,Math.min(maxL,scrollL-(float)dy)); else if(dragRegion==2) scrollR=Math.max(0,Math.min(maxR,scrollR-(float)dy)); return true; }
    return super.mouseDragged(click,dx,dy);
  }
  @Override public boolean mouseReleased(Click click){
    boolean wasDrag=dragged; pressed=false; dragged=false; Hit sl=slider; slider=null;
    if(sl!=null){ Config.save(); return true; }
    if(!wasDrag){ Hit h=hitAt(click.x(),click.y()); if(h!=null){ act(h,click.button()); return true; } }
    return super.mouseReleased(click);
  }
  @Override public boolean mouseScrolled(double mx,double my,double hA,double vA){
    if(mx>=rx0) scrollR=Math.max(0,Math.min(maxR,scrollR-(float)vA*18)); else if(mx>=mx0) scrollL=Math.max(0,Math.min(maxL,scrollL-(float)vA*24)); return true;
  }
  @Override public boolean keyPressed(KeyInput input){ int key=input.key();
    if(binding!=null){ if(key==GLFW.GLFW_KEY_BACKSPACE||key==GLFW.GLFW_KEY_DELETE) binding.key=-1; else if(key!=GLFW.GLFW_KEY_ESCAPE) binding.key=key; binding=null; Config.save(); return true; }
    if(key==GLFW.GLFW_KEY_RIGHT_SHIFT){ close(); return true; }
    if(key==GLFW.GLFW_KEY_END){ ModuleManager.panic(); return true; }
    return super.keyPressed(input);
  }
  @Override public void removed(){ Config.save(); }
}
