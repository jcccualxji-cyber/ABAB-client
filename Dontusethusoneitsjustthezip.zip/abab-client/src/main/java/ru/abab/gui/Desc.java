package ru.abab.gui;
import java.util.*;
/** One-line descriptions shown in the menu. */
final class Desc {
  static final Map<String,String> M=new HashMap<>();
  static void d(String n,String t){ M.put(n.toLowerCase(),t); }
  static String of(String n){ return M.getOrDefault(n.toLowerCase(),""); }
  static {
    d("KillAura","Attacks entities around you automatically."); d("AutoCrystal","Places and breaks end crystals on enemies."); d("AutoTotem","Keeps a totem in your offhand."); d("AutoArmor","Equips your best armor automatically.");
    d("Reach","Extends your attack and build reach."); d("Trigger","Hits whatever your crosshair is on."); d("Criticals","Turns your hits into critical hits."); d("AutoGap","Eats a golden apple when you are low."); d("AutoTrap","Traps the nearest enemy in obsidian.");
    d("SelfTrap","Covers yourself with obsidian."); d("Surround","Protects your feet from crystals."); d("Burrow","Buries you inside a block."); d("AutoCity","Mines enemies' surround blocks."); d("AutoLog","Disconnects when you are in danger.");
    d("BowAimbot","Aims your bow at players."); d("BowSpam","Releases bow shots as fast as possible."); d("AutoClicker","Clicks for you at a set speed."); d("Offhand","Swaps what sits in your offhand."); d("ShieldBypass","Hits through shields.");
    d("MazeKill","Mace smash with a faked long fall."); d("SpearKill","Hold click: keeps striking your target, back and forth."); d("AimAssist","Smoothly pulls your aim toward players."); d("AutoWeb","Places cobwebs on the nearest enemy.");
    d("HoleFiller","Fills nearby holes with obsidian."); d("AutoMace","Smashes players while you fall with a mace."); d("Velocity","Reduces the knockback you take.");
    d("Flight","Lets you fly with adjustable speed."); d("Fly","Low-speed fly with anti-kick."); d("Speed","Moves you faster on the ground."); d("Step","Walk up blocks without jumping."); d("HighJump","Jump many blocks high."); d("LongJump","Jump much farther.");
    d("NoFall","Cancels fall damage."); d("Spider","Climb walls."); d("Jesus","Walk on water and lava."); d("Sprint","Always sprinting."); d("AutoWalk","Holds forward for you."); d("AutoJump","Jumps by itself."); d("Glide","Slows your fall."); d("Sneak","Holds sneak for you.");
    d("BoatFly","Fly while riding a boat."); d("EntitySpeed","Faster rides."); d("ElytraFly","Better elytra control."); d("ChunkFly","Move through unloaded chunks."); d("ChunkWalk","Walk through unloaded chunks."); d("Blink","Holds your movement, then sends it all at once.");
    d("NoSlow","No slowdown while using items."); d("WindChargeKey","Throws a wind charge at your feet."); d("ClickTP","Teleport to where you click."); d("Parkour","Jumps at block edges."); d("SafeWalk","Never walk off edges."); d("AirJump","Jump in mid-air.");
    d("Freecam","Detach the camera and fly around."); d("XRay","Highlights chosen blocks through walls (pick them in the menu)."); d("ESP","Boxes, health and gear on entities."); d("Tracers","Lines to entities."); d("StorageESP","Highlights chests, barrels and shulkers.");
    d("BlockESP","Highlights chosen blocks."); d("HoleESP","Shows safe holes."); d("Fullbright","Full brightness everywhere."); d("HUD","Watermark, coords and module list."); d("ArmorHUD","Your armor and durability on screen."); d("PotionHUD","Active effects with timers.");
    d("CPS","Clicks per second counter."); d("Speedometer","Shows your speed in blocks per second."); d("LightOverlay","Marks dark spots where mobs can spawn."); d("BarrierESP","Highlights barrier blocks."); d("SpawnerESP","Highlights mob spawners.");
    d("TrialSpawnerESP","Highlights trial spawners."); d("BedESP","Highlights beds."); d("PearlESP","Highlights thrown ender pearls."); d("TridentESP","Highlights thrown tridents."); d("WardenESP","Highlights wardens."); d("CrystalESP","Highlights end crystals."); d("ItemESP","Highlights dropped items.");
    d("SusChunk","Finds suspicious chunks (bases and stashes)."); d("Waypoints","Saved places with distance."); d("Zoom","Hold to zoom in."); d("Trajectories","Shows where projectiles will land."); d("Breadcrumbs","Leaves a trail behind you.");
    d("Nuker","Breaks blocks around you."); d("AutoMine","Holds attack while you look at a block."); d("AutoFarm","Harvests ripe crops near you."); d("BonemealAura","Bone-meals crops near you."); d("Scaffold","Places blocks under your feet."); d("LiquidFiller","Fills lava and water around you.");
    d("AutoEat","Eats when you are hungry."); d("AutoTool","Picks the best tool for the block."); d("AutoFish","Fishes for you."); d("AutoReplenish","Refills your hotbar."); d("AntiBlind","Removes blindness, darkness and nausea."); d("FastUse","No delay between item uses."); d("SpeedMine","Mines blocks faster.");
    d("ChestStealer","Takes loot from chests."); d("AutoRespawn","Respawns instantly."); d("AutoMend","Repairs gear with experience."); d("AutoShearer","Shears sheep nearby."); d("AutoMount","Gets on nearby rides."); d("AutoBreed","Breeds animals nearby.");
    d("Chams","Filled body silhouettes through walls."); d("PopChams","Ghost + chat message when someone pops a totem."); d("NoClip","Move through blocks (use with HoldPackets to hide)."); d("FakeLag","Sends your position in bursts, you still play normally.");
    d("TPAura","Hits from a different spot around the target each time."); d("MaceAura","TPAura + MazeKill: teleport, fake fall, smash, return."); d("AutoObsidian","Obsidian beside grounded enemies / under airborne ones.");
    d("FastCrystal","Breaks every crystal in reach instantly."); d("AnchorAura","Places, charges and blows respawn anchors on enemies."); d("TargetStrafe","Circles around the nearest player while you attack.");
    d("AntiKnockback","Drops the knockback the server sends you.");
    d("Phase","Walk through walls (noclip only while you touch blocks)."); d("CrystalPvP","Obsidian base (air/floor) + crystals + breaking, with 3 delays."); d("SusChunk","Scores chunks by player-made blocks, with center/edge overlay.");
    d("Spam","Sends your saved messages (.spam add <text>)."); d("InventoryMove","Keep walking while an inventory is open."); d("YawLock","Locks your yaw to 45-degree steps."); d("FastFall","Falls faster."); d("HoleSnap","Moves you into the nearest hole.");
    d("TPToPlayer","Teleports you to the nearest player (over walls via the sky, flies if blocked)."); d("HitSound","Your own sounds for hits, crystals and totem pops (can mute vanilla)."); d("ChatStyle","Adds your prefix/suffix to messages and restyles the letters.");
    d("BlockESP","Highlights chosen blocks (use the picker; try OnlySusChunks)."); d("SpearAura","Auto spear: strikes the nearest target (teleport, fly or chase)."); d("BackCTP","Escapes enemy crystals: teleports out of range / vclips up or down.");
    d("AutoPanic","Turns every hack off when your health is low."); d("Crosshair","Replaces the vanilla crosshair (Style 5 = your own drawing).");
  }
}
