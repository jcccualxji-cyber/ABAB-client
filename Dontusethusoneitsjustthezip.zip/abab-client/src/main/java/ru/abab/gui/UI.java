package ru.abab.gui;
import net.minecraft.client.gui.DrawContext;
/** Small drawing helpers: rounded rectangles. */
public final class UI {
  public static void rr(DrawContext g,int x,int y,int w,int h,int r,int c){
    if((c>>>24)==0||w<=0||h<=0) return;
    r=Math.min(r,Math.min(w,h)/2); if(r<=0){ g.fill(x,y,x+w,y+h,c); return; }
    g.fill(x,y+r,x+w,y+h-r,c);
    for(int i=0;i<r;i++){ double d=r-i-0.5; int inset=(int)Math.round(r-Math.sqrt(r*r-d*d)); g.fill(x+inset,y+i,x+w-inset,y+i+1,c); g.fill(x+inset,y+h-1-i,x+w-inset,y+h-i,c); }
  }
}
