package ru.abab.gui;
import java.nio.file.*;
import java.util.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import ru.abab.core.ConfigCode;
/** Config profiles. Save = store what is ON (modules + their settings + keybinds). Copy = one line of text you can send to a friend. Import = paste a friend's text and it becomes a new profile. */
public class ProfilesScreen extends Screen {
  record H(int kind,int x,int y,int w,int h,int idx){}
  final Screen parent; final List<H> hits=new ArrayList<>(); List<String> names=new ArrayList<>(); TextFieldWidget input; int scroll; String msg=""; boolean pressed,dragged; double py0; float acc;
  int px,py,pw,ph,rows; static final int RH=20;
  public ProfilesScreen(Screen p){ super(Text.literal("Profiles")); parent=p; }
  static Path dir(){ return FabricLoader.getInstance().getConfigDir().resolve("abab-profiles"); }
  static List<String> list(){ List<String> l=new ArrayList<>(); try{ Path d=dir(); if(Files.isDirectory(d)) try(var s=Files.list(d)){ s.forEach(f->{ String n=f.getFileName().toString(); if(n.endsWith(".txt")) l.add(n.substring(0,n.length()-4)); }); } }catch(Exception e){ e.printStackTrace(); } Collections.sort(l); return l; }
  static String clean(String n){ return n.replaceAll("[^A-Za-z0-9_\\- ]","").trim(); }
  static void write(String n,String text){ try{ Files.createDirectories(dir()); Files.writeString(dir().resolve(n+".txt"),text); }catch(Exception e){ e.printStackTrace(); } }
  static String read(String n){ try{ return Files.readString(dir().resolve(n+".txt")); }catch(Exception e){ return ""; } }
  static void save(String n){ write(n,ConfigCode.currentText()); }
  static void load(String n){ ConfigCode.apply(n==null?"":read(n)); }
  @Override protected void init(){ pw=Math.min(320,width-10); ph=Math.min(250,height-10); px=width/2-pw/2; py=height/2-ph/2; rows=Math.max(1,(ph-134)/RH); names=list();
    input=new TextFieldWidget(textRenderer,px+10,py+44,pw-76,16,Text.literal("profile")); input.setMaxLength(30000); addDrawableChild(input); setInitialFocus(input); }
  @Override public boolean shouldPause(){ return false; }
  @Override public void renderBackground(DrawContext g,int mx,int my,float d){ }
  void btn(DrawContext g,int kind,int x,int y,int w,int h,String t,int col,int idx,int mx,int my){ boolean hv=mx>=x&&mx<x+w&&my>=y&&my<y+h; UI.rr(g,x,y,w,h,4,hv?(0xFF000000|col):(0xAA000000|col)); g.drawCenteredTextWithShadow(textRenderer,t,x+w/2,y+(h-8)/2,0xFFFFFFFF); hits.add(new H(kind,x,y,w,h,idx)); }
  @Override public void render(DrawContext g,int mx,int my,float delta){
    hits.clear(); g.fillGradient(0,0,width,height,0x77000000,0xAA000010);
    UI.rr(g,px-1,py-1,pw+2,ph+2,9,0x40FFFFFF); UI.rr(g,px,py,pw,ph,8,0xB00B0B12); g.fill(px+10,py,px+pw/2,py+2,Hud.RED); g.fill(px+pw/2,py,px+pw-10,py+2,Hud.BLUE);
    g.getMatrices().pushMatrix(); g.getMatrices().translate((float)(px+12),(float)(py+9)); g.getMatrices().scale(1.5f,1.5f); g.drawTextWithShadow(textRenderer,"Configs",0,0,0xFFFFFFFF); g.getMatrices().popMatrix();
    g.drawTextWithShadow(textRenderer,"§7Name + Save = store what is ON (with settings & keybinds).",px+12,py+26,0xFFFFFFFF);
    g.drawTextWithShadow(textRenderer,"§fCopy§7 = a text code to send to a friend · §fImport§7 = paste a friend's code",px+12,py+35,0xFFFFFFFF);
    input.render(g,mx,my,delta); if(input.getText().isEmpty()&&!input.isFocused()) g.drawTextWithShadow(textRenderer,"§7profile name (or paste a code here)",px+14,py+48,0xFFFFFFFF);
    btn(g,1,px+pw-62,py+43,52,18,"Save",0x2F9F4F,0,mx,my);
    int half=(pw-24)/2; btn(g,6,px+10,py+64,half,18,"Copy current config",0x2F5BFF,0,mx,my); btn(g,7,px+14+half,py+64,half,18,"Import (paste code)",0x8A2BE2,0,mx,my);
    int y=py+88, x0=px+10, x1=px+pw-10;
    UI.rr(g,x0,y,x1-x0,RH-3,4,0x44D41F26); g.drawTextWithShadow(textRenderer,"Clean  §7(no hacks at all)",x0+8,y+5,0xFFFFFFFF); btn(g,2,x1-48,y+2,44,RH-7,"Load",0x2F9F4F,0,mx,my); y+=RH;
    scroll=Math.max(0,Math.min(scroll,Math.max(0,names.size()-(rows-1))));
    for(int i=scroll;i<Math.min(names.size(),scroll+rows-1);i++){ UI.rr(g,x0,y,x1-x0,RH-3,4,0x30FFFFFF); g.drawTextWithShadow(textRenderer,textRenderer.trimToWidth(names.get(i),x1-x0-140),x0+8,y+5,0xFFFFFFFF);
      btn(g,3,x1-124,y+2,38,RH-7,"Load",0x2F9F4F,i,mx,my); btn(g,8,x1-82,y+2,42,RH-7,"Copy",0x2F5BFF,i,mx,my); btn(g,4,x1-36,y+2,34,RH-7,"X",0xD41F26,i,mx,my); y+=RH; }
    if(!msg.isEmpty()) g.drawTextWithShadow(textRenderer,textRenderer.trimToWidth(msg,pw-90),px+12,py+ph-20,0xFFFFFFFF);
    btn(g,5,px+pw-70,py+ph-24,60,18,"Back",0x555566,0,mx,my);
  }
  void copy(String text,String what){ String code=ConfigCode.encode(text); client.keyboard.setClipboard(code); input.setText(code.length()<30000?code:""); msg="§aCopied "+what+" ("+code.length()+" chars). Send it to a friend."; }
  void importCode(String raw){ String text=ConfigCode.decode(raw); if(text==null){ msg="§cThat is not an ABAB config code"; return; }
    String n=clean(input.getText().startsWith(ConfigCode.PREFIX)?"":input.getText()); if(n.isEmpty()||list().contains(n)) n="imported-"+(System.currentTimeMillis()/1000%100000);
    write(n,text); names=list(); int on=ConfigCode.apply(text); input.setText(""); msg="§aImported as §f"+n+"§a ("+on+" modules enabled)"; }
  void act(H h){
    switch(h.kind){
      case 1 -> { String n=clean(input.getText()); if(n.isEmpty()){ msg="§cType a name first"; return; } save(n); names=list(); input.setText(""); msg="§aSaved §f"+n; }
      case 2 -> { load(null); msg="§aAll hacks are OFF"; }
      case 3 -> { load(names.get(h.idx)); msg="§aLoaded §f"+names.get(h.idx); }
      case 4 -> { try{ Files.deleteIfExists(dir().resolve(names.get(h.idx)+".txt")); }catch(Exception e){ e.printStackTrace(); } names=list(); }
      case 5 -> client.setScreen(parent);
      case 6 -> copy(ConfigCode.currentText(),"your current config");
      case 7 -> { String clip=client.keyboard.getClipboard(); if(ConfigCode.decode(clip)==null&&input.getText().length()>10) clip=input.getText(); importCode(clip); }
      case 8 -> { String t=read(names.get(h.idx)); if(!t.contains("|")&&!t.startsWith("ABAB")){ StringBuilder sb=new StringBuilder("ABAB-CONFIG 1\n"); for(String l:t.split("\n")) if(!l.isBlank()) sb.append("M|").append(l.trim()).append("|-1|0\n"); t=sb.toString(); } copy(t,names.get(h.idx)); }
      default -> {}
    }
  }
  @Override public boolean mouseClicked(Click click,boolean doubled){ pressed=true; dragged=false; py0=click.y(); acc=0; if(click.y()>=py+42&&click.y()<py+62&&click.x()<px+pw-64) return super.mouseClicked(click,doubled); return true; }
  @Override public boolean mouseDragged(Click click,double dx,double dy){ if(pressed&&Math.abs(click.y()-py0)>4) dragged=true;
    if(dragged){ acc-=dy; while(acc>=RH){ acc-=RH; scroll++; } while(acc<=-RH){ acc+=RH; scroll--; } return true; } return super.mouseDragged(click,dx,dy); }
  @Override public boolean mouseReleased(Click click){ boolean wd=dragged; pressed=false; dragged=false; if(wd||click.button()!=0) return true;
    for(int i=hits.size()-1;i>=0;i--){ H h=hits.get(i); if(click.x()>=h.x&&click.x()<h.x+h.w&&click.y()>=h.y&&click.y()<h.y+h.h){ act(h); return true; } } return super.mouseReleased(click); }
  @Override public boolean mouseScrolled(double mx,double my,double hA,double vA){ scroll=Math.max(0,scroll-(int)Math.signum(vA)); return true; }
  @Override public boolean keyPressed(KeyInput input){ if(input.key()==GLFW.GLFW_KEY_ESCAPE){ client.setScreen(parent); return true; } return super.keyPressed(input); }
}
