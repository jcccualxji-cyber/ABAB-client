package ru.abab.gui;
import java.util.*;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.item.*;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import ru.abab.core.Config;
import ru.abab.mods.Pack7;
/** Pick ANY Minecraft item for the CrystalPvP "ScaffoldAround" feature (it is used if it is in your inventory). Tap an item to choose it. */
public class ItemPicker extends Screen {
  static List<Item> ALL; final Screen parent; String q=""; int scroll; List<Item> list=new ArrayList<>(); TextFieldWidget search; int px,py,pw,ph,rows; static final int RH=16; boolean pressed,dragged; double py0; float acc;
  public ItemPicker(Screen p){ super(Text.literal("Items")); parent=p; }
  static String id(Item i){ return Registries.ITEM.getId(i).getPath(); }
  @Override protected void init(){
    if(ALL==null){ ALL=new ArrayList<>(); for(Item i:Registries.ITEM) if(i!=Items.AIR) ALL.add(i); ALL.sort(Comparator.comparing(ItemPicker::id)); }
    pw=Math.min(290,width-10); ph=height-16; px=width/2-pw/2; py=8; rows=Math.max(1,(ph-72)/RH);
    search=new TextFieldWidget(textRenderer,px+6,py+20,pw-12,14,Text.literal("search")); search.setMaxLength(30);
    search.setChangedListener(s->{ q=s.toLowerCase().trim().replace(' ','_'); scroll=0; refilter(); }); addDrawableChild(search); setInitialFocus(search); refilter(); }
  void refilter(){ list.clear(); for(Item i:ALL) if(q.isEmpty()||id(i).contains(q)) list.add(i); scroll=Math.max(0,Math.min(scroll,Math.max(0,list.size()-rows))); }
  @Override public boolean shouldPause(){ return false; }
  @Override public void renderBackground(DrawContext g,int mx,int my,float d){ }
  @Override public void render(DrawContext g,int mx,int my,float delta){
    g.fillGradient(0,0,width,height,0x77000000,0xAA000010);
    g.fill(px-1,py-1,px+pw+1,py+ph+1,0x30FFFFFF); UI.rr(g,px,py,pw,ph,8,0xAA0B0B12); g.fill(px+10,py,px+pw/2,py+2,Hud.RED); g.fill(px+pw/2,py,px+pw-10,py+2,Hud.BLUE);
    g.drawTextWithShadow(textRenderer,"§cScaffold item §f- selected: §a"+id(Pack7.scaffold())+" §7("+list.size()+" shown)",px+6,py+7,0xFFFFFFFF);
    search.render(g,mx,my,delta); if(search.getText().isEmpty()&&!search.isFocused()) g.drawTextWithShadow(textRenderer,"§7type to search any item (obsidian, cobweb, anvil...)",px+10,py+23,0xFFFFFFFF);
    int y=py+38; for(int i=scroll;i<Math.min(list.size(),scroll+rows);i++){ Item it=list.get(i); boolean sel=it==Pack7.scaffold(); boolean hv=mx>=px+6&&mx<px+pw-6&&my>=y&&my<y+RH;
      UI.rr(g,px+6,y,pw-12,RH-1,3,sel?0xAA8F1A20:(hv?0x55FFFFFF:0x30FFFFFF)); g.drawItem(new ItemStack(it),px+9,y); g.drawTextWithShadow(textRenderer,id(it),px+28,y+4,sel?0xFFFFFFFF:0xFFB5B5BD); if(sel) g.drawTextWithShadow(textRenderer,"ON",px+pw-24,y+4,0xFF3BFF6A); y+=RH; }
    int by=py+ph-26; UI.rr(g,px+pw-90,by,84,18,4,0xAA2F9F4F); g.drawCenteredTextWithShadow(textRenderer,"Done",px+pw-48,by+5,0xFFFFFFFF); }
  @Override public boolean mouseClicked(Click click,boolean doubled){ pressed=true; dragged=false; py0=click.y(); acc=0; if(click.y()>=py+18&&click.y()<py+36) return super.mouseClicked(click,doubled); return true; }
  @Override public boolean mouseDragged(Click click,double dx,double dy){ if(pressed&&Math.abs(click.y()-py0)>4) dragged=true; if(dragged){ acc-=dy; while(acc>=RH){ acc-=RH; scroll++; } while(acc<=-RH){ acc+=RH; scroll--; } scroll=Math.max(0,Math.min(scroll,Math.max(0,list.size()-rows))); return true; } return super.mouseDragged(click,dx,dy); }
  @Override public boolean mouseReleased(Click click){ boolean wd=dragged; pressed=false; dragged=false; if(wd||click.button()!=0) return true; double mx=click.x(), my=click.y(); int by=py+ph-26;
    if(my>=by&&my<by+18&&mx>=px+pw-90&&mx<px+pw-6){ client.setScreen(parent); return true; }
    int y=py+38; for(int i=scroll;i<Math.min(list.size(),scroll+rows);i++){ if(mx>=px+6&&mx<px+pw-6&&my>=y&&my<y+RH){ Pack7.setScaffold(list.get(i)); Config.save(); return true; } y+=RH; }
    return super.mouseReleased(click); }
  @Override public boolean mouseScrolled(double mx,double my,double hA,double vA){ scroll=Math.max(0,Math.min(Math.max(0,list.size()-rows),scroll-(int)Math.signum(vA)*3)); return true; }
  @Override public boolean keyPressed(KeyInput input){ if(input.key()==GLFW.GLFW_KEY_ESCAPE){ client.setScreen(parent); return true; } return super.keyPressed(input); }
  @Override public void removed(){ Config.save(); }
}
