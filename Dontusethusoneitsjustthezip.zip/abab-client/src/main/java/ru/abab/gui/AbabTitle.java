package ru.abab.gui;
import java.util.*;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;
import ru.abab.core.ModuleManager;
/** ABAB CLIENT main menu, "liquid" style: animated waves + glowing blobs behind a glass panel with rounded buttons. */
public class AbabTitle extends Screen {
  public static boolean enabled=true;
  record Btn(String t,Runnable r){}
  final List<Btn> btns=new ArrayList<>(); float[] hov; final float[][] fl=new float[60][5]; final Random rnd=new Random(); long last=System.nanoTime(); float time;
  static final int BW=200, BH=22, GAP=6;
  public AbabTitle(){ super(Text.literal("ABAB CLIENT")); }
  @Override protected void init(){
    btns.clear();
    btns.add(new Btn("Singleplayer",()->client.setScreen(new SelectWorldScreen(this))));
    btns.add(new Btn("Multiplayer",()->client.setScreen(new MultiplayerScreen(this))));
    btns.add(new Btn("Alt Manager",()->client.setScreen(new AltScreen(this))));
    btns.add(new Btn("Options",()->client.setScreen(new OptionsScreen(this,client.options))));
    btns.add(new Btn("Quit Game",()->client.scheduleStop()));
    hov=new float[btns.size()];
    for(float[] f:fl){ f[0]=rnd.nextFloat()*width; f[1]=rnd.nextFloat()*height; f[2]=0.8f+rnd.nextFloat()*2f; f[3]=6+rnd.nextFloat()*20; f[4]=rnd.nextFloat()*6.28f; }
  }
  @Override public boolean shouldCloseOnEsc(){ return false; }
  @Override public void renderBackground(DrawContext g,int mx,int my,float d){ }
  static int al(int c,float k){ return ((int)((c>>>24)*Math.max(0,Math.min(1,k)))<<24)|(c&0xFFFFFF); }
  static int mix(int a,int b,float t){ int r=(int)(((a>>16)&255)*(1-t)+((b>>16)&255)*t), gg=(int)(((a>>8)&255)*(1-t)+((b>>8)&255)*t), bl=(int)((a&255)*(1-t)+(b&255)*t); return 0xFF000000|(r<<16)|(gg<<8)|bl; }
  @Override public void render(DrawContext g,int mx,int my,float delta){
    long n=System.nanoTime(); float dt=Math.min(0.1f,(n-last)/1e9f); last=n; time+=dt; float ease=Math.min(1f,time/0.7f);
    g.fillGradient(0,0,width,height,0xFF06060D,0xFF160A1E);
    // glowing blobs
    float[][] bl={{0.18f,0.30f,60,0xD41F26},{0.82f,0.25f,70,0x2F5BFF},{0.55f,0.85f,80,0x8A2BE2}};
    for(int i=0;i<bl.length;i++){ float bx=width*bl[i][0]+(float)Math.sin(time*0.5+i*2)*20, by=height*bl[i][1]+(float)Math.cos(time*0.4+i)*14; int rgb=(int)bl[i][3];
      for(int k=4;k>=1;k--) ClickGui.disc(g,bx,by,bl[i][2]*k/4f,rgb,9); }
    // liquid waves
    int[] wc={0x40D41F26,0x402F5BFF,0x508A2BE2};
    for(int l=0;l<3;l++){ double base=height*(0.74+0.065*l), amp=7+4*l; for(int x=0;x<width;x+=2){ double y=base+Math.sin(x*0.018+time*(0.7+0.25*l)+l*1.7)*amp+Math.sin(x*0.04-time*1.2)*amp*0.4; g.fill(x,(int)y,x+2,height,wc[l]); } }
    for(float[] f:fl){ f[1]-=f[3]*dt*0.4f; f[4]+=dt; f[0]+=Math.sin(f[4])*4*dt; if(f[1]<-6){ f[1]=height+6; f[0]=rnd.nextFloat()*width; } ClickGui.disc(g,f[0],f[1],f[2]+2,0xFFFFFF,8); ClickGui.disc(g,f[0],f[1],f[2],0xFFFFFF,110); }
    // glass panel
    int pw=BW+40, ph=btns.size()*(BH+GAP)+112, px=width/2-pw/2, py=Math.max(6,height/2-ph/2-4)+(int)((1-ease)*14);
    UI.rr(g,px-1,py-1,pw+2,ph+2,11,al(0x40FFFFFF,ease)); UI.rr(g,px,py,pw,ph,10,al(0x8C0B0B16,ease));
    g.fill(px+14,py,px+pw/2,py+2,al(Hud.RED,ease)); g.fill(px+pw/2,py,px+pw-14,py+2,al(Hud.BLUE,ease));
    // logo: gradient letters
    String logo="ABAB"; float sc=4f; int lw=(int)(textRenderer.getWidth(logo)*sc); float lx=width/2f-lw/2f; g.getMatrices().pushMatrix(); g.getMatrices().translate(lx,(float)(py+16)); g.getMatrices().scale(sc,sc);
    int xo=0; for(int i=0;i<logo.length();i++){ String c=logo.substring(i,i+1); g.drawTextWithShadow(textRenderer,c,xo,0,al(mix(0xFFD41F26,0xFF2F5BFF,i/3f),ease)); xo+=textRenderer.getWidth(c); } g.getMatrices().popMatrix();
    String sub="C L I E N T"; g.drawTextWithShadow(textRenderer,sub,width/2-textRenderer.getWidth(sub)/2,py+54,al(0xFFFFFFFF,ease));
    int wl=(int)(40+8*Math.sin(time*2)); g.fill(width/2-wl,py+68,width/2,py+70,al(Hud.RED,ease)); g.fill(width/2,py+68,width/2+wl,py+70,al(Hud.BLUE,ease));
    // buttons
    int x=width/2-BW/2, y=py+82;
    for(int i=0;i<btns.size();i++){ Btn b=btns.get(i); boolean hv=mx>=x&&mx<x+BW&&my>=y&&my<y+BH; hov[i]+=((hv?1f:0f)-hov[i])*Math.min(1f,dt*14f); float h=hov[i];
      UI.rr(g,x-1,y-1,BW+2,BH+2,7,al(mix(0xFF2B2B38,0xFFFFFFFF,h),ease)); UI.rr(g,x,y,BW,BH,6,al(mix(0xFF101018,0xFFD41F26,h*0.85f),ease));
      g.fill(x+6,y+5,x+8+(int)(2*h),y+BH-5,al(Hud.BLUE,ease)); g.drawCenteredTextWithShadow(textRenderer,b.t,x+BW/2+(int)(3*h),y+7,al(0xFFFFFFFF,ease)); y+=BH+GAP; }
    // account badge + footer
    String un=AltScreen.user(); boolean prem=AltScreen.premium(); int bx=width-130, by=height-26;
    UI.rr(g,bx,by,124,20,6,al(0x66000000,ease)); ClickGui.disc(g,bx+11,by+10,7,0x2F5BFF,(int)(255*ease)); g.drawCenteredTextWithShadow(textRenderer,un.isEmpty()?"?":un.substring(0,1).toUpperCase(),bx+11,by+6,al(0xFFFFFFFF,ease));
    g.drawTextWithShadow(textRenderer,textRenderer.trimToWidth(un,90),bx+22,by+2,al(0xFFFFFFFF,ease)); g.getMatrices().pushMatrix(); g.getMatrices().translate((float)(bx+22),(float)(by+12)); g.getMatrices().scale(0.7f,0.7f);
    g.drawTextWithShadow(textRenderer,prem?"PREMIUM":"CRACKED",0,0,al(prem?0xFF3BFF6A:0xFFFFB03B,ease)); g.getMatrices().popMatrix();
    g.drawTextWithShadow(textRenderer,"§7ABAB Client | Minecraft 1.21.11 | "+ModuleManager.all.size()+" modules",6,height-12,al(0xFFFFFFFF,ease));
  }
  @Override public boolean mouseClicked(Click click,boolean doubled){
    if(click.button()==0){ double mx=click.x(), my=click.y(); int pw=BW+40, ph=btns.size()*(BH+GAP)+112, py=Math.max(6,height/2-ph/2-4); int x=width/2-BW/2, y=py+82;
      for(Btn b:btns){ if(mx>=x&&mx<x+BW&&my>=y&&my<y+BH){ b.r.run(); return true; } y+=BH+GAP; } }
    return super.mouseClicked(click,doubled);
  }
}
