package ru.abab.gui;
import java.util.*;
import net.minecraft.block.*;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.item.*;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import ru.abab.core.*;
/** Pick blocks for BlockESP / XRay: type to search (touch keyboard works), tap a block to add/remove it, drag or wheel to scroll. */
public class BlockPicker extends Screen {
  static List<Block> ALL;
  final Screen parent; final Set<Block> set; final String title; String q=""; int scroll; List<Block> list=new ArrayList<>(); TextFieldWidget search;
  int px,py,pw,ph,rows; static final int RH=16; boolean pressed,dragged; double py0; float acc;
  public BlockPicker(Screen p,Set<Block> set,String title){ super(Text.literal("Blocks")); parent=p; this.set=set; this.title=title; }
  public static int addOres(Set<Block> s){ int n=0; for(Block b:Registries.BLOCK){ String p=Registries.BLOCK.getId(b).getPath(); if(p.endsWith("_ore")||p.equals("ancient_debris")){ if(s.add(b)) n++; } } return n; }
  @Override protected void init(){
    if(ALL==null){ ALL=new ArrayList<>(); for(Block b:Registries.BLOCK) if(b!=Blocks.AIR) ALL.add(b); ALL.sort(Comparator.comparing(b->Registries.BLOCK.getId(b).getPath())); }
    pw=Math.min(290,width-10); ph=height-16; px=width/2-pw/2; py=8; rows=Math.max(1,(ph-72)/RH);
    search=new TextFieldWidget(textRenderer,px+6,py+20,pw-12,14,Text.literal("search")); search.setMaxLength(30);
    search.setChangedListener(s->{ q=s.toLowerCase().trim().replace(' ','_'); scroll=0; refilter(); }); addDrawableChild(search); setInitialFocus(search); refilter();
  }
  static String id(Block b){ return Registries.BLOCK.getId(b).getPath(); }
  void refilter(){ list.clear(); for(Block b:ALL) if(q.isEmpty()||id(b).contains(q)) list.add(b);
    if(q.isEmpty()) list.sort(Comparator.comparing((Block b)->!set.contains(b)).thenComparing(BlockPicker::id));
    scroll=Math.max(0,Math.min(scroll,Math.max(0,list.size()-rows))); }
  @Override public boolean shouldPause(){ return false; }
  @Override public void renderBackground(DrawContext g,int mx,int my,float d){ }
  @Override public void render(DrawContext g,int mx,int my,float delta){
    g.fillGradient(0,0,width,height,0x77000000,0xAA000010);
    g.fill(px-1,py-1,px+pw+1,py+ph+1,0x30FFFFFF); g.fill(px,py,px+pw,py+ph,0xAA0B0B12); g.fill(px,py,px+pw/2,py+2,Hud.RED); g.fill(px+pw/2,py,px+pw,py+2,Hud.BLUE);
    g.drawTextWithShadow(textRenderer,"§c"+title+" §f- choose blocks §7("+set.size()+" selected, "+list.size()+" shown)",px+6,py+7,0xFFFFFFFF);
    search.render(g,mx,my,delta); if(search.getText().isEmpty()&&!search.isFocused()) g.drawTextWithShadow(textRenderer,"§7type to search (diamond, ore, chest...)",px+10,py+23,0xFFFFFFFF);
    int y=py+38;
    for(int i=scroll;i<Math.min(list.size(),scroll+rows);i++){ Block b=list.get(i); boolean sel=set.contains(b); boolean hv=mx>=px+6&&mx<px+pw-6&&my>=y&&my<y+RH;
      g.fill(px+6,y,px+pw-6,y+RH-1,sel?0xAA8F1A20:(hv?0x55FFFFFF:0x30FFFFFF));
      Item it=b.asItem(); if(it!=Items.AIR) g.drawItem(new ItemStack(it),px+9,y); g.drawTextWithShadow(textRenderer,id(b),px+28,y+4,sel?0xFFFFFFFF:0xFFB5B5BD);
      if(sel) g.drawTextWithShadow(textRenderer,"ON",px+pw-24,y+4,0xFF3BFF6A); y+=RH; }
    int by=py+ph-26; btn(g,px+6,by,84,"Add all ores",mx,my); btn(g,px+96,by,84,"Clear all",mx,my); btn(g,px+pw-90,by,84,"Done",mx,my);
  }
  void btn(DrawContext g,int x,int y,int w,String t,int mx,int my){ boolean hv=mx>=x&&mx<x+w&&my>=y&&my<y+18; g.fill(x,y,x+w,y+18,hv?0xFFD41F26:0xAA3A1014); g.drawCenteredTextWithShadow(textRenderer,t,x+w/2,y+5,0xFFFFFFFF); }
  @Override public boolean mouseClicked(Click click,boolean doubled){ pressed=true; dragged=false; py0=click.y(); acc=0;
    if(click.y()>=py+18&&click.y()<py+36) return super.mouseClicked(click,doubled); return true; }
  @Override public boolean mouseDragged(Click click,double dx,double dy){
    if(pressed&&Math.abs(click.y()-py0)>4) dragged=true;
    if(dragged){ acc-=dy; while(acc>=RH){ acc-=RH; scroll++; } while(acc<=-RH){ acc+=RH; scroll--; } scroll=Math.max(0,Math.min(scroll,Math.max(0,list.size()-rows))); return true; }
    return super.mouseDragged(click,dx,dy); }
  @Override public boolean mouseReleased(Click click){ boolean wd=dragged; pressed=false; dragged=false; if(wd||click.button()!=0) return true;
    double mx=click.x(), my=click.y(); int by=py+ph-26;
    if(my>=by&&my<by+18){
      if(mx>=px+6&&mx<px+90){ addOres(set); Config.save(); refilter(); return true; }
      if(mx>=px+96&&mx<px+180){ set.clear(); Config.save(); refilter(); return true; }
      if(mx>=px+pw-90&&mx<px+pw-6){ client.setScreen(parent); return true; } }
    int y=py+38;
    for(int i=scroll;i<Math.min(list.size(),scroll+rows);i++){ if(mx>=px+6&&mx<px+pw-6&&my>=y&&my<y+RH){ Block b=list.get(i); if(!set.remove(b)) set.add(b); Config.save(); return true; } y+=RH; }
    return super.mouseReleased(click); }
  @Override public boolean mouseScrolled(double mx,double my,double hA,double vA){ scroll=Math.max(0,Math.min(Math.max(0,list.size()-rows),scroll-(int)Math.signum(vA)*3)); return true; }
  @Override public boolean keyPressed(KeyInput input){ if(input.key()==GLFW.GLFW_KEY_ESCAPE){ client.setScreen(parent); return true; } return super.keyPressed(input); }
  @Override public void removed(){ Config.save(); }
}
