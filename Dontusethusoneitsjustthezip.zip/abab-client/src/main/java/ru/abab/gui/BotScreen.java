package ru.abab.gui;
import java.util.*;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import ru.abab.bots.*;
/**
 * Bot console. Bots are offline accounts that stay connected (AFK warp) and run the commands you send. Offline-mode servers only.
 *  - tap a bot row = select / unselect it     - X = remove that bot
 *  - commands go to the SELECTED bots (or  @name1,name2 /cmd  /  #5 /cmd  for the first 5 online bots)
 */
public class BotScreen extends Screen {
  record H(int kind,int x,int y,int w,int h,int idx){}
  static final Set<String> SHORT=Set.of("tpa","tpahere","tpaccept","tpdeny","tpno","warp","home","sethome","spawn","back","login","register","kill","rtp","afk");
  final Screen parent; final List<H> hits=new ArrayList<>(); TextFieldWidget input, countF; int px,py,pw,ph,rowsB,scrollB; String msg=""; boolean pressed,dragged; double py0; float acc;
  public BotScreen(Screen p){ super(Text.literal("Bots")); parent=p; BotManager.load(); }
  @Override protected void init(){ pw=Math.min(350,width-8); ph=Math.min(256,height-8); px=width/2-pw/2; py=height/2-ph/2; rowsB=Math.max(2,Math.min(6,(ph-190)/14));
    input=new TextFieldWidget(textRenderer,px+8,py+ph-46,pw-70,16,Text.literal("console")); input.setMaxLength(200); addDrawableChild(input);
    countF=new TextFieldWidget(textRenderer,px+104,py+50,34,16,Text.literal("n")); countF.setMaxLength(3); addDrawableChild(countF); setInitialFocus(input); }
  @Override public boolean shouldPause(){ return false; }
  @Override public void renderBackground(DrawContext g,int mx,int my,float d){ }
  void btn(DrawContext g,int kind,int x,int y,int w,int h,String t,int col,int idx,int mx,int my){ boolean hv=mx>=x&&mx<x+w&&my>=y&&my<y+h; UI.rr(g,x,y,w,h,4,hv?(0xFF000000|col):(0xAA000000|col)); g.drawCenteredTextWithShadow(textRenderer,t,x+w/2,y+(h-8)/2,0xFFFFFFFF); hits.add(new H(kind,x,y,w,h,idx)); }
  @Override public void render(DrawContext g,int mx,int my,float delta){
    hits.clear(); g.fillGradient(0,0,width,height,0x77000000,0xAA000010);
    UI.rr(g,px-1,py-1,pw+2,ph+2,9,0x40FFFFFF); UI.rr(g,px,py,pw,ph,8,0xB00B0B12); g.fill(px+10,py,px+pw/2,py+2,Hud.RED); g.fill(px+pw/2,py,px+pw-10,py+2,Hud.BLUE);
    g.getMatrices().pushMatrix(); g.getMatrices().translate((float)(px+10),(float)(py+8)); g.getMatrices().scale(1.4f,1.4f); g.drawTextWithShadow(textRenderer,"Bots",0,0,0xFFFFFFFF); g.getMatrices().popMatrix();
    g.drawTextWithShadow(textRenderer,"§7Offline accounts that stay online (AFK). Offline-mode servers only.",px+56,py+12,0xFFFFFFFF);
    g.drawTextWithShadow(textRenderer,"§fTap a bot§7 = select / unselect · §fX§7 = remove it · §fcommands go to the selected bots",px+8,py+26,0xFFFFFFFF);
    g.drawTextWithShadow(textRenderer,"§7e.g.  /tpa Steve   ·   @Bot1,Bot2 /warp afk   ·   #5 /home   ·   type help",px+8,py+36,0xFFFFFFFF);
    int total=BotManager.bots.size(), sel=BotManager.selectedCount();
    btn(g,6,px+8,py+50,44,16,"All",0x2F9F4F,0,mx,my); btn(g,7,px+56,py+50,44,16,"None",0x555566,0,mx,my);
    countF.render(g,mx,my,delta); if(countF.getText().isEmpty()&&!countF.isFocused()) g.drawTextWithShadow(textRenderer,"§7n",px+116,py+54,0xFFFFFFFF);
    btn(g,8,px+142,py+50,58,16,"Select n",0x2F5BFF,0,mx,my); g.drawTextWithShadow(textRenderer,"§f"+sel+"§7/"+total+" selected",px+206,py+54,0xFFFFFFFF);
    int y=py+70, x0=px+8, x1=px+pw-8; scrollB=Math.max(0,Math.min(scrollB,Math.max(0,total-rowsB)));
    for(int i=scrollB;i<Math.min(total,scrollB+rowsB);i++){ Bot b=BotManager.bots.get(i); String st=b.status; int col=st.equals("Online")?0xFF3BFF6A:(st.startsWith("Refused")||st.startsWith("Server is online")?0xFFFF5555:0xFFFFB03B);
      UI.rr(g,x0,y,x1-x0,13,3,b.selected?0x552F5BFF:0x24FFFFFF); g.fill(x0+4,y+3,x0+11,y+10,b.selected?0xFF3BFF6A:0xFF555566);
      g.drawTextWithShadow(textRenderer,b.name,x0+16,y+3,0xFFFFFFFF); g.drawTextWithShadow(textRenderer,textRenderer.trimToWidth(st,x1-x0-150),x0+112,y+3,col);
      hits.add(new H(9,x0,y,x1-x0-26,13,i)); btn(g,10,x1-22,y,20,13,"X",0xD41F26,i,mx,my); y+=14; }
    if(total==0) g.drawTextWithShadow(textRenderer,"§7No bots yet. Press \"Add alts\" or type  addn ABAB_ 5",px+12,py+74,0xFFFFFFFF);
    int ly=py+70+rowsB*14+4, ly2=py+ph-52; UI.rr(g,x0,ly,x1-x0,ly2-ly,4,0x66000000);
    int rows=Math.max(1,(ly2-ly-4)/10); List<String> ls=new ArrayList<>(BotManager.LOG); for(int i=Math.max(0,ls.size()-rows),r=0;i<ls.size();i++,r++) g.drawTextWithShadow(textRenderer,textRenderer.trimToWidth("§7"+ls.get(i),pw-24),px+12,ly+3+r*10,0xFFFFFFFF);
    input.render(g,mx,my,delta); if(input.getText().isEmpty()&&!input.isFocused()) g.drawTextWithShadow(textRenderer,"§7console: /tpa <player> · join <ip> · help",px+12,py+ph-42,0xFFFFFFFF);
    btn(g,1,px+pw-58,py+ph-47,50,18,"Send",0x2F9F4F,0,mx,my);
    int bw=(pw-16-4*3)/5; int bx=px+8, by=py+ph-24;
    btn(g,2,bx,by,bw,18,"Join sel.",0x2F5BFF,0,mx,my); btn(g,3,bx+(bw+3),by,bw,18,"Leave sel.",0xB8641A,0,mx,my); btn(g,4,bx+(bw+3)*2,by,bw,18,"Add alts",0x2F9F4F,0,mx,my);
    btn(g,11,bx+(bw+3)*3,by,bw,18,"Remove sel.",0xD41F26,0,mx,my); btn(g,5,bx+(bw+3)*4,by,bw,18,"Back",0x555566,0,mx,my);
    if(!msg.isEmpty()) g.drawTextWithShadow(textRenderer,textRenderer.trimToWidth(msg,pw-80),px+8,py+ph-60+0,0xFFFFFFFF);
  }
  void say(String s){ msg=s.replaceAll("§.",""); BotManager.log(s.replaceAll("§.","")); }
  void run(String line){ line=line.trim(); if(line.isEmpty()) return;
    if(line.startsWith("/")){ int n=BotManager.sendSelected(line); say(n==0?"No selected bot is online":"Sent to "+n+" bot(s)"); return; }
    if(line.startsWith("@")){ String[] t=line.substring(1).split("\\s+",2); if(t.length<2){ say("Usage: @name1,name2 /command"); return; } int n=BotManager.sendNames(t[0],t[1]); say(n==0?"None of those bots is online":"Sent to "+n+" bot(s)"); return; }
    if(line.startsWith("#")){ String[] t=line.substring(1).split("\\s+",2); try{ int n=BotManager.sendFirst(Integer.parseInt(t[0]),t[1]); say(n==0?"No bot is online":"Sent to the first "+n+" online bot(s)"); }catch(Exception e){ say("Usage: #5 /command"); } return; }
    String[] a=line.split("\\s+",2); String c=a[0].toLowerCase(), rest=a.length>1?a[1].trim():"";
    if(SHORT.contains(c)){ String cmd=c.equals("afk")?"/warp afk":"/"+line; int n=BotManager.sendSelected(cmd); say(n==0?"No selected bot is online":"Sent "+cmd+" to "+n+" bot(s)"); return; }
    switch(c){
      case "help" -> { say("/cmd = selected bots · @a,b /cmd · #5 /cmd · tpa/warp/home/login/register/afk work without /"); say("add <name> · addn <prefix> <n> · addalts · remove <name|selected|all> · clear"); say("select all|none|<n>|<name> · join <ip> · leave · list · gap <sec> · script <cmd; cmd> · reconnect on/off"); }
      case "add" -> say(BotManager.add(rest)?"Added "+rest:"Bad name (3-16 letters/digits/_) or already added");
      case "addn" -> { String[] t=rest.split("\\s+"); int cnt=0; try{ cnt=Integer.parseInt(t[t.length-1]); }catch(Exception e){} if(t.length<2||cnt<1){ say("Usage: addn <prefix> <count>  (e.g. addn ABAB_ 20)"); return; } say("Created "+BotManager.addMany(t[0],cnt)+" bot(s)"); }
      case "gap" -> { try{ BotManager.gapSeconds=Math.max(3,Integer.parseInt(rest)); say("One bot joins every "+BotManager.gapSeconds+"s"); }catch(Exception e){ say("gap <seconds> (min 3)"); } }
      case "addalts" -> { int n=0; AltScreen.load(); for(String s:AltScreen.ALTS) if(BotManager.add(s)) n++; say("Added "+n+" alt(s) as bots"); }
      case "remove" -> { if(rest.equalsIgnoreCase("selected")) say("Removed "+BotManager.removeSelected()+" bot(s)"); else if(rest.equalsIgnoreCase("all")){ BotManager.clear(); say("All bots removed"); } else { BotManager.remove(rest); say("Removed "+rest); } }
      case "clear" -> { BotManager.clear(); say("All bots removed"); }
      case "select" -> { if(rest.equalsIgnoreCase("all")) BotManager.selectAll(true); else if(rest.equalsIgnoreCase("none")) BotManager.selectAll(false); else { try{ BotManager.selectFirst(Integer.parseInt(rest)); }catch(Exception e){ Bot b=BotManager.find(rest); if(b!=null) b.selected=!b.selected; } } say(BotManager.selectedCount()+" selected"); }
      case "join" -> { String ip=rest.isEmpty()?BotManager.lastIp:rest; if(ip.isEmpty()){ say("join <ip>"); return; } if(BotManager.selectedCount()==0){ say("Select at least one bot"); return; } BotManager.joinAll(ip); say("Joining "+ip+" with "+BotManager.selectedCount()+" bot(s), one every "+BotManager.gapSeconds+"s"); }
      case "leave" -> { if(rest.isEmpty()) BotManager.leaveAll(); else { Bot b=BotManager.find(rest); if(b!=null) b.stopBot(); } say("Left"); }
      case "list" -> { for(Bot b:BotManager.bots) BotManager.log((b.selected?"[x] ":"[ ] ")+b.name+" - "+b.status); say(BotManager.bots.size()+" bot(s)"); }
      case "script" -> { if(rest.isEmpty()) say("script: "+(BotManager.script.isEmpty()?"(none)":BotManager.script)); else { BotManager.script=rest; BotManager.save(); say("After joining: "+rest); } }
      case "reconnect" -> { BotManager.reconnect=!rest.equalsIgnoreCase("off"); BotManager.save(); say("Reconnect "+(BotManager.reconnect?"ON":"OFF")); }
      default -> say("Unknown command. Type help");
    } }
  void act(H h){ switch(h.kind){
    case 1 -> { run(input.getText()); input.setText(""); }
    case 2 -> { String ip=input.getText().trim(); if(ip.isEmpty()) ip=BotManager.lastIp; if(ip.isEmpty()){ say("Type the server ip in the console, then press Join"); return; } if(BotManager.selectedCount()==0){ say("Select at least one bot"); return; } BotManager.joinAll(ip); input.setText(""); say("Joining "+ip); }
    case 3 -> { BotManager.leaveAll(); say("Selected bots left"); }
    case 4 -> run("addalts");
    case 5 -> client.setScreen(parent);
    case 6 -> { BotManager.selectAll(true); say("All selected"); }
    case 7 -> { BotManager.selectAll(false); say("None selected"); }
    case 8 -> { try{ BotManager.selectFirst(Integer.parseInt(countF.getText().trim())); say(BotManager.selectedCount()+" selected"); }catch(Exception e){ say("Type a number in the small box first"); } }
    case 9 -> { Bot b=BotManager.bots.get(h.idx); b.selected=!b.selected; }
    case 10 -> { Bot b=BotManager.bots.get(h.idx); BotManager.remove(b.name); say("Removed "+b.name); }
    case 11 -> say("Removed "+BotManager.removeSelected()+" bot(s)");
    default -> {} } }
  @Override public boolean mouseClicked(Click click,boolean doubled){ pressed=true; dragged=false; py0=click.y(); acc=0;
    boolean onField=(click.y()>=py+ph-48&&click.y()<py+ph-28&&click.x()<px+pw-60)||(click.y()>=py+48&&click.y()<py+68&&click.x()>=px+104&&click.x()<px+140);
    if(onField) return super.mouseClicked(click,doubled); return true; }
  @Override public boolean mouseDragged(Click click,double dx,double dy){ if(pressed&&Math.abs(click.y()-py0)>4) dragged=true;
    if(dragged&&click.y()<py+70+rowsB*14+4){ acc-=dy; while(acc>=14){ acc-=14; scrollB++; } while(acc<=-14){ acc+=14; scrollB--; } return true; } return super.mouseDragged(click,dx,dy); }
  @Override public boolean mouseReleased(Click click){ boolean wd=dragged; pressed=false; dragged=false; if(wd||click.button()!=0) return true;
    for(int i=hits.size()-1;i>=0;i--){ H h=hits.get(i); if(click.x()>=h.x&&click.x()<h.x+h.w&&click.y()>=h.y&&click.y()<h.y+h.h){ act(h); return true; } } return super.mouseReleased(click); }
  @Override public boolean mouseScrolled(double mx,double my,double hA,double vA){ scrollB=Math.max(0,scrollB-(int)Math.signum(vA)); return true; }
  @Override public boolean keyPressed(KeyInput input){ int k=input.key(); if(k==GLFW.GLFW_KEY_ENTER||k==GLFW.GLFW_KEY_KP_ENTER){ act(new H(1,0,0,0,0,0)); return true; } if(k==GLFW.GLFW_KEY_ESCAPE){ client.setScreen(parent); return true; } return super.keyPressed(input); }
}
