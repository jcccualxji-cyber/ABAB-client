package ru.abab.gui;
import java.lang.reflect.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.session.Session;
import net.minecraft.text.Text;
/** Alt manager: tab "Alts" (offline/cracked names, saved) and tab "Servers" (saved IPs, join with the current or selected alt). Offline names only work on offline-mode servers. */
public class AltScreen extends Screen {
  static final List<String> ALTS=new ArrayList<>(), SERVERS=new ArrayList<>(); static boolean loaded; static Session original; static String selected; static int tab=0; static boolean useSel=true;
  record H(int kind,int x,int y,int w,int h,int idx){}
  final Screen parent; final List<H> hits=new ArrayList<>(); TextFieldWidget input; int scroll; String msg=""; boolean pressed,dragged; double py0; float acc;
  int px,py,pw,ph,rows; static final int RH=20;
  public AltScreen(Screen p){ super(Text.literal("Alts")); parent=p; load(); }
  static Path file(String n){ return FabricLoader.getInstance().getConfigDir().resolve(n); }
  static void readInto(List<String> l,String n){ try{ Path f=file(n); if(Files.exists(f)) for(String s:Files.readAllLines(f)){ s=s.trim(); if(!s.isEmpty()&&!l.contains(s)) l.add(s); } }catch(Exception e){ e.printStackTrace(); } }
  static void load(){ if(loaded) return; loaded=true; readInto(ALTS,"abab-alts.txt"); readInto(SERVERS,"abab-servers.txt"); }
  static void save(){ try{ Files.write(file("abab-alts.txt"),ALTS); Files.write(file("abab-servers.txt"),SERVERS); }catch(Exception e){ e.printStackTrace(); } }
  public static String user(){ try{ return MinecraftClient.getInstance().getSession().getUsername(); }catch(Throwable t){ return "?"; } }
  /** a real Microsoft login carries a long access token; offline sessions do not */
  public static boolean premium(){ try{ String t=MinecraftClient.getInstance().getSession().getAccessToken(); return t!=null&&t.length()>20; }catch(Throwable t){ return false; } }
  static Session make(String name){
    for(Constructor<?> c:Session.class.getDeclaredConstructors()){ try{ c.setAccessible(true); Class<?>[] ps=c.getParameterTypes(); Object[] a=new Object[ps.length]; int strings=0; boolean okc=true;
      for(int i=0;i<ps.length&&okc;i++){ Class<?> t=ps[i];
        if(t==String.class) a[i]=(strings++==0)?name:"0";
        else if(t==UUID.class) a[i]=UUID.nameUUIDFromBytes(("OfflinePlayer:"+name).getBytes(StandardCharsets.UTF_8));
        else if(t==Optional.class) a[i]=Optional.empty();
        else if(t.isEnum()){ Object[] cs=t.getEnumConstants(); Object pick=cs[0]; for(Object o:cs) if(o.toString().toUpperCase().contains("LEGACY")) pick=o; a[i]=pick; }
        else if(t==boolean.class) a[i]=false; else okc=false; }
      if(okc) return (Session)c.newInstance(a); }catch(Throwable ignored){} }
    return null; }
  static boolean apply(Session s){ MinecraftClient mc=MinecraftClient.getInstance();
    for(Field f:MinecraftClient.class.getDeclaredFields()) if(f.getType()==Session.class){ try{ f.setAccessible(true); f.set(mc,s); return true; }catch(Throwable t){ t.printStackTrace(); } }
    return false; }
  boolean login(String name){ Session s=make(name); if(s==null){ msg="§cCould not build a session on this version"; return false; }
    if(original==null) original=MinecraftClient.getInstance().getSession(); if(!apply(s)){ msg="§cCould not switch the account"; return false; } msg="§aNow playing as §f"+name; return true; }
  static boolean valid(String n){ return n.matches("[A-Za-z0-9_]{3,16}"); }
  void join(String ip){ if(useSel&&selected!=null&&!selected.equals(user())&&!login(selected)) return;
    try{ ConnectScreen.connect(this,client,ServerAddress.parse(ip),new ServerInfo("ABAB",ip,ServerInfo.ServerType.OTHER),false,null); }catch(Throwable t){ msg="§cCould not join: "+t.getMessage(); } }
  @Override protected void init(){
    pw=Math.min(310,width-10); ph=Math.min(250,height-10); px=width/2-pw/2; py=height/2-ph/2; rows=Math.max(1,(ph-126)/RH);
    input=new TextFieldWidget(textRenderer,px+10,py+70,pw-128,16,Text.literal("input")); input.setMaxLength(60); addDrawableChild(input); setInitialFocus(input);
  }
  @Override public boolean shouldPause(){ return false; }
  @Override public void renderBackground(DrawContext g,int mx,int my,float d){ }
  void btn(DrawContext g,int kind,int x,int y,int w,int h,String t,int col,int idx,int mx,int my){ boolean hv=mx>=x&&mx<x+w&&my>=y&&my<y+h; UI.rr(g,x,y,w,h,4,hv?(col|0xFF000000):(0xAA000000|(col&0xFFFFFF))); g.drawCenteredTextWithShadow(textRenderer,t,x+w/2,y+(h-8)/2,0xFFFFFFFF); hits.add(new H(kind,x,y,w,h,idx)); }
  @Override public void render(DrawContext g,int mx,int my,float delta){
    hits.clear(); g.fillGradient(0,0,width,height,0x77000000,0xAA000010);
    UI.rr(g,px-1,py-1,pw+2,ph+2,9,0x40FFFFFF); UI.rr(g,px,py,pw,ph,8,0xB00B0B12); g.fill(px+10,py,px+pw/2,py+2,Hud.RED); g.fill(px+pw/2,py,px+pw-10,py+2,Hud.BLUE);
    g.getMatrices().pushMatrix(); g.getMatrices().translate((float)(px+12),(float)(py+9)); g.getMatrices().scale(1.5f,1.5f); g.drawTextWithShadow(textRenderer,"Alt Manager",0,0,0xFFFFFFFF); g.getMatrices().popMatrix();
    g.drawTextWithShadow(textRenderer,"Current: §f"+user()+"  "+(premium()?"§a[PREMIUM]":"§6[CRACKED / OFFLINE]"),px+12,py+27,0xFFB0B0BC);
    g.drawTextWithShadow(textRenderer,tab==0?"§fUse§7 = play as this alt · §f+Bot§7 = AFK bot · §fX§7 = delete · tap name = select":"§fJoin§7 = connect · §fAlt ON§7 = join as the alt selected in Alts · tap IP = copy it up",px+12,py+38,0xFFFFFFFF);
    btn(g,7,px+12,py+50,60,15,"Alts",tab==0?0xD41F26:0x444455,0,mx,my); btn(g,8,px+76,py+50,60,15,"Servers",tab==1?0xD41F26:0x444455,0,mx,my);
    input.render(g,mx,my,delta); if(input.getText().isEmpty()&&!input.isFocused()) g.drawTextWithShadow(textRenderer,tab==0?"§7new username":"§7server ip (ip:port)",px+14,py+74,0xFFFFFFFF);
    btn(g,1,px+pw-114,py+69,46,18,"Add",0x2F9F4F,0,mx,my); if(tab==0) btn(g,2,px+pw-64,py+69,54,18,"Random",0x2F5BFF,0,mx,my); else btn(g,10,px+pw-64,py+69,54,18,useSel?"Alt: ON":"Alt: OFF",useSel?0x2F9F4F:0x555566,0,mx,my);
    List<String> l=tab==0?ALTS:SERVERS; int y=py+94, x0=px+10, x1=px+pw-10;
    for(int i=scroll;i<Math.min(l.size(),scroll+rows);i++){ String n=l.get(i); boolean cur=tab==0&&n.equals(user()), sel=tab==0&&n.equals(selected);
      UI.rr(g,x0,y,x1-x0,RH-3,4,cur?0x66D41F26:(sel?0x552F5BFF:0x30FFFFFF)); g.drawTextWithShadow(textRenderer,textRenderer.trimToWidth(n,x1-x0-(tab==0?140:100)),x0+8,y+5,0xFFFFFFFF);
      hits.add(new H(tab==0?9:12,x0,y,x1-x0-(tab==0?130:90),RH-3,i));
      if(tab==0){ btn(g,3,x1-124,y+2,38,RH-7,"Use",0x2F9F4F,i,mx,my); btn(g,13,x1-82,y+2,42,RH-7,"+Bot",0x2F5BFF,i,mx,my); } else btn(g,11,x1-84,y+2,44,RH-7,"Join",0x2F9F4F,i,mx,my); btn(g,4,x1-36,y+2,34,RH-7,"X",0xD41F26,i,mx,my); y+=RH; }
    if(l.isEmpty()) g.drawCenteredTextWithShadow(textRenderer,tab==0?"§7No alts yet - type a name and press Add":"§7No servers yet - type an IP and press Add",px+pw/2,py+110,0xFFFFFFFF);
    if(tab==1) g.drawTextWithShadow(textRenderer,"§7Join uses "+(useSel&&selected!=null?"the alt you selected in the Alts tab ("+selected+")":"your current account"),px+12,py+ph-38,0xFFFFFFFF);
    if(!msg.isEmpty()) g.drawCenteredTextWithShadow(textRenderer,msg,px+pw/2,py+ph-50,0xFFFFFFFF);
    btn(g,14,px+pw-128,py+ph-24,54,18,"Bots",0x2F5BFF,0,mx,my); btn(g,5,px+10,py+ph-24,110,18,"Restore original",0x555566,0,mx,my); btn(g,6,px+pw-70,py+ph-24,60,18,"Back",0x555566,0,mx,my);
  }
  void act(H h){ List<String> l=tab==0?ALTS:SERVERS;
    switch(h.kind){
      case 1 -> { String n=input.getText().trim(); if(tab==0){ if(!valid(n)){ msg="§cName: 3-16 letters, digits or _"; return; } } else if(n.isEmpty()||n.contains(" ")){ msg="§cType a valid ip"; return; }
        if(!l.contains(n)){ l.add(n); save(); } input.setText(""); msg="§aSaved "+n; }
      case 2 -> { String n="ABAB_"+(1000+new Random().nextInt(9000)); ALTS.add(n); save(); msg="§aCreated "+n; }
      case 3 -> { selected=ALTS.get(h.idx); login(selected); }
      case 4 -> { l.remove(h.idx); save(); scroll=Math.max(0,Math.min(scroll,Math.max(0,l.size()-rows))); }
      case 5 -> { if(original==null) msg="§7Already on your original account"; else if(apply(original)){ original=null; msg="§aRestored your original account"; } else msg="§cCould not restore"; }
      case 6 -> client.setScreen(parent);
      case 7 -> { tab=0; scroll=0; input.setText(""); }
      case 8 -> { tab=1; scroll=0; input.setText(""); }
      case 9 -> { selected=ALTS.get(h.idx); msg="§7Selected §f"+selected; }
      case 10 -> useSel=!useSel;
      case 11 -> join(SERVERS.get(h.idx));
      case 12 -> input.setText(SERVERS.get(h.idx));
      case 13 -> msg=ru.abab.bots.BotManager.add(ALTS.get(h.idx))?"§aBot added: "+ALTS.get(h.idx)+" (open Bots)":"§cAlready a bot, or limit reached";
      case 14 -> client.setScreen(new BotScreen(this));
      default -> {}
    }
  }
  @Override public boolean mouseClicked(Click click,boolean doubled){ pressed=true; dragged=false; py0=click.y(); acc=0;
    if(click.y()>=py+68&&click.y()<py+88&&click.x()<px+pw-116) return super.mouseClicked(click,doubled); return true; }
  @Override public boolean mouseDragged(Click click,double dx,double dy){ if(pressed&&Math.abs(click.y()-py0)>4) dragged=true;
    if(dragged){ acc-=dy; int n=(tab==0?ALTS:SERVERS).size(); while(acc>=RH){ acc-=RH; scroll++; } while(acc<=-RH){ acc+=RH; scroll--; } scroll=Math.max(0,Math.min(scroll,Math.max(0,n-rows))); return true; }
    return super.mouseDragged(click,dx,dy); }
  @Override public boolean mouseReleased(Click click){ boolean wd=dragged; pressed=false; dragged=false; if(wd||click.button()!=0) return true;
    for(int i=hits.size()-1;i>=0;i--){ H h=hits.get(i); if(click.x()>=h.x&&click.x()<h.x+h.w&&click.y()>=h.y&&click.y()<h.y+h.h){ act(h); return true; } }
    return super.mouseReleased(click); }
  @Override public boolean mouseScrolled(double mx,double my,double hA,double vA){ int n=(tab==0?ALTS:SERVERS).size(); scroll=Math.max(0,Math.min(Math.max(0,n-rows),scroll-(int)Math.signum(vA))); return true; }
}
