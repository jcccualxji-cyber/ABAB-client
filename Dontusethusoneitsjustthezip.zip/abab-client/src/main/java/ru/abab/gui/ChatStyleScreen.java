package ru.abab.gui;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import ru.abab.mods.Pack8;
/** Edit the text ChatStyle puts before / after your messages, and preview the letter styles. */
public class ChatStyleScreen extends Screen {
  final Screen parent; TextFieldWidget pre, suf; int px,py,pw,ph; String msg="";
  public ChatStyleScreen(Screen p){ super(Text.literal("ChatStyle")); parent=p; }
  @Override protected void init(){ pw=Math.min(330,width-10); ph=Math.min(240,height-10); px=width/2-pw/2; py=height/2-ph/2;
    pre=new TextFieldWidget(textRenderer,px+12,py+50,pw-24,16,Text.literal("prefix")); pre.setMaxLength(80); pre.setText(Pack8.prefix); addDrawableChild(pre);
    suf=new TextFieldWidget(textRenderer,px+12,py+86,pw-24,16,Text.literal("suffix")); suf.setMaxLength(80); suf.setText(Pack8.suffix); addDrawableChild(suf); setInitialFocus(suf); }
  @Override public boolean shouldPause(){ return false; }
  @Override public void renderBackground(DrawContext g,int mx,int my,float d){ }
  void btn(DrawContext g,int x,int y,int w,String t,int col,int mx,int my){ boolean hv=mx>=x&&mx<x+w&&my>=y&&my<y+18; UI.rr(g,x,y,w,18,4,hv?(0xFF000000|col):(0xAA000000|col)); g.drawCenteredTextWithShadow(textRenderer,t,x+w/2,y+5,0xFFFFFFFF); }
  @Override public void render(DrawContext g,int mx,int my,float delta){
    g.fillGradient(0,0,width,height,0x77000000,0xAA000010);
    UI.rr(g,px-1,py-1,pw+2,ph+2,9,0x40FFFFFF); UI.rr(g,px,py,pw,ph,8,0xB00B0B12); g.fill(px+10,py,px+pw/2,py+2,Hud.RED); g.fill(px+pw/2,py,px+pw-10,py+2,Hud.BLUE);
    g.getMatrices().pushMatrix(); g.getMatrices().translate((float)(px+12),(float)(py+9)); g.getMatrices().scale(1.5f,1.5f); g.drawTextWithShadow(textRenderer,"Chat text",0,0,0xFFFFFFFF); g.getMatrices().popMatrix();
    g.drawTextWithShadow(textRenderer,"§7Your message becomes:  prefix + message + suffix   (turn each on in the module)",px+12,py+28,0xFFFFFFFF);
    g.drawTextWithShadow(textRenderer,"§fPrefix§7 (before the message)",px+12,py+40,0xFFFFFFFF); g.drawTextWithShadow(textRenderer,"§fSuffix§7 (after the message, e.g.  -ABAB CLIENT)",px+12,py+76,0xFFFFFFFF);
    pre.render(g,mx,my,delta); suf.render(g,mx,my,delta);
    g.drawTextWithShadow(textRenderer,"§7Letter styles (module setting Style 0-5):",px+12,py+110,0xFFFFFFFF);
    for(int i=0;i<Pack8.STYLES.length;i++) g.drawTextWithShadow(textRenderer,"§e"+i+" §7"+Pack8.STYLES[i]+": §f"+Pack8.restyle("hello abab client",i),px+12,py+122+i*11,0xFFFFFFFF);
    if(!msg.isEmpty()) g.drawTextWithShadow(textRenderer,msg,px+12,py+ph-38,0xFFFFFFFF);
    btn(g,px+12,py+ph-24,90,"Save",0x2F9F4F,mx,my); btn(g,px+pw-72,py+ph-24,60,"Back",0x555566,mx,my);
  }
  @Override public boolean mouseClicked(Click click,boolean doubled){ double mx=click.x(), my=click.y();
    if(my>=py+ph-24&&my<py+ph-6){ if(mx>=px+12&&mx<px+102){ Pack8.saveTexts(pre.getText(),suf.getText()); msg="§aSaved"; return true; } if(mx>=px+pw-72&&mx<px+pw-12){ Pack8.saveTexts(pre.getText(),suf.getText()); client.setScreen(parent); return true; } }
    return super.mouseClicked(click,doubled); }
  @Override public boolean keyPressed(KeyInput input){ if(input.key()==GLFW.GLFW_KEY_ESCAPE){ Pack8.saveTexts(pre.getText(),suf.getText()); client.setScreen(parent); return true; } return super.keyPressed(input); }
}
