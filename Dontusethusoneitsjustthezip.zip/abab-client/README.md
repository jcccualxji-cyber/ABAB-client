# АБАБ client (Fabric 1.21.11)

## Build in Termux
    pkg update && pkg upgrade -y
    pkg install openjdk-21 gradle unzip -y     # gradle must be >= 8.14 (check: gradle -v)
    termux-setup-storage                        # allow storage popup
    cd ~ && unzip ~/storage/downloads/abab-client.zip && cd abab-client
    gradle build --no-daemon
    cp build/libs/abab-1.0.0.jar ~/storage/downloads/

Put the jar + Fabric API 0.141.3+1.21.11 in the mods folder (Fabric Loader 0.18.1+).
First build downloads ~1 GB and needs ~3 GB free RAM. If the phone can't, build on a PC with the same `gradle build`.

## Use
Right Shift = GUI (or type `.gui`). Chat commands use prefix `.`; /vclip /hclip also work with slash.
`.help` lists everything. Examples: `.bind KillAura r` `.set ESP FillAlpha 100` `.block add emerald_ore` `/vclip 50`

## New
- `.set Flight Speed 100` / `.set HighJump Blocks 200` (no cap). In the GUI, Shift = x10, Ctrl = x100 per click.
- KBDelay: your hit is held back N seconds then lands. MazeKill: mace smash via fall-distance packets (hold a mace).
- SpearKill: hold LMB aiming at a target. ChunkFly/ChunkWalk: move in unloaded chunks (uses a Mixin).
- SusChunk: red chunks = likely bases. `.sus` lists the top chunks with coordinates.

## Batch 2 (57 modules)
Offhand mode: `.set Offhand Mode 0..3` (0 totem, 1 gap, 2 crystal, 3 shield).
Waypoints: `.wp add base` / `.wp add base 100 64 -300` / `.wp list` / `.wp del base`.
Instant-action modules (ClickTP, Burrow): bind a key; each press fires once.
Accessor mixins (FastUse, SpeedMine, NoJumpDelay) are in src/main/java/ru/abab/mixin.

## Port notes (1.21.4 -> 1.21.11)
- Build: Yarn 1.21.11+build.4, Loom `net.fabricmc.fabric-loom-remap` 1.14-SNAPSHOT, Loader 0.18.1, Fabric API 0.141.3+1.21.11.
- If Gradle complains it is too old: `gradle wrapper --gradle-version 8.14.3` then use `./gradlew build --no-daemon` instead.
- ESP / Tracers / BlockESP / SusChunk / Trajectories etc. no longer use the removed GL pipeline. They are projected
  to the screen and drawn as a 2D overlay (always visible through walls). Boxes are wireframe + optional fill.
  The projection uses the player's view and the FOV option, so it is approximate in 3rd person and with FOV effects.
- Key names / bind parsing no longer use InputUtil (its API changed): use letters, digits, f1-f12, space, tab,
  rshift/lshift, rctrl/lctrl, ralt/lalt, up/down/left/right, insert, delete, home, end.
- ChunkFly/ChunkWalk mixin target (`World.isPosLoaded(II)`) may not exist in 1.21.11. It is `require=0`, so it will just
  not activate. Check logs/latest.log if so.

## Batch 3 (this update)
- **Freecam** (Render): camera detaches, WASD/Space/LShift move it, your body stays put and sends no movement packets. Uses CameraMixin + ClientPlayerMixin.
- **Fly** (Movement): vanilla-sized speed + AntiKick. `Flight` is untouched. Nothing is guaranteed undetectable by Grim.
- **ALL HACKS OFF button** (top-left of the GUI), key **END**, or `.panic`: turns every module off, press again to restore the same set.
- **Search bar** in the GUI: just type; Backspace deletes, Esc clears.
- **BlockESP**: expand it in the GUI -> "Choose blocks..." opens a picker (search, click to add/remove, "Add all ores"). `.block ores` also works.
- **ESP**: Mode 0 = 3D, 1 = 2D box, 2 = corners; health bar; labels centered on the box. **Tracers**: nearest MaxCount only, FromBottom, fade by distance, point to targets behind you.
- **StorageESP**: per-type toggles, double chests merged into one box, MaxDist, 2D mode.
- **HUD**: new watermark (FPS/ping/modules), **ArmorHUD** (durability bars + %), PotionHUD, CPS, Speedometer. HUD has `FovFix` (if ESP looks slightly off while sprinting, change it).
- **Main menu**: ABAB CLIENT title screen (Singleplayer / Multiplayer / Options / Quit).
- **Limits**: Reach max 6, Flight 10, Speed 3, Step 10, HighJump 300, MazeKill 500, SpearKill speed 10, etc.
- **MazeKill**: IgnoreCooldown (default on), Range, works in the air. **SpearKill**: hold LMB on a target; releasing stops it (ReturnOnRelease), anti-stuck.

## Batch 4
- New menu (sidebar | module cards | settings + keybind). Tap a card to select, tap the switch to toggle. Drag to scroll. Search box accepts the touch keyboard.
- Keybinds: select a module -> "Keybind" -> press a key (Backspace clears). "Hold to enable" = active only while the key is held.
- SpearKill: Mode 0 teleport strikes (default), Mode 1 fly back and forth. Hold left click (or HoldClick off = full auto). Continuous.
- XRay (highlight through walls, pick blocks in menu), AimAssist, AutoWeb, HoleFiller, AutoMace, WindChargeKey, Velocity, NoSlow, AutoMine, AutoFarm, BonemealAura, AntiBlind, Blink, LightOverlay, BarrierESP, SpawnerESP, TrialSpawnerESP, BedESP, PearlESP, TridentESP, WardenESP, CrystalESP, ItemESP.
- Fixes: HighJump/LongJump (vanilla jump overwrote the boost), Flight AntiKick, BlockPicker/Search work with touch keyboard.

## Batch 5
- Delay selector (ticks) + WaitCooldown for KillAura and Trigger; AutoCrystal has BreakDelay / PlaceDelay.
- New PvP: TPAura, MaceAura, FakeLag, AutoObsidian, FastCrystal, AnchorAura, TargetStrafe, AntiKnockback (drops the server's knockback packet via NetMixin).
- NoClip, Chams (silhouettes), PopChams (ghost + chat message on totem pop).
- StorageESP: whole view distance, outline only. SusChunk: CenterColor / EdgeColor / CenterSize. Flight max 100.
- Modules on/off + settings are saved and restored when you start the game (not Freecam/Blink/NoClip).
- Menu: rounded corners, account badge (PREMIUM / CRACKED), Alts entry. Alt manager also from the Multiplayer screen ("Alts" button, top-left).
- If the game does not start after AntiKnockback was added: remove "NetMixin" from src/main/resources/abab.mixins.json and rebuild.

## Batch 6
- NoClip is now a real noclip (collisions off via ClientPlayerMixin); new Phase. Servers can still pull you back (vanilla checks it); NoClip has HoldPackets.
- "Open modules" (sidebar) = classic windows with [-]/[+] per category. Profiles (sidebar) = save/load which hacks are ON ("Clean" = nothing).
- CrystalPvP (obsidian base + crystals + breaking, 3 delays). New SusChunk. Spam (.spam add/list/clear). InventoryMove, YawLock, FastFall, HoleSnap, AutoPanic.
- Crosshair module (Style 5 = draw your own). HudMixin hides the vanilla one while ON; remove "HudMixin" from abab.mixins.json if the game does not start.
- ESP (3D boxes + tracers to the feet) and StorageESP (filled boxes + tracers, colors per type) restyled.
- Alt Manager has two tabs: Alts and Servers (saved IPs; Join with the selected alt). Main menu restyled ("liquid").

## Batch 7: bots (AFK warp)
- Alt Manager -> "+Bot" on an alt (or Bots button, or `.bots`) opens the bot console. Offline-mode servers only.
- Console: `/tpa <player>` (all bots) | `@name /cmd` | add/remove/addalts/clear | join <ip> | leave | list | script <cmd; cmd> (runs after joining, e.g. /login pass; /warp afk) | reconnect on/off.
- Bots stay connected, answer keep-alives and run only the commands you send. Max 10, one joins every 6 s, 1.5 s between commands per bot, no chat, no movement.
- Protocol ids are for 1.21.11 (774). The play keep-alive ids are calibrated automatically: if a bot is timed out after ~30 s it tries the next id pair on reconnect (see config/abab-bots.properties "cal").
- Bots: no limit. `addn <prefix> <count>` makes many at once (e.g. `addn ABAB_ 20`), `gap <sec>` sets the seconds between joins (min 3, default 6).

## Batch 8/9
- FIX: BlockESP / XRay used java.awt (not on Android) and crashed -> disabled themselves. Now fixed; tracers default ON. Big boxes you stand inside now draw (near-plane clipping).
- SusChunk v3: block entities + unnatural blocks per dimension + farms (bamboo/kelp/pickles/cane...) + OLD/NEW chunk age + minimap + whitelist + OnlySusChunks pre-filter in StorageESP/BlockESP/XRay/HoleESP/finders.
- Bots: tap to select, X to remove, commands go to selected bots (@a,b /cmd, #5 /cmd), shortcuts tpa/warp/home/login/register/afk; reason for disconnect is shown.
- SpearAura, BackCTP, TPToPlayer, HitSound (+ mute vanilla), ChatStyle, CrystalPvP scaffold item + PerTick, AnchorAura AirPlace + PerTick, AutoCrystal PerTick, KillAura AutoSwitchWeapon + HitMode (crit/sweep/auto), TPAura HitMode.
- SpearKill: Mode 2 Chase (runners / air), Predict. Spam: delay per message. Phase: AntiSetback (experimental).
- If the game does not start: remove "SoundMixin", "HudMixin" or "NetMixin" from abab.mixins.json.

## Shareable configs
- Menu -> Profiles (Configs): Save stores the ON modules with their settings and keybinds. "Copy" gives a one-line code (starts with ABAB1:). A friend pastes it with "Import (paste code)" and gets a new profile with the same modules and settings turned on.
