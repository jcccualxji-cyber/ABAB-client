# АБАБ client (Fabric 1.21.11)

## Build in Termux
    pkg update && pkg upgrade -y
    pkg install openjdk-21 gradle unzip -y     # gradle must be >= 8.14 (check: gradle -v)
    termux-setup-storage                        # allow storage popup
    cd ~ && unzip ~/storage/downloads/abab-client.zip && cd abab-client
    gradle build --no-daemon
    cp build/libs/abab-1.0.0.jar ~/storage/downloads/

Put the jar + Fabric API 0.141.3+1.21.11 in the mods folder (Fabric Loader 0.18.1+).
First build downloads ~1 GB and needs ~3 GB free RAM. If the phone can't, build on a PC with the same `gradle build`.

## Use
Right Shift = GUI (or type `.gui`). Chat commands use prefix `.`; /vclip /hclip also work with slash.
`.help` lists everything. Examples: `.bind KillAura r` `.set ESP FillAlpha 100` `.block add emerald_ore` `/vclip 50`

## New
- `.set Flight Speed 100` / `.set HighJump Blocks 200` (no cap). In the GUI, Shift = x10, Ctrl = x100 per click.
- KBDelay: your hit is held back N seconds then lands. MazeKill: mace smash via fall-distance packets (hold a mace).
- SpearKill: hold LMB aiming at a target. ChunkFly/ChunkWalk: move in unloaded chunks (uses a Mixin).
- SusChunk: red chunks = likely bases. `.sus` lists the top chunks with coordinates.

## Batch 2 (57 modules)
Offhand mode: `.set Offhand Mode 0..3` (0 totem, 1 gap, 2 crystal, 3 shield).
Waypoints: `.wp add base` / `.wp add base 100 64 -300` / `.wp list` / `.wp del base`.
Instant-action modules (ClickTP, Burrow): bind a key; each press fires once.
Accessor mixins (FastUse, SpeedMine, NoJumpDelay) are in src/main/java/ru/abab/mixin.

## Port notes (1.21.4 -> 1.21.11)
- Build: Yarn 1.21.11+build.4, Loom `net.fabricmc.fabric-loom-remap` 1.14-SNAPSHOT, Loader 0.18.1, Fabric API 0.141.3+1.21.11.
- If Gradle complains it is too old: `gradle wrapper --gradle-version 8.14.3` then use `./gradlew build --no-daemon` instead.
- ESP / Tracers / BlockESP / SusChunk / Trajectories etc. no longer use the removed GL pipeline. They are projected
  to the screen and drawn as a 2D overlay (always visible through walls). Boxes are wireframe + optional fill.
  The projection uses the player's view and the FOV option, so it is approximate in 3rd person and with FOV effects.
- Key names / bind parsing no longer use InputUtil (its API changed): use letters, digits, f1-f12, space, tab,
  rshift/lshift, rctrl/lctrl, ralt/lalt, up/down/left/right, insert, delete, home, end.
- ChunkFly/ChunkWalk mixin target (`World.isPosLoaded(II)`) may not exist in 1.21.11. It is `require=0`, so it will just
  not activate. Check logs/latest.log if so.

## Batch 3 (this update)
- **Freecam** (Render): camera detaches, WASD/Space/LShift move it, your body stays put and sends no movement packets. Uses CameraMixin + ClientPlayerMixin.
- **Fly** (Movement): vanilla-sized speed + AntiKick. `Flight` is untouched. Nothing is guaranteed undetectable by Grim.
- **ALL HACKS OFF button** (top-left of the GUI), key **END**, or `.panic`: turns every module off, press again to restore the same set.
- **Search bar** in the GUI: just type; Backspace deletes, Esc clears.
- **BlockESP**: expand it in the GUI -> "Choose blocks..." opens a picker (search, click to add/remove, "Add all ores"). `.block ores` also works.
- **ESP**: Mode 0 = 3D, 1 = 2D box, 2 = corners; health bar; labels centered on the box. **Tracers**: nearest MaxCount only, FromBottom, fade by distance, point to targets behind you.
- **StorageESP**: per-type toggles, double chests merged into one box, MaxDist, 2D mode.
- **HUD**: new watermark (FPS/ping/modules), **ArmorHUD** (durability bars + %), PotionHUD, CPS, Speedometer. HUD has `FovFix` (if ESP looks slightly off while sprinting, change it).
- **Main menu**: ABAB CLIENT title screen (Singleplayer / Multiplayer / Options / Quit).
- **Limits**: Reach max 6, Flight 10, Speed 3, Step 10, HighJump 300, MazeKill 500, SpearKill speed 10, etc.
- **MazeKill**: IgnoreCooldown (default on), Range, works in the air. **SpearKill**: hold LMB on a target; releasing stops it (ReturnOnRelease), anti-stuck.
