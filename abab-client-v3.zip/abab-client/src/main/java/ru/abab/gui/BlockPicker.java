package ru.abab.gui;
import java.util.*;
import net.minecraft.block.*;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.item.*;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import ru.abab.core.*;
import ru.abab.mods.Mods;
/** Pick which blocks BlockESP highlights: type to search, click a block to add/remove it, mouse wheel to scroll. */
public class BlockPicker extends Screen {
  static List<Block> ALL;
  final Screen parent; String q=""; int scroll; List<Block> list=new ArrayList<>();
  int px,py,pw,ph,rows; static final int RH=16;
  public BlockPicker(Screen p){ super(Text.literal("Blocks")); parent=p; }
  @Override protected void init(){
    if(ALL==null){ ALL=new ArrayList<>(); for(Block b:Registries.BLOCK) if(b!=Blocks.AIR) ALL.add(b); ALL.sort(Comparator.comparing(b->Registries.BLOCK.getId(b).getPath())); }
    pw=Math.min(280,width-10); ph=height-20; px=width/2-pw/2; py=10; rows=Math.max(1,(ph-72)/RH); refilter();
  }
  static String id(Block b){ return Registries.BLOCK.getId(b).getPath(); }
  void refilter(){ list.clear(); for(Block b:ALL) if(q.isEmpty()||id(b).contains(q)) list.add(b);
    if(q.isEmpty()) list.sort(Comparator.comparing((Block b)->!Mods.blockEspHas(b)).thenComparing(BlockPicker::id)); // selected blocks first
    scroll=Math.max(0,Math.min(scroll,Math.max(0,list.size()-rows))); }
  @Override public boolean shouldPause(){ return false; }
  @Override public void renderBackground(DrawContext g,int mx,int my,float d){ }
  @Override public void render(DrawContext g,int mx,int my,float delta){
    g.fillGradient(0,0,width,height,0xEE000000,0xF2090912);
    g.fill(px,py,px+pw,py+ph,0xEE0B0B10); g.fill(px,py,px+pw,py+2,Hud.RED);
    g.drawTextWithShadow(textRenderer,"§cBlockESP §f- choose blocks §7("+Mods.blockEspNames().size()+" selected, "+list.size()+" shown)",px+6,py+7,0xFFFFFFFF);
    g.fill(px+6,py+20,px+pw-6,py+34,0xFF14141B);
    g.drawTextWithShadow(textRenderer,q.isEmpty()?"§7type to search (e.g. diamond, ore, chest)":"§f"+q+((System.currentTimeMillis()/500)%2==0?"§c_":""),px+10,py+23,0xFFFFFFFF);
    int y=py+38;
    for(int i=scroll;i<Math.min(list.size(),scroll+rows);i++){ Block b=list.get(i); boolean sel=Mods.blockEspHas(b); boolean hv=mx>=px+6&&mx<px+pw-6&&my>=y&&my<y+RH;
      g.fill(px+6,y,px+pw-6,y+RH-1,sel?0xCC8F1A20:(hv?0xDD1C1C24:0xAA14141B));
      Item it=b.asItem(); if(it!=Items.AIR) g.drawItem(new ItemStack(it),px+9,y); g.drawTextWithShadow(textRenderer,id(b),px+28,y+4,sel?0xFFFFFFFF:0xFFB5B5BD);
      if(sel) g.drawTextWithShadow(textRenderer,"ON",px+pw-24,y+4,0xFF3BFF6A); y+=RH; }
    int by=py+ph-26; btn(g,px+6,by,80,"Add all ores",mx,my); btn(g,px+92,by,80,"Clear all",mx,my); btn(g,px+pw-86,by,80,"Done",mx,my);
  }
  void btn(DrawContext g,int x,int y,int w,String t,int mx,int my){ boolean hv=mx>=x&&mx<x+w&&my>=y&&my<y+18; g.fill(x,y,x+w,y+18,hv?0xFFD41F26:0xFF3A1014); g.drawCenteredTextWithShadow(textRenderer,t,x+w/2,y+5,0xFFFFFFFF); }
  @Override public boolean mouseClicked(Click click,boolean doubled){ double mx=click.x(), my=click.y(); if(click.button()!=0) return super.mouseClicked(click,doubled);
    int by=py+ph-26;
    if(my>=by&&my<by+18){
      if(mx>=px+6&&mx<px+86){ Mods.blockEspAddOres(); Config.save(); refilter(); return true; }
      if(mx>=px+92&&mx<px+172){ Mods.blockEspClear(); Config.save(); refilter(); return true; }
      if(mx>=px+pw-86&&mx<px+pw-6){ client.setScreen(parent); return true; } }
    int y=py+38;
    for(int i=scroll;i<Math.min(list.size(),scroll+rows);i++){ if(mx>=px+6&&mx<px+pw-6&&my>=y&&my<y+RH){ Mods.blockEspToggle(list.get(i)); Config.save(); return true; } y+=RH; }
    return super.mouseClicked(click,doubled);
  }
  @Override public boolean mouseScrolled(double mx,double my,double hAmount,double vAmount){ scroll=Math.max(0,Math.min(Math.max(0,list.size()-rows),scroll-(int)Math.signum(vAmount)*3)); return true; }
  @Override public boolean keyPressed(KeyInput input){ int key=input.key();
    if(key==GLFW.GLFW_KEY_ESCAPE){ client.setScreen(parent); return true; }
    if(key==GLFW.GLFW_KEY_BACKSPACE){ if(!q.isEmpty()){ q=q.substring(0,q.length()-1); scroll=0; refilter(); } return true; }
    char c=0; if(key>=GLFW.GLFW_KEY_A&&key<=GLFW.GLFW_KEY_Z) c=(char)('a'+(key-GLFW.GLFW_KEY_A)); else if(key>=GLFW.GLFW_KEY_0&&key<=GLFW.GLFW_KEY_9) c=(char)('0'+(key-GLFW.GLFW_KEY_0));
    else if(key==GLFW.GLFW_KEY_SPACE||key==GLFW.GLFW_KEY_MINUS) c='_';
    if(c!=0&&q.length()<30){ q+=c; scroll=0; refilter(); return true; }
    return super.keyPressed(input);
  }
  @Override public void removed(){ Config.save(); }
}
