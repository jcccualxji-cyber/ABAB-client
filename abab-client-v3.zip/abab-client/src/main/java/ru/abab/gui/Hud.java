package ru.abab.gui;
import ru.abab.core.Module;
import java.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import ru.abab.core.*;
import ru.abab.mods.Mods;
public final class Hud {
  static final MinecraftClient mc=MinecraftClient.getInstance();
  public static final int RED=0xFFD41F26, BLUE=0xFF2F5BFF;
  public static void render(DrawContext g,float td){
    if(mc.player==null||mc.options.hudHidden) return;
    for(Module m:ModuleManager.all) if(m.on) m.onHud(g,td);
    Mods.HudMod h=Mods.HUD; if(!h.on) return;
    int w=mc.getWindow().getScaledWidth(), H=mc.getWindow().getScaledHeight();
    if(h.watermark.b){
      var le=mc.getNetworkHandler()!=null?mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()):null; int ping=le!=null?le.getLatency():0;
      String info="§7FPS §f"+mc.getCurrentFps()+"   §7PING §f"+ping+"ms   §7MODS §f"+ModuleManager.enabledCount();
      int tw=(int)(mc.textRenderer.getWidth("ABAB CLIENT")*1.6f), bw=Math.max(tw,mc.textRenderer.getWidth(info))+16;
      g.fill(4,4,4+bw,36,0xB0000000);
      g.fill(4,4,4+bw/2,6,RED); g.fill(4+bw/2,4,4+bw,6,BLUE);       // red -> blue top line
      g.fill(4,6,6,36,RED); g.fill(4,34,4+bw,36,0x55FFFFFF);
      g.getMatrices().pushMatrix(); g.getMatrices().translate((float)(11),(float)(10)); g.getMatrices().scale(1.6f,1.6f);
      g.drawTextWithShadow(mc.textRenderer,"ABAB",0,0,RED); g.drawTextWithShadow(mc.textRenderer," CLIENT",mc.textRenderer.getWidth("ABAB"),0,0xFFFFFFFF); g.getMatrices().popMatrix();
      g.drawTextWithShadow(mc.textRenderer,info,11,26,0xFFFFFFFF);
    }
    if(h.list.b){
      List<Module> on=new ArrayList<>(); for(Module m:ModuleManager.all) if(m.on) on.add(m);
      on.sort((a,b)->mc.textRenderer.getWidth(b.name)-mc.textRenderer.getWidth(a.name));
      String t="Hacks turned on: "+on.size(); int y=4;
      g.drawTextWithShadow(mc.textRenderer,t,w-mc.textRenderer.getWidth(t)-4,y,0xFFFFFFFF); y+=11;
      for(Module m:on){ int tw=mc.textRenderer.getWidth(m.name); g.fill(w-tw-8,y-1,w-2,y+10,0x88000000); g.fill(w-2,y-1,w,y+10,RED); g.drawTextWithShadow(mc.textRenderer,m.name,w-tw-5,y,0xFFFFFFFF); y+=11; }
    }
    if(h.keys.b){
      float s=(float)h.scale.d; int x=(int)(w*h.x.d/100.0), y=(int)(H*h.y.d/100.0);
      g.getMatrices().pushMatrix(); g.getMatrices().translate((float)(x),(float)(y)); g.getMatrices().scale(s,s);
      key(g,22,0,20,20,"W",mc.options.forwardKey.isPressed()); key(g,0,22,20,20,"A",mc.options.leftKey.isPressed());
      key(g,22,22,20,20,"S",mc.options.backKey.isPressed()); key(g,44,22,20,20,"D",mc.options.rightKey.isPressed());
      key(g,0,44,64,12,"━",mc.options.jumpKey.isPressed());
      key(g,0,58,31,14,"LMB",mc.options.attackKey.isPressed()); key(g,33,58,31,14,"RMB",mc.options.useKey.isPressed());
      g.getMatrices().popMatrix();
    }
  }
  static void key(DrawContext g,int x,int y,int w,int h,String t,boolean d){
    g.fill(x,y,x+w,y+h,d?0xDDD41F26:0xAA000000); g.fill(x,y+h-1,x+w,y+h,d?0xFFFFFFFF:0xFF2B2B33);
    g.drawCenteredTextWithShadow(mc.textRenderer,t,x+w/2,y+(h-8)/2,0xFFFFFFFF);
  }
}
