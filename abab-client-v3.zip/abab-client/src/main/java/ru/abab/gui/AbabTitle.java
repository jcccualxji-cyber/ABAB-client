package ru.abab.gui;
import java.util.*;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;
import ru.abab.core.ModuleManager;
/** ABAB CLIENT main menu (replaces the vanilla title screen). */
public class AbabTitle extends Screen {
  public static boolean enabled=true;
  record Btn(String t,Runnable r){}
  final List<Btn> btns=new ArrayList<>(); final float[][] fl=new float[90][5]; final Random rnd=new Random(); long last=System.nanoTime(); float time;
  static final int BW=210, BH=22, GAP=6;
  public AbabTitle(){ super(Text.literal("ABAB CLIENT")); }
  @Override protected void init(){
    btns.clear();
    btns.add(new Btn("Singleplayer",()->client.setScreen(new SelectWorldScreen(this))));
    btns.add(new Btn("Multiplayer",()->client.setScreen(new MultiplayerScreen(this))));
    btns.add(new Btn("Options",()->client.setScreen(new OptionsScreen(this,client.options))));
    btns.add(new Btn("Quit Game",()->client.scheduleStop()));
    for(float[] f:fl){ f[0]=rnd.nextFloat()*width; f[1]=rnd.nextFloat()*height; f[2]=1f+rnd.nextFloat()*2.2f; f[3]=8+rnd.nextFloat()*26; f[4]=rnd.nextFloat()*6.28f; }
  }
  @Override public boolean shouldCloseOnEsc(){ return false; }
  @Override public void renderBackground(DrawContext g,int mx,int my,float d){ }
  int top(){ return height/2-10; }
  @Override public void render(DrawContext g,int mx,int my,float delta){
    long n=System.nanoTime(); float dt=Math.min(0.1f,(n-last)/1e9f); last=n; time+=dt;
    g.fillGradient(0,0,width,height,0xFF05050B,0xFF160A12);
    // soft red / blue glows
    ClickGui.disc(g,width*0.15f,height*0.85f,70,0xD41F26,10); ClickGui.disc(g,width*0.15f,height*0.85f,40,0xD41F26,14);
    ClickGui.disc(g,width*0.85f,height*0.2f,70,0x2F5BFF,10); ClickGui.disc(g,width*0.85f,height*0.2f,40,0x2F5BFF,14);
    for(float[] f:fl){ f[1]+=f[3]*dt; f[4]+=dt; f[0]+=Math.sin(f[4])*5*dt; if(f[1]>height+8){ f[1]=-8; f[0]=rnd.nextFloat()*width; }
      ClickGui.disc(g,f[0],f[1],f[2]+3,0xFFFFFF,10); ClickGui.disc(g,f[0],f[1],f[2],0xFFFFFF,150); }
    // title
    g.getMatrices().pushMatrix(); g.getMatrices().translate((float)(width/2f),(float)(height/2f-88)); g.getMatrices().scale(5f,5f);
    g.drawCenteredTextWithShadow(textRenderer,"ABAB",0,0,Hud.RED); g.getMatrices().popMatrix();
    g.getMatrices().pushMatrix(); g.getMatrices().translate((float)(width/2f),(float)(height/2f-45)); g.getMatrices().scale(2f,2f);
    g.drawCenteredTextWithShadow(textRenderer,"C L I E N T",0,0,0xFFFFFFFF); g.getMatrices().popMatrix();
    int lw=(int)(60+10*Math.sin(time*2)); g.fill(width/2-lw,height/2-26,width/2,height/2-24,Hud.RED); g.fill(width/2,height/2-26,width/2+lw,height/2-24,Hud.BLUE);
    // buttons
    int x=width/2-BW/2, y=top();
    for(Btn b:btns){ boolean hv=mx>=x&&mx<x+BW&&my>=y&&my<y+BH;
      g.fill(x-1,y-1,x+BW+1,y+BH+1,hv?0xFFFFFFFF:0xFF2B2B33); g.fill(x,y,x+BW,y+BH,hv?0xEED41F26:0xEE0B0B10);
      g.fill(x,y,x+3,y+BH,Hud.BLUE); g.drawCenteredTextWithShadow(textRenderer,b.t,x+BW/2,y+7,0xFFFFFFFF); y+=BH+GAP; }
    g.drawTextWithShadow(textRenderer,"§7ABAB Client | Minecraft 1.21.11 | Fabric",6,height-12,0xFFFFFFFF);
    String r="§7"+ModuleManager.all.size()+" modules"; g.drawTextWithShadow(textRenderer,r,width-textRenderer.getWidth(r)-6,height-12,0xFFFFFFFF);
  }
  @Override public boolean mouseClicked(Click click,boolean doubled){
    if(click.button()==0){ double mx=click.x(), my=click.y(); int x=width/2-BW/2, y=top();
      for(Btn b:btns){ if(mx>=x&&mx<x+BW&&my>=y&&my<y+BH){ b.r.run(); return true; } y+=BH+GAP; } }
    return super.mouseClicked(click,doubled);
  }
}
