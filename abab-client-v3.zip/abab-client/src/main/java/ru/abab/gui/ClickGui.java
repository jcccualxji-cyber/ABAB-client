package ru.abab.gui;
import ru.abab.core.Module;
import java.util.*;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import ru.abab.core.*;
import ru.abab.mods.Mods;
public class ClickGui extends Screen {
  record Hit(int x,int y,int w,int h,Module m,Setting s,int panel,boolean pick){ boolean in(double a,double b){ return a>=x&&a<x+w&&b>=y&&b<y+h; } }
  static final int W=104;
  static int[] px=new int[Category.values().length], py=new int[Category.values().length];
  static boolean placed; static String query="";
  final List<Hit> hits=new ArrayList<>(); int drag=-1; int dox,doy; Module binding;
  final float[][] fl=new float[80][5]; long last=System.nanoTime(); final Random rnd=new Random();
  public ClickGui(){ super(Text.literal("АБАБ")); }
  @Override protected void init(){
    if(!placed){ int cols=Math.max(1,(width-10)/(W+6)); for(int i=0;i<px.length;i++){ px[i]=8+(i%cols)*(W+6); py[i]=58+(i/cols)*150; } placed=true; }
    for(float[] f:fl){ f[0]=rnd.nextFloat()*width; f[1]=rnd.nextFloat()*height; f[2]=1.2f+rnd.nextFloat()*2.4f; f[3]=10+rnd.nextFloat()*22; f[4]=rnd.nextFloat()*6.28f; }
  }
  @Override public boolean shouldPause(){ return false; }
  @Override public void renderBackground(DrawContext g,int mx,int my,float d){ /* no vanilla blur, we draw our own */ }
  static void disc(DrawContext g,float cx,float cy,float r,int rgb,int a){
    int R=(int)Math.ceil(r); for(int dy=-R;dy<=R;dy++){ double q=r*r-dy*dy; if(q<0) continue; int dx=(int)Math.sqrt(q); g.fill((int)cx-dx,(int)cy+dy,(int)cx+dx+1,(int)cy+dy+1,(a<<24)|rgb); }
  }
  boolean match(Module m){ return query.isEmpty()||m.name.toLowerCase().contains(query); }
  @Override public void render(DrawContext g,int mx,int my,float delta){
    long n=System.nanoTime(); float dt=Math.min(0.1f,(n-last)/1e9f); last=n;
    g.fillGradient(0,0,width,height,0xEE000000,0xF2090912);
    for(float[] f:fl){ f[1]+=f[3]*dt; f[4]+=dt; f[0]+=Math.sin(f[4])*6*dt; if(f[1]>height+8){ f[1]=-8; f[0]=rnd.nextFloat()*width; }
      disc(g,f[0],f[1],f[2]+4,0xFFFFFF,10); disc(g,f[0],f[1],f[2]+2,0xFFFFFF,26); disc(g,f[0],f[1],f[2],0xFFFFFF,170); }
    g.getMatrices().pushMatrix(); g.getMatrices().translate((float)(width/2f),(float)(6)); g.getMatrices().scale(2.5f,2.5f);
    g.drawCenteredTextWithShadow(textRenderer,"АБАБ",0,0,Hud.RED); g.getMatrices().popMatrix();
    g.fill(width/2-30,30,width/2-10,32,0xFFFFFFFF); g.fill(width/2-10,30,width/2+10,32,Hud.BLUE); g.fill(width/2+10,30,width/2+30,32,Hud.RED);
    // search bar
    int sx=width/2-80; g.fill(sx-1,36,sx+161,52,0xFF2B2B33); g.fill(sx,37,sx+160,51,0xEE0B0B10);
    String qs=query.isEmpty()?"§7Search modules... (just type)":"§f"+query+((System.currentTimeMillis()/500)%2==0?"§c_":""); g.drawTextWithShadow(textRenderer,qs,sx+5,40,0xFFFFFFFF);
    // master switch
    boolean pn=ModuleManager.panicked; g.fill(6,6,100,22,pn?0xEE1F8F3A:0xEED41F26); g.fill(6,21,100,22,0xFFFFFFFF);
    g.drawCenteredTextWithShadow(textRenderer,pn?"RESTORE HACKS":"ALL HACKS OFF",53,10,0xFFFFFFFF);
    String ht="Hacks turned on: "+ModuleManager.enabledCount(); g.drawTextWithShadow(textRenderer,ht,width-textRenderer.getWidth(ht)-6,height-12,0xFFFFFFFF);
    g.drawTextWithShadow(textRenderer,"§7LMB toggle | RMB settings | MMB bind | drag headers | END = all off/on",6,height-12,0xFFFFFFFF);
    hits.clear(); Category[] cs=Category.values();
    for(int i=0;i<cs.length;i++){
      int x=px[i],y=py[i];
      g.fill(x,y,x+W,y+16,0xEE0B0B10); g.fill(x,y,x+W,y+1,Hud.RED);
      g.drawTextWithShadow(textRenderer,cs[i].label.toUpperCase(),x+5,y+4,0xFFFFFFFF); hits.add(new Hit(x,y,W,16,null,null,i,false)); y+=16;
      for(Module m:ModuleManager.byCat(cs[i])){
        if(!match(m)) continue;
        boolean hv=mx>=x&&mx<x+W&&my>=y&&my<y+13;
        g.fill(x,y,x+W,y+13,m.on?0xEED41F26:(hv?0xDD1C1C24:0xCC0B0B10));
        g.drawTextWithShadow(textRenderer,m.name,x+4,y+3,m.on?0xFFFFFFFF:0xFFB5B5BD);
        String k=binding==m?"...":(m.key>=0?"["+ModuleManager.keyName(m.key)+"]":(m.settings.isEmpty()?"":(m.expanded?"-":"+")));
        g.drawTextWithShadow(textRenderer,"§7"+k,x+W-textRenderer.getWidth(k)-3,y+3,0xFFFFFFFF);
        hits.add(new Hit(x,y,W,13,m,null,i,false)); y+=13;
        if(m.expanded){ for(Setting s:m.settings){
          g.fill(x,y,x+W,y+12,0xDD14141B); g.fill(x,y,x+2,y+12,Hud.BLUE);
          switch(s.type){
            case BOOL -> { g.drawTextWithShadow(textRenderer,s.name,x+6,y+2,0xFFD0D0D8); String v=s.b?"ON":"OFF"; g.drawTextWithShadow(textRenderer,v,x+W-textRenderer.getWidth(v)-4,y+2,s.b?0xFF3BFF6A:0xFFFF5555); }
            case NUM -> { g.drawTextWithShadow(textRenderer,s.name,x+6,y+2,0xFFD0D0D8); String v=String.format("%.1f",s.d); g.drawTextWithShadow(textRenderer,v,x+W-textRenderer.getWidth(v)-4,y+2,0xFFFFFFFF);
                          double f=(s.d-s.min)/(s.max-s.min); g.fill(x+2,y+11,x+2+(int)((W-4)*f),y+12,Hud.RED); }
            case COLOR -> { g.drawTextWithShadow(textRenderer,s.name,x+6,y+2,0xFFD0D0D8); g.fill(x+W-16,y+2,x+W-4,y+10,s.c|0xFF000000); }
          }
          hits.add(new Hit(x,y,W,12,m,s,i,false)); y+=12; }
          if(m.name.equals("BlockESP")){ g.fill(x,y,x+W,y+13,0xDD1B2A44); g.fill(x,y,x+2,y+13,Hud.RED);
            g.drawTextWithShadow(textRenderer,"§bChoose blocks... §7("+Mods.blockEspNames().size()+")",x+6,y+3,0xFFFFFFFF); hits.add(new Hit(x,y,W,13,m,null,i,true)); y+=13; }
        }
      }
      g.fill(x,y,x+W,y+2,0xEE0B0B10);
    }
  }
  @Override public boolean mouseClicked(Click click,boolean doubled){ double mx=click.x(), my=click.y(); int b=click.button();
    if(b==0&&mx>=6&&mx<100&&my>=6&&my<22){ ModuleManager.panic(); return true; }
    for(int i=hits.size()-1;i>=0;i--){ Hit h=hits.get(i); if(!h.in(mx,my)) continue;
      if(h.m==null){ drag=h.panel; dox=(int)mx-px[drag]; doy=(int)my-py[drag]; return true; }
      if(h.pick){ client.setScreen(new BlockPicker(this)); return true; }
      if(h.s==null){ if(b==0) h.m.toggle(); else if(b==1) h.m.expanded=!h.m.expanded; else if(b==2) binding=h.m; return true; }
      Setting s=h.s; switch(s.type){ case BOOL -> s.b=!s.b; case NUM -> s.step(b==1?-1:1,(Util.keyDown(GLFW.GLFW_KEY_LEFT_CONTROL)||Util.keyDown(GLFW.GLFW_KEY_RIGHT_CONTROL))?100:(Util.keyDown(GLFW.GLFW_KEY_LEFT_SHIFT)||Util.keyDown(GLFW.GLFW_KEY_RIGHT_SHIFT))?10:1); case COLOR -> s.cycle(); } Config.save(); return true; }
    return super.mouseClicked(click,doubled);
  }
  @Override public boolean mouseDragged(Click click,double dx,double dy){ if(drag>=0){ px[drag]=(int)click.x()-dox; py[drag]=(int)click.y()-doy; return true; } return false; }
  @Override public boolean mouseReleased(Click click){ drag=-1; return super.mouseReleased(click); }
  @Override public boolean keyPressed(KeyInput input){ int key=input.key();
    if(binding!=null){ binding.key=key==GLFW.GLFW_KEY_ESCAPE?-1:key; binding=null; Config.save(); return true; }
    if(key==GLFW.GLFW_KEY_RIGHT_SHIFT){ close(); return true; }
    if(key==GLFW.GLFW_KEY_END){ ModuleManager.panic(); return true; }
    if(key==GLFW.GLFW_KEY_BACKSPACE){ if(!query.isEmpty()) query=query.substring(0,query.length()-1); return true; }
    if(key==GLFW.GLFW_KEY_ESCAPE&&!query.isEmpty()){ query=""; return true; }
    if(key>=GLFW.GLFW_KEY_A&&key<=GLFW.GLFW_KEY_Z&&query.length()<24){ query+=(char)('a'+(key-GLFW.GLFW_KEY_A)); return true; }
    if(key>=GLFW.GLFW_KEY_0&&key<=GLFW.GLFW_KEY_9&&query.length()<24){ query+=(char)('0'+(key-GLFW.GLFW_KEY_0)); return true; }
    return super.keyPressed(input);
  }
  @Override public void removed(){ Config.save(); }
}
