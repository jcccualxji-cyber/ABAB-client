package ru.abab.mixin;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
@Mixin(LivingEntity.class)
public interface LeAccessor { @Accessor("jumpingCooldown") void abab$setJumpCd(int v); }
