package ru.abab.mixin;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.abab.mods.Pack3;
/** Freecam: after vanilla positions the camera, move it to the free-camera spot. */
@Mixin(Camera.class)
public abstract class CameraMixin {
  @Shadow protected abstract void setPos(double x,double y,double z);
  @Shadow protected abstract void setRotation(float yaw,float pitch);
  @Inject(method="update", at=@At("TAIL"), require=0)
  private void abab$freecam(CallbackInfo ci){
    if(!Pack3.freecamActive()) return;
    MinecraftClient mc=MinecraftClient.getInstance(); if(mc.player==null) return;
    float td=mc.getRenderTickCounter().getTickProgress(false);
    Vec3d p=Pack3.freecamPos(td); setPos(p.x,p.y,p.z); setRotation(mc.player.getYaw(td),mc.player.getPitch(td));
  }
}
