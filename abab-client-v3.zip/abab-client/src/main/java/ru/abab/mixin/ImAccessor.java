package ru.abab.mixin;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
@Mixin(ClientPlayerInteractionManager.class)
public interface ImAccessor { @Accessor("blockBreakingCooldown") void abab$setBreakCd(int v); }
