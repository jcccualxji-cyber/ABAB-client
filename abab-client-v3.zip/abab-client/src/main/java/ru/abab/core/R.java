package ru.abab.core;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.*;
import org.joml.Matrix4f;
import ru.abab.AbabClient;
import java.util.List;
/**
 * Through-wall overlay renderer for 1.21.11 (projects to the screen and draws with DrawContext).
 * All coordinates passed in are camera-relative unless stated otherwise.
 * v2: lines are drawn as horizontal/vertical RUNS (about half the fill calls of the old 1px stepping),
 * plus 2D boxes, corner boxes and tracers that also point to targets behind you.
 */
public final class R {
  static DrawContext g;
  public static void begin(DrawContext ctx){ g=ctx; }
  public static void end(){ g=null; }
  static int sw(){ return MinecraftClient.getInstance().getWindow().getScaledWidth(); }
  static int sh(){ return MinecraftClient.getInstance().getWindow().getScaledHeight(); }

  /** Liang-Barsky clip, then draw as runs (one fill per row/column instead of one per pixel). */
  static void seg(double x0,double y0,double x1,double y1,int c){
    if(g==null||(c>>>24)==0) return;
    double dx=x1-x0, dy=y1-y0, t0=0, t1=1;
    double[] p={-dx,dx,-dy,dy}, q={x0,sw()-x0,y0,sh()-y0};
    for(int i=0;i<4;i++){
      if(p[i]==0){ if(q[i]<0) return; }
      else { double r=q[i]/p[i]; if(p[i]<0){ if(r>t1) return; if(r>t0) t0=r; } else { if(r<t0) return; if(r<t1) t1=r; } }
    }
    int ax=(int)Math.round(x0+t0*dx), ay=(int)Math.round(y0+t0*dy), bx=(int)Math.round(x0+t1*dx), by=(int)Math.round(y0+t1*dy);
    int w=bx-ax, h=by-ay;
    if(h==0){ g.fill(Math.min(ax,bx),ay,Math.max(ax,bx)+1,ay+1,c); return; }
    if(w==0){ g.fill(ax,Math.min(ay,by),ax+1,Math.max(ay,by)+1,c); return; }
    if(Math.abs(w)>=Math.abs(h)){
      int n=Math.min(4096,Math.abs(h)); int sy=h>0?1:-1;
      for(int i=0;i<=n;i++){ int y=ay+sy*i; double ta=Math.max(0,(i-0.5)/n), tb=Math.min(1,(i+0.5)/n);
        int xa=(int)Math.round(ax+w*ta), xb=(int)Math.round(ax+w*tb); g.fill(Math.min(xa,xb),y,Math.max(xa,xb)+1,y+1,c); }
    } else {
      int n=Math.min(4096,Math.abs(w)); int sx=w>0?1:-1;
      for(int i=0;i<=n;i++){ int x=ax+sx*i; double ta=Math.max(0,(i-0.5)/n), tb=Math.min(1,(i+0.5)/n);
        int ya=(int)Math.round(ay+h*ta), yb=(int)Math.round(ay+h*tb); g.fill(x,Math.min(ya,yb),x+1,Math.max(ya,yb)+1,c); }
    }
  }

  /** Full 3D box (wire + optional screen-space fill). */
  public static void box(Matrix4f unused,Box bx,int fill,int line){
    if(g==null) return;
    double[][] cs={{bx.minX,bx.minY,bx.minZ},{bx.maxX,bx.minY,bx.minZ},{bx.maxX,bx.minY,bx.maxZ},{bx.minX,bx.minY,bx.maxZ},
                   {bx.minX,bx.maxY,bx.minZ},{bx.maxX,bx.maxY,bx.minZ},{bx.maxX,bx.maxY,bx.maxZ},{bx.minX,bx.maxY,bx.maxZ}};
    Vec3d[] s=new Vec3d[8]; double minx=1e9,miny=1e9,maxx=-1e9,maxy=-1e9; int vis=0;
    for(int i=0;i<8;i++){ s[i]=AbabClient.projectRel(new Vec3d(cs[i][0],cs[i][1],cs[i][2])); if(s[i]!=null){ vis++; minx=Math.min(minx,s[i].x); maxx=Math.max(maxx,s[i].x); miny=Math.min(miny,s[i].y); maxy=Math.max(maxy,s[i].y); } }
    if(vis==0) return;
    if((fill>>>24)>0&&vis==8&&(bx.maxY-bx.minY)>0.2){
      int x1=(int)Math.max(0,minx), y1=(int)Math.max(0,miny), x2=(int)Math.min(sw(),maxx), y2=(int)Math.min(sh(),maxy);
      if(x2>x1&&y2>y1) g.fill(x1,y1,x2,y2,fill);
    }
    if((line>>>24)>0){
      int[][] e={{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
      for(int[] k:e){ Vec3d a=s[k[0]], b=s[k[1]]; if(a!=null&&b!=null) seg(a.x,a.y,b.x,b.y,line); }
    }
  }

  /** Screen rectangle {minX,minY,maxX,maxY} of a camera-relative box, or null if any corner is behind the camera. */
  public static double[] rect(Box bx){
    double minx=1e9,miny=1e9,maxx=-1e9,maxy=-1e9;
    for(int i=0;i<8;i++){
      Vec3d s=AbabClient.projectRel(new Vec3d((i&1)==0?bx.minX:bx.maxX,(i&2)==0?bx.minY:bx.maxY,(i&4)==0?bx.minZ:bx.maxZ));
      if(s==null) return null;
      minx=Math.min(minx,s.x); maxx=Math.max(maxx,s.x); miny=Math.min(miny,s.y); maxy=Math.max(maxy,s.y);
    }
    if(maxx<0||maxy<0||minx>sw()||miny>sh()) return null;
    return new double[]{minx,miny,maxx,maxy};
  }

  /** 2D ESP box (always upright and centered on the target). corners=true draws only the corner brackets. */
  public static void box2d(double[] r,int line,int fill,boolean corners){
    if(g==null||r==null) return;
    int x1=(int)Math.round(r[0]), y1=(int)Math.round(r[1]), x2=(int)Math.round(r[2]), y2=(int)Math.round(r[3]);
    if(x2-x1<2) x2=x1+2; if(y2-y1<2) y2=y1+2;
    if((fill>>>24)>0) g.fill(x1,y1,x2,y2,fill);
    int sh=0xAA000000;
    if(!corners){
      g.fill(x1-1,y1-1,x2+1,y1,sh); g.fill(x1-1,y2,x2+1,y2+1,sh); g.fill(x1-1,y1,x1,y2,sh); g.fill(x2,y1,x2+1,y2,sh);
      g.fill(x1,y1,x2,y1+1,line); g.fill(x1,y2-1,x2,y2,line); g.fill(x1,y1,x1+1,y2,line); g.fill(x2-1,y1,x2,y2,line);
    } else {
      int L=Math.max(3,Math.min(x2-x1,y2-y1)/4);
      g.fill(x1,y1,x1+L,y1+1,line); g.fill(x1,y1,x1+1,y1+L,line);
      g.fill(x2-L,y1,x2,y1+1,line); g.fill(x2-1,y1,x2,y1+L,line);
      g.fill(x1,y2-1,x1+L,y2,line); g.fill(x1,y2-L,x1+1,y2,line);
      g.fill(x2-L,y2-1,x2,y2,line); g.fill(x2-1,y2-L,x2,y2,line);
    }
  }

  public static void line(Matrix4f unused,Vec3d a,Vec3d b,int c){
    Vec3d pa=AbabClient.projectRel(a), pb=AbabClient.projectRel(b);
    if(pa!=null&&pb!=null) seg(pa.x,pa.y,pb.x,pb.y,c);
  }

  /** Tracer from the screen center (or bottom center) to a camera-relative point. Points behind you aim at the screen edge. */
  public static void tracer(Vec3d rel,int c,boolean bottom){
    if(g==null) return;
    double[] o=new double[3]; AbabClient.camSpace(rel,o);
    double W=sw(),H=sh(), sx=W/2, sy=bottom?H:H/2, tx,ty;
    if(o[2]<=0.05){ double l=Math.hypot(o[0],o[1]); if(l<1e-6){ tx=W/2; ty=H+2000; } else { tx=W/2+o[0]/l*4000; ty=H/2-o[1]/l*4000; } }
    else { double[] s=AbabClient.scr(o); tx=s[0]; ty=s[1]; }
    seg(sx,sy,tx,ty,c);
  }

  /** pts are absolute world positions. */
  public static void lines(Matrix4f unused,List<Vec3d> pts,Vec3d cam,int c){
    if(pts.size()<2) return;
    Vec3d prev=null;
    for(Vec3d p:pts){ Vec3d s=AbabClient.projectRel(p.subtract(cam)); if(prev!=null&&s!=null) seg(prev.x,prev.y,s.x,s.y,c); prev=s; }
  }
}
