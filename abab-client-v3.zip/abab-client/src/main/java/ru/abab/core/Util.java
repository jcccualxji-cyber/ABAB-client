package ru.abab.core;
import java.util.function.Predicate;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.*;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.mob.WaterCreatureEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.Packet;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.*;
public final class Util {
  static final MinecraftClient mc = MinecraftClient.getInstance();
  public static float fwd(){ return (mc.options.forwardKey.isPressed()?1f:0f)-(mc.options.backKey.isPressed()?1f:0f); }
  public static float side(){ return (mc.options.leftKey.isPressed()?1f:0f)-(mc.options.rightKey.isPressed()?1f:0f); }
  public static boolean keyDown(int k){ return org.lwjgl.glfw.GLFW.glfwGetKey(mc.getWindow().getHandle(),k)==org.lwjgl.glfw.GLFW.GLFW_PRESS; }
  public static boolean moving(){ return fwd()!=0||side()!=0; }
  /** Horizontal velocity from WASD at given speed (blocks/tick); vy = new vertical velocity. */
  public static void move(double speed, double vy){
    float f=fwd(), s=side();
    if(f==0&&s==0){ mc.player.setVelocity(0,vy,0); return; }
    double len=Math.max(1,Math.hypot(f,s)), yaw=Math.toRadians(mc.player.getYaw());
    double dx=(-Math.sin(yaw)*f+Math.cos(yaw)*s)/len*speed, dz=(Math.cos(yaw)*f+Math.sin(yaw)*s)/len*speed;
    mc.player.setVelocity(dx,vy,dz);
  }
  public static int sel(){ return mc.player.getInventory().getSelectedSlot(); }
  public static void sel(int i){ mc.player.getInventory().setSelectedSlot(i); }
  public static int findHotbar(Predicate<ItemStack> p){ for(int i=0;i<9;i++) if(p.test(mc.player.getInventory().getStack(i))) return i; return -1; }
  public static boolean place(BlockPos pos){
    if(!mc.world.getBlockState(pos).isReplaceable()) return false;
    for(Direction d:Direction.values()){
      BlockPos n=pos.offset(d);
      if(mc.world.getBlockState(n).isAir()||!mc.world.getFluidState(n).isEmpty()) continue;
      Direction face=d.getOpposite();
      Vec3d hit=Vec3d.ofCenter(n).add(face.getOffsetX()*0.5,face.getOffsetY()*0.5,face.getOffsetZ()*0.5);
      mc.interactionManager.interactBlock(mc.player,Hand.MAIN_HAND,new BlockHitResult(hit,face,n,false));
      mc.player.swingHand(Hand.MAIN_HAND);
      return true;
    }
    return false;
  }
  public static void face(Vec3d t){
    Vec3d e=mc.player.getEyePos(); double dx=t.x-e.x,dy=t.y-e.y,dz=t.z-e.z;
    mc.player.setYaw((float)Math.toDegrees(Math.atan2(dz,dx))-90f);
    mc.player.setPitch((float)-Math.toDegrees(Math.atan2(dy,Math.hypot(dx,dz))));
  }
  /** 0 players, 1 hostile, 2 animals, 3 items, 4 other living, -1 ignore */
  public static int cat(Entity e){
    if(e instanceof PlayerEntity) return 0;
    if(e instanceof Monster) return 1;
    if(e instanceof AnimalEntity||e instanceof WaterCreatureEntity) return 2;
    if(e instanceof ItemEntity) return 3;
    if(e instanceof LivingEntity) return 4;
    return -1;
  }
  public static Box lerpBox(Entity e,float td){
    Vec3d lp=e.getLerpedPos(td); double x=lp.x, y=lp.y, z=lp.z;
    return e.getBoundingBox().offset(x-e.getX(),y-e.getY(),z-e.getZ());
  }
  public static void send(Packet<?> p){ mc.player.networkHandler.sendPacket(p); }
  public static void msg(String s){ if(mc.inGameHud!=null) mc.inGameHud.getChatHud().addMessage(Text.literal("§c[АБАБ]§r "+s)); }
}
