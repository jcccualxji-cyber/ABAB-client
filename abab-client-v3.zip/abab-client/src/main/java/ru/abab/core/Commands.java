package ru.abab.core;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import ru.abab.gui.ClickGui;
import ru.abab.mods.Mods;
import ru.abab.mods.Extra;
import ru.abab.mods.Pack2;
public final class Commands {
  public static String PREFIX=".";
  static final MinecraftClient mc=MinecraftClient.getInstance();
  /** chat hook: return false to cancel sending to the server */
  public static boolean chat(String m){
    if(!m.startsWith(PREFIX)||m.length()<2) return true;
    run(m.substring(PREFIX.length()).trim().split("\\s+")); return false;
  }
  /** /vclip /hclip /abab hook (no leading slash) */
  public static boolean command(String c){
    String[] a=c.trim().split("\\s+"); String h=a[0].toLowerCase();
    if(h.equals("vclip")||h.equals("hclip")){ run(a); return false; }
    if(h.equals("abab")){ run(java.util.Arrays.copyOfRange(a,1,a.length)); return false; }
    return true;
  }
  static void run(String[] a){
    if(a.length==0||a[0].isEmpty()) return;
    try{
    switch(a[0].toLowerCase()){
      case "help" -> { Util.msg("§f.toggle <mod> | .bind <mod> <key|none> | .set <mod> <setting> <value> | .settings <mod>");
        Util.msg("§f.vclip <n> | .hclip <n> | .block add/remove/list/clear/ores <block> | .panic | .fov <n> | .gui | .modules | .prefix <p> | .save | .sus [clear] | .wp add/del/list/clear <name> [x y z]"); }
      case "panic" -> { ModuleManager.panic(); Util.msg(ModuleManager.panicked?"§cAll hacks OFF §7(.panic or END to restore)":"§aHacks restored"); }
      case "gui" -> mc.send(() -> mc.setScreen(new ClickGui()));
      case "modules" -> { for(Category c:Category.values()){ StringBuilder sb=new StringBuilder("§c"+c.label+": §f"); for(Module m:ModuleManager.byCat(c)) sb.append(m.on?"§a":"§7").append(m.name).append(" "); Util.msg(sb.toString()); } }
      case "t","toggle" -> { Module m=ModuleManager.get(a[1]); if(m==null){Util.msg("§cNo such module");return;} m.toggle(); Util.msg(m.name+(m.on?" §aON":" §cOFF")); }
      case "bind" -> { Module m=ModuleManager.get(a[1]); if(m==null){Util.msg("§cNo such module");return;}
        if(a[2].equalsIgnoreCase("none")) m.key=-1; else { int k=ModuleManager.parseKey(a[2]); if(k==-2){Util.msg("§cUnknown key (use e.g. r, g, f6, right.shift)");return;} m.key=k; }
        Util.msg(m.name+" bound to §f"+ModuleManager.keyName(m.key)); Config.save(); }
      case "settings" -> { Module m=ModuleManager.get(a[1]); if(m==null){Util.msg("§cNo such module");return;} for(Setting s:m.settings) Util.msg("§7"+s.name+" = §f"+s.str()); }
      case "set" -> { Module m=ModuleManager.get(a[1]); if(m==null){Util.msg("§cNo such module");return;} Setting s=m.setting(a[2]); if(s==null){Util.msg("§cNo such setting");return;}
        Util.msg(s.parse(a[3])?"§a"+s.name+" = "+s.str():"§cBad value"); Config.save(); }
      case "fov" -> { Module m=ModuleManager.get("CustomFov"); m.setting("FOV").parse(a[1]); m.set(true); Util.msg("FOV "+a[1]); }
      case "prefix" -> { PREFIX=a[1]; Util.msg("Prefix: "+PREFIX); }
      case "save" -> { Config.save(); Util.msg("Saved"); }
      case "block" -> { switch(a[1].toLowerCase()){
          case "add" -> Util.msg(Mods.blockEspAdd(a[2])?"§aAdded "+a[2]:"§cUnknown block");
          case "remove" -> { Mods.blockEspRemove(a[2]); Util.msg("Removed "+a[2]); }
          case "clear" -> { Mods.blockEspClear(); Util.msg("Cleared"); }
          case "ores" -> Util.msg("§aAdded "+Mods.blockEspAddOres()+" ore blocks");
          default -> Util.msg("§f"+Mods.blockEspNames()); } Config.save(); }
      case "vclip" -> { if(mc.player==null) return; double d=Double.parseDouble(a[1]); double x=mc.player.getX(),y=mc.player.getY(),z=mc.player.getZ();
        int n=Math.min(19,(int)Math.ceil(Math.abs(d)/8.0)); for(int i=0;i<n;i++) Util.send(new PlayerMoveC2SPacket.PositionAndOnGround(x,y,z,false,false));
        Util.send(new PlayerMoveC2SPacket.PositionAndOnGround(x,y+d,z,false,false)); mc.player.setPosition(x,y+d,z); Util.msg("vclip "+d); }
      case "hclip" -> { if(mc.player==null) return; double d=Double.parseDouble(a[1]); double yaw=Math.toRadians(mc.player.getYaw());
        double x=mc.player.getX()-Math.sin(yaw)*d,z=mc.player.getZ()+Math.cos(yaw)*d,y=mc.player.getY();
        int n=Math.min(19,(int)Math.ceil(Math.abs(d)/8.0)); for(int i=0;i<n;i++) Util.send(new PlayerMoveC2SPacket.PositionAndOnGround(mc.player.getX(),y,mc.player.getZ(),false,false));
        Util.send(new PlayerMoveC2SPacket.PositionAndOnGround(x,y,z,false,false)); mc.player.setPosition(x,y,z); Util.msg("hclip "+d); }
      case "wp" -> { Pack2.wpCommand(a); Config.save(); }
      case "sus" -> { if(a.length>1&&a[1].equalsIgnoreCase("clear")){ Extra.susClear(); Util.msg("Cleared"); } else for(String l:Extra.susTop(8)) Util.msg(l); }
      default -> Util.msg("§cUnknown command. .help");
    }
    }catch(ArrayIndexOutOfBoundsException e){ Util.msg("§cMissing argument. .help"); }
     catch(Exception e){ Util.msg("§cError: "+e.getMessage()); }
  }
}
