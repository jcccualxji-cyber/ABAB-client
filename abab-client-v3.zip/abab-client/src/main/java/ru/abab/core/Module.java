package ru.abab.core;
import java.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
public abstract class Module {
  public static final MinecraftClient mc = MinecraftClient.getInstance();
  public final String name; public final Category cat;
  public int key=-1; public boolean on, expanded;
  public final List<Setting> settings=new ArrayList<>();
  protected Module(String n, Category c){name=n;cat=c;}
  protected Setting bool(String n,boolean v){ Setting s=Setting.bool(n,v); settings.add(s); return s; }
  protected Setting num(String n,double v,double a,double b,double st){ Setting s=Setting.num(n,v,a,b,st); settings.add(s); return s; }
  protected Setting color(String n,int argb){ Setting s=Setting.color(n,argb); settings.add(s); return s; }
  public Setting setting(String n){ for(Setting s:settings) if(s.name.equalsIgnoreCase(n)) return s; return null; }
  public void toggle(){ set(!on); }
  public void set(boolean v){ if(v==on) return; on=v; if(mc.player!=null){ if(v) onEnable(); else onDisable(); } }
  public void onEnable(){} public void onDisable(){} public void onTick(){}
  public void onRender(Matrix4f m, Vec3d cam, float td){}
  public void onHud(DrawContext g, float td){}
}
