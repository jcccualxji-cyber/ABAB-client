package ru.abab.core;
public class Setting {
  public enum T { BOOL, NUM, COLOR }
  public final String name; public final T type;
  public boolean b; public double d, min, max, step; public int c;
  private Setting(String n, T t){name=n;type=t;}
  public static Setting bool(String n, boolean v){ Setting s=new Setting(n,T.BOOL); s.b=v; return s; }
  public static Setting num(String n,double v,double mi,double ma,double st){ Setting s=new Setting(n,T.NUM); s.d=v;s.min=mi;s.max=ma;s.step=st; return s; }
  public static Setting color(String n,int argb){ Setting s=new Setting(n,T.COLOR); s.c=argb; return s; }
  public int i(){ return (int)d; }
  public String str(){ return switch(type){ case BOOL -> b?"true":"false"; case NUM -> String.valueOf(Math.round(d*100)/100.0); case COLOR -> String.format("#%08X", c); }; }
  public boolean parse(String s){
    try{
      switch(type){
        case BOOL -> b = s.equalsIgnoreCase("true")||s.equalsIgnoreCase("on")||s.equals("1");
        case NUM -> d = Math.max(min, Math.min(max, Double.parseDouble(s)));
        case COLOR -> { String h=s.replace("#",""); long v=Long.parseLong(h,16); c=(int)(h.length()<=6 ? (0xFF000000L|v) : v); }
      }
      return true;
    }catch(Exception e){ return false; }
  }
  public void step(int dir){ step(dir,1); }
  public void step(int dir,double mult){ if(type==T.NUM) d=Math.max(min,Math.min(max, Math.round((d+dir*step*mult)*1000)/1000.0)); }
  static final int[] PALETTE={0xFFFF3B3B,0xFFFF9A1F,0xFFFFE23B,0xFF3BFF6A,0xFF3BC8FF,0xFF4D6BFF,0xFFC04DFF,0xFFFFFFFF};
  public void cycle(){ if(type!=T.COLOR) return; int k=0; for(int i=0;i<PALETTE.length;i++) if(PALETTE[i]==c) k=i+1; c=PALETTE[k%PALETTE.length]; }
}
