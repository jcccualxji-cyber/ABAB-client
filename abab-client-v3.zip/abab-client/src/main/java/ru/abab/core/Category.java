package ru.abab.core;
public enum Category { COMBAT("Combat"), PLAYER("Player"), MOVEMENT("Movement"), RENDER("Render"), WORLD("World");
  public final String label; Category(String l){label=l;} }
