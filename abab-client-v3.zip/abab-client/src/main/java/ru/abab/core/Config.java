package ru.abab.core;
import java.io.*; import java.nio.file.*; import java.util.Properties;
import net.fabricmc.loader.api.FabricLoader;
import ru.abab.mods.Mods;
import ru.abab.mods.Pack2;
public final class Config {
  static Path file(){ return FabricLoader.getInstance().getConfigDir().resolve("abab.properties"); }
  public static void save(){
    try{ Properties p=new Properties();
      for(Module m:ModuleManager.all){ p.setProperty(m.name+".key",String.valueOf(m.key)); for(Setting s:m.settings) p.setProperty(m.name+"."+s.name,s.str()); }
      p.setProperty("waypoints",Pack2.wpSerialize()); p.setProperty("blockesp.blocks",String.join(",",Mods.blockEspNames()));
      try(OutputStream o=Files.newOutputStream(file())){ p.store(o,"ABAB client"); }
    }catch(Exception e){ e.printStackTrace(); }
  }
  public static void load(){
    try{ if(!Files.exists(file())) return; Properties p=new Properties(); try(InputStream i=Files.newInputStream(file())){ p.load(i); }
      for(Module m:ModuleManager.all){ String k=p.getProperty(m.name+".key"); if(k!=null) m.key=Integer.parseInt(k); for(Setting s:m.settings){ String v=p.getProperty(m.name+"."+s.name); if(v!=null) s.parse(v); } }
      String wp=p.getProperty("waypoints"); if(wp!=null) Pack2.wpLoad(wp); String b=p.getProperty("blockesp.blocks"); if(b!=null) for(String n:b.split(",")) if(!n.isBlank()) Mods.blockEspAdd(n);
    }catch(Exception e){ e.printStackTrace(); }
  }
}
