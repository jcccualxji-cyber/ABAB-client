package ru.abab.mods;
import java.util.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
import ru.abab.core.Module;
import ru.abab.core.*;
import ru.abab.gui.Hud;

/** Batch 3: Freecam, Fly, ArmorHUD, PotionHUD, CPS, Speedometer. */
public final class Pack3 {
  static Freecam FC;
  public static void register(List<Module> l){
    FC=new Freecam();
    l.addAll(List.of(FC,new Fly(),new ArmorHud(),new PotionHud(),new Cps(),new Speedometer()));
  }
  public static boolean freecamActive(){ return Freecam.active; }
  public static Vec3d freecamPos(float td){ return Freecam.prev.lerp(Freecam.pos,td); }
  /** called when there is no world/player (disconnect): never leave freecam stuck on. */
  public static void freecamReset(){ Freecam.active=false; if(FC!=null) FC.on=false; }
  static int px(Setting s,int total){ return (int)(total*s.d/100.0); }

  // ===== Freecam: camera detaches, your body stays put and sends NO movement packets (see ClientPlayerMixin / CameraMixin) =====
  public static class Freecam extends Module {
    public static boolean active; public static Vec3d pos=Vec3d.ZERO, prev=Vec3d.ZERO; static Vec3d home;
    Setting sp=num("Speed",1.0,0.1,5,0.1);
    public Freecam(){ super("Freecam",Category.RENDER); }
    public void onEnable(){ pos=prev=mc.player.getEyePos(); home=mc.player.getEntityPos(); active=true; }
    public void onDisable(){ active=false; if(mc.player!=null&&home!=null){ mc.player.setPosition(home); mc.player.setVelocity(Vec3d.ZERO); } }
    public void onTick(){
      if(mc.player.getHealth()<=0){ set(false); return; }
      prev=pos;
      if(mc.currentScreen==null){
        double yaw=Math.toRadians(mc.player.getYaw()), pit=Math.toRadians(mc.player.getPitch()), cp=Math.cos(pit);
        Vec3d f=new Vec3d(-Math.sin(yaw)*cp,-Math.sin(pit),Math.cos(yaw)*cp), left=new Vec3d(Math.cos(yaw),0,Math.sin(yaw));
        double fw=(Util.keyDown(GLFW.GLFW_KEY_W)?1:0)-(Util.keyDown(GLFW.GLFW_KEY_S)?1:0), sd=(Util.keyDown(GLFW.GLFW_KEY_A)?1:0)-(Util.keyDown(GLFW.GLFW_KEY_D)?1:0),
               up=(Util.keyDown(GLFW.GLFW_KEY_SPACE)?1:0)-(Util.keyDown(GLFW.GLFW_KEY_LEFT_SHIFT)?1:0);
        Vec3d mv=f.multiply(fw).add(left.multiply(sd)).add(0,up,0);
        if(mv.lengthSquared()>0) pos=pos.add(mv.normalize().multiply(sp.d*0.5));
      }
      // keep the real player frozen (client side only; movement packets are cancelled while active)
      if(home!=null){ mc.player.setPosition(home); mc.player.setVelocity(Vec3d.ZERO); mc.player.fallDistance=0; }
    }
  }

  // ===== Fly: stays inside vanilla-like numbers (low speed, small vertical, anti "floating" kick). No fly is guaranteed
  // undetectable by Grim - this one only avoids the obvious flags (huge speed, constant hover, bad onGround). =====
  public static class Fly extends Module {
    Setting sp=num("Speed",0.26,0.05,3,0.01), vs=num("Vertical",0.1,0.02,2,0.01), anti=bool("AntiKick",true);
    int t;
    public Fly(){ super("Fly",Category.MOVEMENT); }
    public void onTick(){
      if(mc.player.hasVehicle()) return;
      double vy=mc.options.jumpKey.isPressed()?vs.d:mc.options.sneakKey.isPressed()?-vs.d:0;
      if(vy==0&&anti.b&&++t%20==0) vy=-0.04; // vanilla kicks after 80 ticks without any real downward movement
      Util.move(sp.d,vy); mc.player.fallDistance=0;
    }
  }

  // ===== ArmorHUD: your armor + durability on screen =====
  public static class ArmorHud extends Module {
    Setting yoff=num("YOffset",74,20,200,1), xoff=num("XOffset",0,-300,300,1), pct=bool("Percent",true), bars=bool("Bars",true), off=bool("Offhand",false);
    public ArmorHud(){ super("ArmorHUD",Category.RENDER); on=true; }
    public void onHud(DrawContext g,float td){
      EquipmentSlot[] sl=off.b?new EquipmentSlot[]{EquipmentSlot.HEAD,EquipmentSlot.CHEST,EquipmentSlot.LEGS,EquipmentSlot.FEET,EquipmentSlot.OFFHAND}
                              :new EquipmentSlot[]{EquipmentSlot.HEAD,EquipmentSlot.CHEST,EquipmentSlot.LEGS,EquipmentSlot.FEET};
      int w=mc.getWindow().getScaledWidth(), h=mc.getWindow().getScaledHeight(), cell=22, total=sl.length*cell;
      int x0=w/2-total/2+xoff.i(), y=h-yoff.i();
      g.fill(x0-3,y-3,x0+total+1,y+26,0x88000000); g.fill(x0-3,y-3,x0+total+1,y-2,Hud.RED);
      for(int i=0;i<sl.length;i++){
        ItemStack s=mc.player.getEquippedStack(sl[i]); int x=x0+i*cell;
        if(s.isEmpty()){ g.fill(x+2,y+2,x+14,y+14,0x33FFFFFF); continue; }
        g.drawItem(s,x,y);
        if(bars.b&&s.isItemBarVisible()){ g.fill(x+2,y+13,x+15,y+15,0xFF000000); g.fill(x+2,y+13,x+2+s.getItemBarStep(),y+14,s.getItemBarColor()|0xFF000000); }
        if(pct.b&&s.isDamageable()){
          int p=Math.max(0,Math.round(100f*(s.getMaxDamage()-s.getDamage())/s.getMaxDamage())); String t=p+"%";
          int col=p>60?0xFF3BFF6A:p>30?0xFFFFE23B:0xFFFF3B3B;
          g.getMatrices().pushMatrix(); g.getMatrices().translate((float)(x+8-mc.textRenderer.getWidth(t)*0.35f),(float)(y+17)); g.getMatrices().scale(0.7f,0.7f);
          g.drawTextWithShadow(mc.textRenderer,t,0,0,col); g.getMatrices().popMatrix();
        }
      }
    }
  }

  // ===== PotionHUD: active effects with time left =====
  public static class PotionHud extends Module {
    Setting x=num("X%",1,0,95,1), y=num("Y%",45,0,95,1);
    public PotionHud(){ super("PotionHUD",Category.RENDER); }
    public void onHud(DrawContext g,float td){
      int X=px(x,mc.getWindow().getScaledWidth()), Y=px(y,mc.getWindow().getScaledHeight());
      for(StatusEffectInstance e:mc.player.getStatusEffects()){
        String name=e.getEffectType().value().getName().getString()+" "+(e.getAmplifier()+1);
        int sec=e.getDuration()/20; String time=e.isInfinite()?"**":(sec/60)+":"+String.format("%02d",sec%60);
        int col=sec<10&&!e.isInfinite()?0xFFFF5555:0xFFFFFFFF;
        g.fill(X-2,Y-1,X+mc.textRenderer.getWidth(name+" "+time)+3,Y+10,0x88000000); g.fill(X-2,Y-1,X-1,Y+10,Hud.BLUE);
        g.drawTextWithShadow(mc.textRenderer,name+" §7"+time,X+1,Y,col); Y+=12;
      }
    }
  }

  // ===== CPS counter =====
  public static class Cps extends Module {
    Setting x=num("X%",1,0,95,1), y=num("Y%",38,0,95,1);
    final ArrayDeque<Long> l=new ArrayDeque<>(), r=new ArrayDeque<>(); boolean la,ra;
    public Cps(){ super("CPS",Category.RENDER); }
    public void onTick(){ long n=System.currentTimeMillis(); boolean a=mc.options.attackKey.isPressed(), u=mc.options.useKey.isPressed();
      if(a&&!la) l.add(n); if(u&&!ra) r.add(n); la=a; ra=u; while(!l.isEmpty()&&n-l.peekFirst()>1000) l.pollFirst(); while(!r.isEmpty()&&n-r.peekFirst()>1000) r.pollFirst(); }
    public void onHud(DrawContext g,float td){ g.drawTextWithShadow(mc.textRenderer,"§cCPS §f"+l.size()+" §7| §f"+r.size(),px(x,mc.getWindow().getScaledWidth()),px(y,mc.getWindow().getScaledHeight()),0xFFFFFFFF); }
  }

  // ===== Speedometer (blocks per second) =====
  public static class Speedometer extends Module {
    Setting x=num("X%",1,0,95,1), y=num("Y%",41,0,95,1);
    public Speedometer(){ super("Speedometer",Category.RENDER); }
    public void onHud(DrawContext g,float td){ double bps=Math.hypot(mc.player.getX()-mc.player.prevX,mc.player.getZ()-mc.player.prevZ)*20;
      g.drawTextWithShadow(mc.textRenderer,String.format("§cSpeed §f%.1f b/s",bps),px(x,mc.getWindow().getScaledWidth()),px(y,mc.getWindow().getScaledHeight()),0xFFFFFFFF); }
  }
}
